#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MIN_INTRON_LEN 11

typedef struct RegionStartEnd {
	int start;
	int end;
} REGION;

typedef struct candidate {
        char chr[50];
        int start;
        int end;
        char strand;
        //char ENSTID[1000];
	char Label[10];
	//int numFlanking;
	//REGION *Flanking;
	int frontFlankStart;
	int frontFlankEnd;
	int rearFlankStart;
	int rearFlankEnd; 
	int phase;
	int CDSstart;
	int CDSend;
	char MAX_ENST[50];
	int MAX_ENST_InitStart;
	int MAX_ENST_InitEnd; 
        char MAX_EST[50];
        int MAX_ENST_AdjStart;
        int MAX_ENST_AdjEnd;
} CANDIDATE;

typedef struct SeqAlign { 
	char TargetChr[50];
	int TargetStart; 
	int TargetEnd;
	char TargetStrand;
	int TargetLength; 
	char *TargetString;
	char QueryTag[50];
	int QueryStart; 
	int QueryEnd;
	char QueryStrand;
	int QueryLength;
	char *QueryString;
} ALIGNMENT; 

ALIGNMENT searchSeq(CANDIDATE cand, ALIGNMENT *alignList, int numAlign);
ALIGNMENT RevAlign(ALIGNMENT intputAlignment, int isReverse);
int AlignCutOut(CANDIDATE *cand, int numNovel, ALIGNMENT goalAlign);
int OverLapNovelLen(CANDIDATE cand, int RegionStart, int RegionEnd);
char NucCompl(char ch);

int main(int argc, char **argv)
{
	FILE *CandFile = NULL, *MafSeqFile = NULL, *p_NUM_MAF_BLOCKS_ = NULL; 
	int i = 0; 
	int numNovel = 0;
	//int numCandidates = 0;
	int numAlign = 0;
	int scanVal = 0;
	char delim;
	ALIGNMENT goalAlign;
	CANDIDATE tmpForSearch;

	if ((CandFile = fopen(argv[1], "r")) == NULL || (MafSeqFile = fopen(argv[2], "r")) == NULL || argc != 3) {
		if (argc != 3) fprintf(stderr, "Usage:\n\t./DN_DS_Seq_Cut [DN_DS_INPUT_CANDIDATES] [MAF_To_DNDS_INPUT]\n\n");
                else if (CandFile == NULL) fprintf(stderr, "** File ([DN_DS_INPUT_CANDIDATES]) error! **\n");
                else if (MafSeqFile == NULL) fprintf(stderr, "** File ([MAF_To_DNDS_INPUT]) error! **\n");
                exit(EXIT_FAILURE);
        }

	//while (fgets(AlignLine, 20000, MafSeqFile) != NULL) {
	//	if (AlignLine[0] == 'c' && AlignLine[1] == 'h' && AlignLine[2] == 'r') numAlign++;
	//}
	//fseek(MafSeqFile, 0, SEEK_SET);
	if ((p_NUM_MAF_BLOCKS_ = fopen("_NUM_MAF_BLOCKS_", "r")) == NULL) { 
		fprintf(stderr, "** File _NUM_MAF_BLOCKS_ error!  **\n");
		exit(EXIT_FAILURE);
	} 
	if (fscanf(p_NUM_MAF_BLOCKS_, "%d", &numAlign) != 1) { 
		fprintf(stderr, "** File _NUM_MAF_BLOCKS_ error!  **\n");
		exit(EXIT_FAILURE);
	}
	fclose(p_NUM_MAF_BLOCKS_); 

	//CANDIDATE *candList = (CANDIDATE *)malloc(sizeof(CANDIDATE) * numCandidates);
	ALIGNMENT *alignList = (ALIGNMENT *)malloc(sizeof(ALIGNMENT) * numAlign);
	
	while (fscanf(MafSeqFile, "%s %d %d %c %d", alignList[i].TargetChr, &alignList[i].TargetStart, &alignList[i].TargetEnd, &alignList[i].TargetStrand, &alignList[i].TargetLength) != EOF) {
		alignList[i].TargetString = (char *)malloc(sizeof(char) * (alignList[i].TargetLength + 1));
		scanVal = fscanf(MafSeqFile, "%c", &delim);
		if (scanVal != 1) fprintf(stderr, "** File reading error in DN_DS_Novel_Cut **\n");
		if (fgets(alignList[i].TargetString, (alignList[i].TargetLength + 1), MafSeqFile) == NULL) 
			fprintf(stderr, "** Target string reading error in DN_DS_Novel_Cut **\n");
		alignList[i].TargetString[alignList[i].TargetLength] = '\0';

		scanVal = fscanf(MafSeqFile, "%s %d %d %c %d", alignList[i].QueryTag, &alignList[i].QueryStart, &alignList[i].QueryEnd, &alignList[i].QueryStrand, &alignList[i].QueryLength); 
		if (scanVal != 5) fprintf(stderr, "** File reading error in DN_DS_Novel_Cut **\n");
		alignList[i].QueryString = (char *)malloc(sizeof(char) * (alignList[i].QueryLength + 1));
		scanVal = fscanf(MafSeqFile, "%c", &delim);
		if (scanVal != 1) fprintf(stderr, "** File reading error in DN_DS_Novel_Cut **\n");
		if (fgets(alignList[i].QueryString, (alignList[i].QueryLength + 1), MafSeqFile) == NULL) 
			fprintf(stderr, "** Query string reading error in DN_DS_Novel_Cut **\n");
		alignList[i].QueryString[alignList[i].QueryLength] = '\0';
		//strcpy(alignList[i].QueryString, AlignLine);
		i++;
	}
	fclose(MafSeqFile);
	i = 0;

	while (fscanf(CandFile, "%d", &numNovel) != EOF) {
		CANDIDATE *candList = (CANDIDATE *)malloc(sizeof(CANDIDATE) * numNovel);

		//printf("@@ numNovel = %d @@\n", numNovel);
		for (i=0; i<numNovel; i++) { 
			scanVal = fscanf(CandFile, "%s %d %d %c %s %d %d %d %d %d %d %d %s %d %d %s %d %d", candList[i].chr, &candList[i].start, &candList[i].end, &candList[i].strand, candList[i].Label, 
			&candList[i].frontFlankStart, &candList[i].frontFlankEnd, &candList[i].rearFlankStart, &candList[i].rearFlankEnd, &candList[i].phase, &candList[i].CDSstart, &candList[i].CDSend, candList[i].MAX_ENST, 
			&candList[i].MAX_ENST_InitStart, &candList[i].MAX_ENST_InitEnd, candList[i].MAX_EST, &candList[i].MAX_ENST_AdjStart, &candList[i].MAX_ENST_AdjEnd);
			if (scanVal != 18) fprintf(stderr, "** File reading error in DN_DS_Novel_Cut **\n"); 
		} 
		if (candList[0].strand == '+') { 
			strcpy(tmpForSearch.chr, candList[0].chr);
			tmpForSearch.start = candList[0].start;
			tmpForSearch.end = candList[numNovel-1].end;
			tmpForSearch.strand = candList[0].strand;
			//strcpy(tmpForSearch.ENSTID, candList[0].ENSTID);
			strcpy(tmpForSearch.Label, candList[0].Label);
			tmpForSearch.frontFlankStart = candList[0].frontFlankStart;
			tmpForSearch.frontFlankEnd = candList[0].frontFlankEnd;
			tmpForSearch.rearFlankStart = candList[0].rearFlankStart;
			tmpForSearch.rearFlankEnd = candList[0].rearFlankEnd;
			tmpForSearch.phase = candList[0].phase;
			tmpForSearch.CDSstart = candList[0].CDSstart;
			tmpForSearch.CDSend = candList[0].CDSend;
			strcpy(tmpForSearch.MAX_ENST, candList[0].MAX_ENST);
			tmpForSearch.MAX_ENST_InitStart = candList[0].MAX_ENST_InitStart;
			tmpForSearch.MAX_ENST_InitEnd = candList[numNovel-1].MAX_ENST_InitEnd;
			strcpy(tmpForSearch.MAX_EST, candList[0].MAX_EST);
			tmpForSearch.MAX_ENST_AdjStart = candList[0].MAX_ENST_AdjStart;
			tmpForSearch.MAX_ENST_AdjEnd = candList[numNovel-1].MAX_ENST_AdjEnd;
		} else { 
			strcpy(tmpForSearch.chr, candList[0].chr);
			tmpForSearch.start = candList[numNovel-1].start;
			tmpForSearch.end = candList[0].end;
			tmpForSearch.strand = candList[0].strand;
			//strcpy(tmpForSearch.ENSTID, candList[0].ENSTID);
			strcpy(tmpForSearch.Label, candList[0].Label);
			tmpForSearch.frontFlankStart = candList[0].frontFlankStart;
			tmpForSearch.frontFlankEnd = candList[0].frontFlankEnd;
			tmpForSearch.rearFlankStart = candList[0].rearFlankStart;
			tmpForSearch.rearFlankEnd = candList[0].rearFlankEnd;
			tmpForSearch.phase = candList[0].phase;
			tmpForSearch.CDSstart = candList[0].CDSstart;
			tmpForSearch.CDSend = candList[0].CDSend;
			strcpy(tmpForSearch.MAX_ENST, candList[0].MAX_ENST);
			tmpForSearch.MAX_ENST_InitStart = candList[numNovel-1].MAX_ENST_InitStart;
			tmpForSearch.MAX_ENST_InitEnd = candList[0].MAX_ENST_InitEnd;
			strcpy(tmpForSearch.MAX_EST, candList[0].MAX_EST);
			tmpForSearch.MAX_ENST_AdjStart = candList[numNovel-1].MAX_ENST_AdjStart;
			tmpForSearch.MAX_ENST_AdjEnd = candList[0].MAX_ENST_AdjEnd;
		}
		
		/*for (i=0; i<numNovel; i++) {  // for checking
			printf("%s\t%d\t%d\t%c\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%d\t%d\t%s\t%d\t%d\n", candList[i].chr, candList[i].start, candList[i].end, 
			candList[i].strand, candList[i].Label, candList[i].frontFlankStart, candList[i].frontFlankEnd, candList[i].rearFlankStart, 
			candList[i].rearFlankEnd, candList[i].phase, candList[i].CDSstart, candList[i].CDSend, candList[i].MAX_ENST,
                	candList[i].MAX_ENST_InitStart, candList[i].MAX_ENST_InitEnd, candList[i].MAX_EST, candList[i].MAX_ENST_AdjStart, candList[i].MAX_ENST_AdjEnd);
                }
		printf("@@ %s\t%d\t%d\t%c\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%d\t%d\t%s\t%d\t%d\n", tmpForSearch.chr, tmpForSearch.start, tmpForSearch.end,  // for checking
		tmpForSearch.strand, tmpForSearch.Label, tmpForSearch.frontFlankStart, tmpForSearch.frontFlankEnd, tmpForSearch.rearFlankStart, // for checking
		tmpForSearch.rearFlankEnd, tmpForSearch.phase, tmpForSearch.CDSstart, tmpForSearch.CDSend, tmpForSearch.MAX_ENST, tmpForSearch.MAX_ENST_InitStart,   // for checking
		tmpForSearch.MAX_ENST_InitEnd, tmpForSearch.MAX_EST, tmpForSearch.MAX_ENST_AdjStart, tmpForSearch.MAX_ENST_AdjEnd);*/
                //for (i=0; i<numNovel; i++) { 
		goalAlign = searchSeq(tmpForSearch, alignList, numAlign);
		//printf("=>\n%s\t%d\t%d\t%c\n%s\n%s\t%d\t%d\t%c\n%s\n\n", goalAlign.TargetChr, goalAlign.TargetStart, goalAlign.TargetEnd, goalAlign.TargetStrand, // for checking
		//goalAlign.TargetString, goalAlign.QueryTag, goalAlign.QueryStart, goalAlign.QueryEnd, goalAlign.QueryStrand, goalAlign.QueryString); // for checking
		AlignCutOut(candList, numNovel, goalAlign);
		free(goalAlign.TargetString);
		free(goalAlign.QueryString);
		//}
		free(candList);
	}
	fclose(CandFile);

	for (i=0; i<numAlign; i++) {
		free(alignList[i].TargetString); 
		free(alignList[i].QueryString);
	}
	free(alignList);
	return 0;
}

ALIGNMENT searchSeq(CANDIDATE cand, ALIGNMENT *alignList, int numAlign)
{
	int i = 0, j = 0, k = 0, p = 0;
	//int flagExactFound = 0;
	//int flagCoverFound = 0;
	//int flagJointFound = 0;
	int flagJointCoverFound = 0;
	int flagErr = 1;
	int flagOverlap = 0;
	int flagJointCoverExist = 0; 
	int CoverLen = 0;
	int MaxCoverLen = 0;
	int tmpLen = 0;
	ALIGNMENT outAlign    = { "", 0, 0, '*', 0, "", "", 0, 0, '*', 0, "" };
	ALIGNMENT outRevAlign = { "", 0, 0, '*', 0, "", "", 0, 0, '*', 0, "" };

	for (i=0; i<numAlign; i++) { 
		if (!strcmp(cand.chr, alignList[i].TargetChr) && !strcmp(cand.MAX_EST, alignList[i].QueryTag)) {
			flagErr = 0;
			break;
		}
	}
	if (flagErr == 1) { 
		fprintf(stderr, "** Error in searching for the corresponding alignment result. **\n");
		exit(EXIT_FAILURE);
	}

	for (i=0; i<numAlign; i++) { // Exactly match
		if (!strcmp(cand.chr, alignList[i].TargetChr) && !strcmp(cand.MAX_EST, alignList[i].QueryTag) && 
		cand.MAX_ENST_InitStart == alignList[i].TargetStart && cand.MAX_ENST_InitEnd == alignList[i].TargetEnd && cand.strand == alignList[i].TargetStrand) { 
			//flagExactFound = 1;
			//printf("# EXACTLY #\n"); // for checking
			return RevAlign(alignList[i], 0); 
		}
	} 
	
	for (i=0; i<numAlign; i++) { // Exactly match except the strand
		if (!strcmp(cand.chr, alignList[i].TargetChr) && !strcmp(cand.MAX_EST, alignList[i].QueryTag) && 
		cand.MAX_ENST_InitStart == alignList[i].TargetStart && cand.MAX_ENST_InitEnd == alignList[i].TargetEnd) { 
			//flagExactFound = 1;
			//printf("# EXACTLY (EXCEPT STRAND) #\n"); // for checking
			return RevAlign(alignList[i], 1);
		}
	}

	for (i=0; i<numAlign; i++) { // Alignment covers the entire candidate 
		if (!strcmp(cand.chr, alignList[i].TargetChr) && !strcmp(cand.MAX_EST, alignList[i].QueryTag) && 
		alignList[i].TargetStart <= cand.MAX_ENST_InitStart && cand.MAX_ENST_InitEnd <= alignList[i].TargetEnd) { 
			//flagCoverFound = 1;
			//printf("# COVER "); // for checking
			if (cand.strand == alignList[i].TargetStrand) { 
				//printf("#\n"); // for checking
				return RevAlign(alignList[i], 0);
			} else { 
				//printf("(EXCEPT STRAND) #\n"); // for checking
				return RevAlign(alignList[i], 1);
			}
		}
	}

	for (i=0; i<numAlign; i++) { // Merge separated blocks to cover the candidate 
		flagOverlap = 0;
		flagJointCoverFound = 0;
		CoverLen = 0;

		if (!strcmp(cand.chr, alignList[i].TargetChr) && !strcmp(cand.MAX_EST, alignList[i].QueryTag) && 
		alignList[i].TargetStart <= cand.MAX_ENST_InitStart && cand.MAX_ENST_InitStart <= alignList[i].TargetEnd) { 
			//printf("** XD here **\n");
			if (alignList[i].TargetStrand == '+') { 
				if (i < numAlign-1 && (strcmp(cand.chr, alignList[i+1].TargetChr) || (!strcmp(cand.chr, alignList[i+1].TargetChr) && 
				(alignList[i+1].TargetStart < alignList[i].TargetEnd || alignList[i+1].TargetStart > cand.MAX_ENST_InitEnd)))) { 

					if ((cand.MAX_ENST_InitStart <= alignList[i].TargetStart && alignList[i].TargetStart <= cand.MAX_ENST_InitEnd) ||
					(cand.MAX_ENST_InitStart <= alignList[i].TargetEnd && alignList[i].TargetEnd <= cand.MAX_ENST_InitEnd) || 
					(alignList[i].TargetStart <= cand.MAX_ENST_InitStart && cand.MAX_ENST_InitEnd <= alignList[i].TargetEnd)) {
						flagOverlap = 1;
						flagJointCoverExist = 1;
					} else continue;
					CoverLen = OverLapNovelLen(cand, alignList[i].TargetStart, alignList[i].TargetEnd);
					if (CoverLen <= MaxCoverLen) continue;
					else { 
						if (MaxCoverLen > 0) { 
							free(outAlign.TargetString);
							free(outAlign.QueryString);
						}
						MaxCoverLen = CoverLen;
					}
					tmpLen = strlen(alignList[i].TargetString);
					strcpy(outAlign.TargetChr, alignList[i].TargetChr);
					outAlign.TargetStart = alignList[i].TargetStart;
					outAlign.TargetEnd = alignList[i].TargetEnd;
					outAlign.TargetStrand = alignList[i].TargetStrand;
					strcpy(outAlign.QueryTag, alignList[i].QueryTag);
					outAlign.QueryStart = alignList[i].QueryStart;
					outAlign.QueryEnd = alignList[j].QueryEnd;
					outAlign.QueryStrand = alignList[i].QueryStrand;
					outAlign.TargetString = (char *)malloc((sizeof(char) * (tmpLen+1)));
					outAlign.QueryString = (char *)malloc((sizeof(char) * (tmpLen+1)));
					strcpy(outAlign.TargetString, alignList[i].TargetString);
					strcpy(outAlign.QueryString, alignList[i].QueryString);
					//printf("## FAKE JOINT COVER ##\n ## (+) alignList[%d].TargetStart = %d, alignList[%d].TargetEnd = %d ##\n", // for checking
					//i, alignList[i].TargetStart, i, alignList[i].TargetEnd); // for checking
				} else if (i < numAlign - 1) { 
					//printf("## (+) alignList[%d].TargetStart = %d, alignList[%d].TargetEnd = %d (cand.MAX_ENST_InitStart = %d) ##\n", // for checking
					//i, alignList[i].TargetStart, i, alignList[i].TargetEnd, cand.MAX_ENST_InitStart); // for checking
					for (j=i+1; j<numAlign; j++) { 
						if (!strcmp(cand.chr, alignList[j].TargetChr) && !strcmp(cand.MAX_EST, alignList[j].QueryTag) && 
						alignList[j].TargetStrand == '+' && cand.MAX_ENST_InitStart <= alignList[j].TargetEnd) { 
							//printf("## alignList[%d].TargetStart = %d, alignList[%d].TargetEnd = %d ##\n", j, // for checking
							//alignList[j].TargetStart, j, alignList[j].TargetEnd); // for checking
							if (cand.strand == alignList[i].TargetStrand) { 
								//printf("# Joint #\n"); 
							} else { 
								//printf("# Joint (EXCEPT STRAND) #\n");
							}
							flagJointCoverFound = 1;
							//break;
						} 
						if (strcmp(cand.chr, alignList[j].TargetChr) || alignList[j].TargetStrand != '+' || 
						(!strcmp(cand.chr, alignList[j].TargetChr) && (alignList[j].TargetStart > cand.MAX_ENST_InitEnd || 
						alignList[j].TargetStart < alignList[j-1].TargetEnd)) ) { 
							//flagJointCoverFound = 1;
							j--;
							break;
						}
						//if (alignList[j+1].TargetStart < alignList[j].TargetEnd) break;
					}

					if (flagJointCoverFound == 1) { 
        	                               for (k=i; k<=j; k++) {
                	                                if ((cand.MAX_ENST_InitStart <= alignList[k].TargetStart && alignList[k].TargetStart <= cand.MAX_ENST_InitEnd) ||
                        	                        (cand.MAX_ENST_InitStart <= alignList[k].TargetEnd && alignList[k].TargetEnd <= cand.MAX_ENST_InitEnd) ||
                                	                (alignList[k].TargetStart <= cand.MAX_ENST_InitStart && cand.MAX_ENST_InitEnd <= alignList[k].TargetEnd)) {
                                        	                flagOverlap = 1;
                                                	        break;
	                                                }
        	                                }
                	                        if (flagOverlap != 1) continue; 
                        	                flagJointCoverExist = 1;

	
        	                                for (k=i; k<=j; k++) CoverLen += OverLapNovelLen(cand, alignList[k].TargetStart, alignList[k].TargetEnd);
                	                        if (CoverLen <= MaxCoverLen) continue;
                        	                else {
                                	                if (MaxCoverLen > 0) {
                                        	                free(outAlign.TargetString);
                                                	        free(outAlign.QueryString);
	                                                }
        	                                        MaxCoverLen = CoverLen;
                	                        }

						tmpLen = strlen(alignList[i].TargetString);
						for (k=i+1; k<=j; k++) { 
							tmpLen += strlen(alignList[k].TargetString);
							tmpLen += alignList[k].TargetStart - alignList[k-1].TargetEnd - 1;
						}
						strcpy(outAlign.TargetChr, alignList[i].TargetChr); 
						outAlign.TargetStart = alignList[i].TargetStart;
						outAlign.TargetEnd = alignList[j].TargetEnd;
						outAlign.TargetStrand = alignList[i].TargetStrand;
						strcpy(outAlign.QueryTag, alignList[i].QueryTag); 
						if (alignList[i].QueryStrand == '+') { 
							outAlign.QueryStart = alignList[i].QueryStart;
							outAlign.QueryEnd = alignList[j].QueryEnd;
						} else { 
							outAlign.QueryStart = alignList[j].QueryStart;
							outAlign.QueryEnd = alignList[i].QueryEnd;
						}
						outAlign.QueryStrand = alignList[i].QueryStrand;
						outAlign.TargetString = (char *)malloc((sizeof(char) * (tmpLen+1)));
						outAlign.QueryString = (char *)malloc((sizeof(char) * (tmpLen+1)));
						strcpy(outAlign.TargetString, alignList[i].TargetString);
						for (k=i+1; k<=j; k++) { 
							for (p=0; p<alignList[k].TargetStart - alignList[k-1].TargetEnd - 1; p++) 
								strcat(outAlign.TargetString, ".");
							strcat(outAlign.TargetString, alignList[k].TargetString);
						}
						strcpy(outAlign.QueryString, alignList[i].QueryString);
						for (k=i+1; k<=j; k++) { 
							for (p=0; p<alignList[k].TargetStart - alignList[k-1].TargetEnd - 1; p++)
								strcat(outAlign.QueryString, ".");
							strcat(outAlign.QueryString, alignList[k].QueryString);
						}
						//break;
					}
				}
			} else { // for the minus strand
				if (i > 0 && (strcmp(cand.chr, alignList[i-1].TargetChr) || (!strcmp(cand.chr, alignList[i-1].TargetChr) && 
				alignList[i-1].TargetStart < alignList[i].TargetEnd) || alignList[i-1].TargetStart > cand.MAX_ENST_InitEnd)) { 
					if ((cand.MAX_ENST_InitStart <= alignList[i].TargetStart && alignList[i].TargetStart <= cand.MAX_ENST_InitEnd) ||
					(cand.MAX_ENST_InitStart <= alignList[i].TargetEnd && alignList[i].TargetEnd <= cand.MAX_ENST_InitEnd) || 
					(alignList[i].TargetStart <= cand.MAX_ENST_InitStart && cand.MAX_ENST_InitEnd <= alignList[i].TargetEnd)) {
						flagOverlap = 1;
						flagJointCoverExist = 1;
					} else continue;
					CoverLen = OverLapNovelLen(cand, alignList[i].TargetStart, alignList[i].TargetEnd);
					if (CoverLen <= MaxCoverLen) continue;
					else { 
						if (MaxCoverLen > 0) { 
							free(outAlign.TargetString);
							free(outAlign.QueryString);
						}
						MaxCoverLen = CoverLen;
					}
					tmpLen = strlen(alignList[i].TargetString);
					strcpy(outAlign.TargetChr, alignList[i].TargetChr);
					outAlign.TargetStart = alignList[i].TargetStart;
					outAlign.TargetEnd = alignList[i].TargetEnd;
					outAlign.TargetStrand = alignList[i].TargetStrand;
					strcpy(outAlign.QueryTag, alignList[i].QueryTag);
					outAlign.QueryStart = alignList[i].QueryStart;
					outAlign.QueryEnd = alignList[j].QueryEnd;
					outAlign.QueryStrand = alignList[i].QueryStrand;
					outAlign.TargetString = (char *)malloc((sizeof(char) * (tmpLen+1)));
					outAlign.QueryString = (char *)malloc((sizeof(char) * (tmpLen+1)));
					strcpy(outAlign.TargetString, alignList[i].TargetString);
					strcpy(outAlign.QueryString, alignList[i].QueryString);
					//printf("## FAKE JOINT COVER ##\n ## (-) alignList[%d].TargetStart = %d, alignList[%d].TargetEnd = %d ##\n", // for checking
					//i, alignList[i].TargetStart, i, alignList[i].TargetEnd); // for checking
				} else { 
					//printf("## (-) alignList[%d].TargetStart = %d, alignList[%d].TargetEnd = %d ##\n", i, alignList[i].TargetStart, // for checking
					//i, alignList[i].TargetEnd); // for checking
					for (j=i-1; j>=0; j--) { 
						if (!strcmp(cand.chr, alignList[j].TargetChr) && !strcmp(cand.MAX_EST, alignList[j].QueryTag) && 
						alignList[j].TargetStrand == '-' && cand.MAX_ENST_InitStart <= alignList[j].TargetEnd) { 
							//printf("## alignList[%d].TargetStart = %d, alignList[%d].TargetEnd = %d ##\n", j, // for checking
							//alignList[j].TargetStart, j, alignList[j].TargetEnd); // for checking
							if (cand.strand == alignList[i].TargetStrand) { 
								//printf("# Joint #\n"); 
								//return RevAlign(alignList[j], 0);
							} else { 
								//printf("# Joint (EXCEPT STRAND) #\n");
								//return RevAlign(alignList[j], 1);
							}
							flagJointCoverFound = 1;
							//break;
						} 
						if (strcmp(cand.chr, alignList[j].TargetChr) || alignList[j].TargetStrand != '-' || 
						(!strcmp(cand.chr, alignList[j].TargetChr) && (alignList[j].TargetStart > cand.MAX_ENST_InitEnd || 
						alignList[j].TargetStart < alignList[j+1].TargetEnd)) ) { 
							//flagJointCoverFound = 1;
							j++;
							break;
						}
						//if (alignList[j-1].TargetStart < alignList[j].TargetEnd) break;
					}
					if (flagJointCoverFound == 1) { 
	                                       for (k=i; k>=j; k--) {
        	                                        if ((cand.MAX_ENST_InitStart <= alignList[k].TargetStart && alignList[k].TargetStart <= cand.MAX_ENST_InitEnd) ||
                	                                (cand.MAX_ENST_InitStart <= alignList[k].TargetEnd && alignList[k].TargetEnd <= cand.MAX_ENST_InitEnd) ||
                        	                        (alignList[k].TargetStart <= cand.MAX_ENST_InitStart && cand.MAX_ENST_InitEnd <= alignList[k].TargetEnd)) {
                                	                        flagOverlap = 1;
	                                                        break;
        	                                        }
                	                        }
                        	                if (flagOverlap != 1) continue; 
                                	        flagJointCoverExist = 1;
	
        	                                for (k=i; k>=j; k--) CoverLen += OverLapNovelLen(cand, alignList[k].TargetStart, alignList[k].TargetEnd);
                	                        if (CoverLen <= MaxCoverLen) continue;
                        	                else {
                                	                if (MaxCoverLen > 0) {
                                        	                free(outAlign.TargetString);
                                                	        free(outAlign.QueryString);
                                               		}
	                                                MaxCoverLen = CoverLen;
        	                                }
	
						tmpLen = strlen(alignList[j].TargetString);	
						for (k=j+1; k<=i; k++) { 
							tmpLen += strlen(alignList[k].TargetString);
							tmpLen += alignList[k-1].TargetStart - alignList[k].TargetEnd - 1;
						}
						strcpy(outAlign.TargetChr, alignList[i].TargetChr); 
						outAlign.TargetStart = alignList[i].TargetStart;
						outAlign.TargetEnd = alignList[j].TargetEnd;
						outAlign.TargetStrand = alignList[i].TargetStrand;
						strcpy(outAlign.QueryTag, alignList[i].QueryTag); 
						if (alignList[i].QueryStrand == '+') { 
							outAlign.QueryStart = alignList[j].QueryStart;
							outAlign.QueryEnd = alignList[i].QueryEnd;
						} else { 
							outAlign.QueryStart = alignList[i].QueryStart;
							outAlign.QueryEnd = alignList[j].QueryEnd;
						}
						outAlign.QueryStrand = alignList[i].QueryStrand;
						outAlign.TargetString = (char *)malloc((sizeof(char) * (tmpLen+1)));
						outAlign.QueryString = (char *)malloc((sizeof(char) * (tmpLen+1)));
						strcpy(outAlign.TargetString, alignList[j].TargetString);
						for (k=j+1; k<=i; k++) { 
							for (p=0; p<alignList[k-1].TargetStart - alignList[k].TargetEnd - 1; p++) 
								strcat(outAlign.TargetString, ".");
							strcat(outAlign.TargetString, alignList[k].TargetString);
						}
						strcpy(outAlign.QueryString, alignList[j].QueryString);
						for (k=j+1; k<=i; k++) { 
							for (p=0; p<alignList[k-1].TargetStart - alignList[k].TargetEnd - 1; p++)
								strcat(outAlign.QueryString, ".");
							strcat(outAlign.QueryString, alignList[k].QueryString);
						}
						//break;
					}
				}
			} 
		}
	}
	if (flagJointCoverExist == 1) { 
		if (cand.strand == outAlign.TargetStrand) { 
			return outAlign;
		} else {
			outRevAlign = RevAlign(outAlign, 1);
			free(outAlign.TargetString);
			free(outAlign.QueryString);
			return outRevAlign;
		}
	}
	fprintf(stderr, "** Possibly error here **\n");
	return outAlign;
}

ALIGNMENT RevAlign(ALIGNMENT intAlign, int isRev)
{
	int i = 0;
	int len = strlen(intAlign.TargetString);
	ALIGNMENT outAlign = { "", 0, 0, '*', 0, "", "", 0, 0, '*', 0, "" };
	outAlign.TargetString = (char *)malloc(sizeof(char) * (len+1));
	outAlign.QueryString = (char *)malloc(sizeof(char) * (len+1));

	if (isRev == 0) {
		strcpy(outAlign.TargetChr, intAlign.TargetChr);
		outAlign.TargetStart = intAlign.TargetStart;
		outAlign.TargetEnd = intAlign.TargetEnd;
		outAlign.TargetStrand = intAlign.TargetStrand;
		strcpy(outAlign.TargetString, intAlign.TargetString);
		strcpy(outAlign.QueryTag, intAlign.QueryTag);
		outAlign.QueryStart = intAlign.QueryStart;
		outAlign.QueryEnd = intAlign.QueryEnd;
		outAlign.QueryStrand = intAlign.QueryStrand;
		strcpy(outAlign.QueryString, intAlign.QueryString);
	} else {
		if (intAlign.TargetStrand == '+') outAlign.TargetStrand = '-';
		else outAlign.TargetStrand = '+';
		if (intAlign.QueryStrand == '+') outAlign.QueryStrand = '-';
		else outAlign.QueryStrand = '+';
		strcpy(outAlign.TargetChr, intAlign.TargetChr);
		strcpy(outAlign.QueryTag, intAlign.QueryTag);
		outAlign.TargetStart = intAlign.TargetStart;
		outAlign.TargetEnd = intAlign.TargetEnd;
		outAlign.QueryStart = intAlign.QueryStart;
		outAlign.QueryEnd = intAlign.QueryEnd;
		for (i=0; i<len; i++) outAlign.TargetString[i] = NucCompl(intAlign.TargetString[len-1-i]);
		outAlign.TargetString[len] = '\0';
		for (i=0; i<len; i++) outAlign.QueryString[i] = NucCompl(intAlign.QueryString[len-1-i]);
		outAlign.QueryString[len] = '\0';
	}	
	return outAlign;
}


int AlignCutOut(CANDIDATE *cand, int numNovel, ALIGNMENT goalAlign)
{
	int i = 0, j = 0, k = 0, l = 0; 
	int alignLen = strlen(goalAlign.TargetString);
	int tmpCodingBegin = 0;
	int refinedLen = 0;
	int tmpPhase = 0;
	int *relCasLen; 
	int *relCasStart;
	int *relCasEnd;
	int relRetLen;
	int relRetStart;
	int relRetEnd;
	int *IS_PRINT; 
	char *RefinedTargetString; 
	char *RefinedQueryString;
	int matchBases = 0;
	int totalBases = 0;
	int novelLen = 0;

	REGION *exons, intron;
	
	if (!strcmp(cand[0].Label, "NOVEL")) { 
		exons = (REGION *)malloc(sizeof(REGION) * numNovel);
		relCasLen = (int *)malloc(sizeof(int) * numNovel);
		relCasStart = (int *)malloc(sizeof(int) * numNovel);
		relCasEnd = (int *)malloc(sizeof(int) * numNovel);

		for (i=0; i<numNovel; i++) { 
			exons[i].start = cand[i].start;
			exons[i].end = cand[i].end;
			novelLen += (cand[i].end - cand[i].start + 1);
		}

		if (cand[0].strand == '+') { 
			if (exons[0].start < goalAlign.TargetStart) { 
				tmpPhase = (cand[0].phase + goalAlign.TargetStart - exons[0].start)%3;
				novelLen -= (goalAlign.TargetStart - exons[0].start);
				exons[0].start = goalAlign.TargetStart;
			} else tmpPhase = cand[0].phase;

			exons[0].start += ((3-tmpPhase)%3);
			novelLen -= ((3-tmpPhase)%3);
			exons[numNovel-1].end -= (novelLen%3);
			novelLen -= (novelLen%3);
			
			for (i=0; i<numNovel; i++) { 
				relCasLen[i] = exons[i].end - exons[i].start + 1;
				relCasStart[i] = exons[i].start - goalAlign.TargetStart;
				relCasEnd[i] = exons[i].end - goalAlign.TargetStart;
				//printf("relCasStart[%d] = %d, relCasEnd[%d] = %d \t", i, relCasStart[i], i, relCasEnd[i]); // for checking
			}
			//printf("\n\n"); // for checking
		} else { 
			if (exons[0].end > goalAlign.TargetEnd) { 
				tmpPhase = (cand[0].phase + exons[0].end - goalAlign.TargetEnd)%3;
				novelLen -= (exons[0].end - goalAlign.TargetEnd);
				exons[0].end = goalAlign.TargetEnd;
			} else tmpPhase = cand[0].phase;

			exons[0].end -= ((3-tmpPhase)%3);
			novelLen -= ((3-tmpPhase)%3);
			exons[numNovel-1].start += (novelLen%3);
			novelLen -= (novelLen%3);

			for (i=0; i<numNovel; i++) { 
				relCasLen[i] = exons[i].end - exons[i].start + 1;
				relCasStart[i] = goalAlign.TargetEnd - exons[i].end;
				relCasEnd[i] = goalAlign.TargetEnd - exons[i].start;
				//printf("relCasStart[%d] = %d, relCasEnd[%d] = %d \t", i, relCasStart[i], i, relCasEnd[i]); // for checking
			}
			//printf("\n\n"); // for checking
		}
		for (i=0; i<numNovel; i++) refinedLen += relCasLen[i];
		//if (refinedLen != novelLen) fprintf(stderr, "** refinedLen == %d  != novelLen == %d **\n", refinedLen, novelLen); // for checking

		RefinedTargetString = (char *)malloc(sizeof(char) * (refinedLen + 1));
		RefinedQueryString =  (char *)malloc(sizeof(char) * (refinedLen + 1));
		IS_PRINT = (int *)malloc(sizeof(int) * refinedLen);
		for (i=0; i<refinedLen; i++) { 
			IS_PRINT[i] = 1;
			RefinedTargetString[i] = 'q';
			RefinedQueryString[i] = 'q';
		}

		l = 0; // count the bases of the chopped (final) sequence
		for (k=0; k<numNovel; k++) { 
			j = 0; // count the non-gap bases
			for (i=0; i<alignLen; i++) {
				if (l < refinedLen) {
					if (goalAlign.TargetString[i] != '-') {
						if (j <= relCasEnd[k] && j >= relCasStart[k]) {
							RefinedTargetString[l] = goalAlign.TargetString[i];
							RefinedQueryString[l] = goalAlign.QueryString[i];
							//if (goalAlign.TargetString[i] == goalAlign.QueryString[i]) matchBases++;
							//totalBases++;
							l++;
						}
						j++;
					} 
				} else break;
			}
		}

		RefinedTargetString[refinedLen] = '\0';
		RefinedQueryString[refinedLen] = '\0';
		//printf("RefinedTargetString:\n%s\nRefinedQueryString:\n%s\n\n", RefinedTargetString, RefinedQueryString); // for checking

		for (i=0; i<refinedLen-2; i+=3) { 
			if (RefinedQueryString[i] == '-' || RefinedQueryString[i+1] == '-' || RefinedQueryString[i+2] == '-' || 
			RefinedTargetString[i] == '-' || RefinedTargetString[i+1] == '-' || RefinedTargetString[i+2] == '-' || 
			RefinedTargetString[i] == '.' || RefinedTargetString[i+1] == '.' || RefinedTargetString[i+2] == '.' || 
			RefinedQueryString[i] == '.' || RefinedQueryString[i+1] == '.' || RefinedQueryString[i+2] == '.' || 
			RefinedTargetString[i] == 'q' || RefinedTargetString[i+1] == 'q' || RefinedTargetString[i+2] == 'q' || 
			RefinedQueryString[i] == 'q' || RefinedQueryString[i+1] == 'q' || RefinedQueryString[i+2] == 'q' || 
			((RefinedTargetString[i] == 't' || RefinedTargetString[i] == 'T') && (RefinedTargetString[i+1] == 'a' || RefinedTargetString[i+1] == 'A' ) && 
			(RefinedTargetString[i+2] == 'g'|| RefinedTargetString[i+2] == 'G' || RefinedTargetString[i+2] == 'a' || RefinedTargetString[i+2] == 'A')) || 
			((RefinedTargetString[i] == 't' || RefinedTargetString[i] == 'T') && (RefinedTargetString[i+1] == 'g' || RefinedTargetString[i+1] == 'G' ) && 
			(RefinedTargetString[i+2] == 'a'|| RefinedTargetString[i+2] == 'A')) || 
			((RefinedQueryString[i] == 't' || RefinedQueryString[i] == 'T') && (RefinedQueryString[i+1] == 'a' || RefinedQueryString[i+1] == 'A' ) && 
			(RefinedQueryString[i+2] == 'g'|| RefinedQueryString[i+2] == 'G' || RefinedQueryString[i+2] == 'a' || RefinedQueryString[i+2] == 'A')) || 
			((RefinedQueryString[i] == 't' || RefinedQueryString[i] == 'T') && (RefinedQueryString[i+1] == 'g' || RefinedQueryString[i+1] == 'G' ) && 
			(RefinedQueryString[i+2] == 'a'|| RefinedQueryString[i+2] == 'A')) ) { 
				IS_PRINT[i] = 0;
				IS_PRINT[i+1] = 0;
				IS_PRINT[i+2] = 0;
			}
		}

		for (i=0; i<refinedLen; i++) {
			if (IS_PRINT[i] != 0) {
				if (RefinedTargetString[i] == RefinedQueryString[i]) matchBases++;
				totalBases++;
			}
		}
		printf(">%s_", cand[0].chr);
		if (numNovel == 1) printf("%d_%d_%c_%s_identity=%2.2f_length=%d\n", cand[0].start, cand[0].end, cand[0].strand, cand[0].Label, (float)matchBases/(float)totalBases, totalBases);
		else { 
			for (i=0; i<numNovel; i++) printf("%d_%d_", cand[i].start, cand[i].end);
			printf("%c_%s_identity=%2.2f_length=%d\n", cand[0].strand, cand[0].Label, (float)matchBases/(float)totalBases, totalBases);
		}
		for (i=0; i<refinedLen; i++) { 
			if (IS_PRINT[i] != 0) printf("%c", RefinedTargetString[i]);
		}
		printf("\n");
		printf(">%s_%c\n", cand[0].MAX_EST, goalAlign.QueryStrand);
		for (i=0; i<refinedLen; i++) { 
			if (IS_PRINT[i] != 0) printf("%c", RefinedQueryString[i]);
		}
		printf("\n\n");

                free(relCasLen);
                free(relCasStart);
                free(relCasEnd);
		free(IS_PRINT);
		free(RefinedTargetString);
		free(RefinedQueryString);
		free(exons);
	} else if (!strcmp(cand[0].Label, "RETAIN")) { 
		if (cand[0].strand == '+') {
			if (cand[0].MAX_ENST_AdjStart < cand[0].CDSstart) tmpCodingBegin = cand[0].CDSstart;
			else tmpCodingBegin = cand[0].MAX_ENST_AdjStart + ((3-cand[0].phase)%3); 
		} else {
			if (cand[0].CDSend < cand[0].MAX_ENST_AdjEnd) tmpCodingBegin = cand[0].CDSend;
			else tmpCodingBegin = cand[0].MAX_ENST_AdjEnd - ((3-cand[0].phase)%3);
		}
		//printf("** tmpCodingBegin = %d (cand[0].CDSstart = %d, cand[0].CDSend = %d; TargetStart = %d, TargetEnd = %d) **\n", tmpCodingBegin, cand[0].CDSstart, cand[0].CDSend, goalAlign.TargetStart, goalAlign.TargetEnd); // for checking

		intron.start = cand[0].frontFlankEnd + 1;
		intron.end = cand[0].rearFlankStart - 1;
		
		//printf("=> (intron)  %s\t%d\t%d\t%c\t", cand[0].chr, intron.start, intron.end, cand[0].strand); // for checking

		if (cand[0].strand == '+') { 
			intron.start += ((3-(intron.start - tmpCodingBegin)%3)%3);
			intron.end -= ((intron.end - intron.start + 1)%3);

			//printf("intron => %s\t%d\t%d\t%c\t", cand[0].chr, intron.start, intron.end, cand[0].strand); // for checking

			if (intron.end - intron.start + 1 > 2) { // Just in case that the intron is too short to analyze
				relRetLen = intron.end - intron.start + 1;
				relRetStart = intron.start - goalAlign.TargetStart;
				relRetEnd = intron.end - goalAlign.TargetStart;
				//printf("relRetStart = %d, relRetEnd = %d\n", relRetStart, relRetEnd); // for checking
			} else {
				relRetLen = 0;
				relRetStart = -1;
				relRetEnd = -1;
			}
		} else { 
			intron.end -= ((3-(tmpCodingBegin - intron.end)%3)%3);
			intron.start += ((intron.end - intron.start + 1)%3);

			//printf("intron => %s\t%d\t%d\t%c\t", cand[0].chr, intron.start, intron.end, cand[0].strand); // for checking 

			if (intron.end - intron.start + 1 > 2) { // Just in case that the intron is too short to analyze 
				relRetLen = intron.end - intron.start + 1;
				relRetStart = goalAlign.TargetEnd - intron.end;
				relRetEnd = goalAlign.TargetEnd - intron.start;
				//printf("relRetStart = %d, relRetEnd = %d\n", relRetStart, relRetEnd); // for checking
			} else {
				relRetLen = 0;
				relRetStart = -1;
				relRetEnd = -1;
			}
		}

		RefinedTargetString = (char *)malloc(sizeof(char) * (relRetLen + 1));
		RefinedQueryString =  (char *)malloc(sizeof(char) * (relRetLen + 1));
		IS_PRINT = (int *)malloc(sizeof(int) * relRetLen);
		for (i=0; i<relRetLen; i++) { 
			IS_PRINT[i] = 1;
			RefinedTargetString[i] = 'q';
			RefinedQueryString[i] = 'q';
		}
		//printf("retained => %s\t%d\t%d\t%c\n", cand[0].chr, cand[0].start, cand[0].end, cand[0].strand); // for checking

		l = 0; // count the bases of the chopped (final) sequence
		j = 0; // count the non-gap bases
		for (i=0; i<alignLen; i++) {
			if (l < relRetLen) {
				if (goalAlign.TargetString[i] != '-') {
					if (j <= relRetEnd && j >= relRetStart) {
						RefinedTargetString[l] = goalAlign.TargetString[i];
						RefinedQueryString[l] = goalAlign.QueryString[i];
						//if (goalAlign.TargetString[i] == goalAlign.QueryString[i]) matchBases++;
						//totalBases++;
						l++;
					}
					j++;
				} 
			} else break;
		}
		RefinedTargetString[relRetLen] = '\0';
		RefinedQueryString[relRetLen] = '\0';
		//printf("RefinedTargetString:\n%s\nRefinedQueryString:\n%s\n\n", RefinedTargetString, RefinedQueryString); // for checking

		for (i=0; i<relRetLen-2; i+=3) { 
			if (RefinedQueryString[i] == '-' || RefinedQueryString[i+1] == '-' || RefinedQueryString[i+2] == '-' || 
			RefinedTargetString[i] == '.' || RefinedTargetString[i+1] == '.' || RefinedTargetString[i+2] == '.' || 
			RefinedTargetString[i] == 'q' || RefinedTargetString[i+1] == 'q' || RefinedTargetString[i+2] == 'q' || 
			((RefinedTargetString[i] == 't' || RefinedTargetString[i] == 'T') && (RefinedTargetString[i+1] == 'a' || RefinedTargetString[i+1] == 'A' ) && 
			(RefinedTargetString[i+2] == 'g'|| RefinedTargetString[i+2] == 'G' || RefinedTargetString[i+2] == 'a' || RefinedTargetString[i+2] == 'A')) || 
			((RefinedTargetString[i] == 't' || RefinedTargetString[i] == 'T') && (RefinedTargetString[i+1] == 'g' || RefinedTargetString[i+1] == 'G' ) && 
			(RefinedTargetString[i+2] == 'a'|| RefinedTargetString[i+2] == 'A')) || 
			((RefinedQueryString[i] == 't' || RefinedQueryString[i] == 'T') && (RefinedQueryString[i+1] == 'a' || RefinedQueryString[i+1] == 'A' ) && 
			(RefinedQueryString[i+2] == 'g'|| RefinedQueryString[i+2] == 'G' || RefinedQueryString[i+2] == 'a' || RefinedQueryString[i+2] == 'A')) || 
			((RefinedQueryString[i] == 't' || RefinedQueryString[i] == 'T') && (RefinedQueryString[i+1] == 'g' || RefinedQueryString[i+1] == 'G' ) && 
			(RefinedQueryString[i+2] == 'a'|| RefinedQueryString[i+2] == 'A')) ) { 
				IS_PRINT[i] = 0;
				IS_PRINT[i+1] = 0;
				IS_PRINT[i+2] = 0;
			}
		}

		for (i=0; i<relRetLen; i++) {
			if (IS_PRINT[i] != 0) {
				if (RefinedTargetString[i] == RefinedQueryString[i]) matchBases++;
				totalBases++;
			}
		}
		printf(">%s_%d_%d_%c_%s_identity=%2.2f_length=%d\n", cand[0].chr, cand[0].frontFlankEnd + 1, cand[0].rearFlankStart - 1, cand[0].strand, cand[0].Label, (float)matchBases/(float)totalBases, totalBases);
		for (i=0; i<relRetLen; i++) { 
			if (IS_PRINT[i] != 0) printf("%c", RefinedTargetString[i]);
		}
		printf("\n");
		printf(">%s_%c\n", cand[0].MAX_EST, goalAlign.QueryStrand);
		for (i=0; i<relRetLen; i++) { 
			if (IS_PRINT[i] != 0) printf("%c", RefinedQueryString[i]);
		}
		printf("\n\n");

		free(IS_PRINT);
		free(RefinedTargetString);
		free(RefinedQueryString);
	} 
	
	//if (!strcmp(cand[0].Label, "NOVEL")) free(exons); 
	return 0;
}

int OverLapNovelLen(CANDIDATE cand, int rStart, int rEnd)
{
        int len = 0;
        int overStart = 0, overEnd = 0;

        if (rStart <= cand.MAX_ENST_InitStart) {
                overStart = cand.MAX_ENST_InitStart;
                if (cand.MAX_ENST_InitStart <= rEnd) {
                        if (rEnd <= cand.MAX_ENST_InitEnd) overEnd = rEnd;
                        else overEnd = cand.MAX_ENST_InitEnd;
                        len = overEnd - overStart + 1;
                }
        } else if (rStart <= cand.MAX_ENST_InitEnd) {
                overStart = rStart;
                if (rEnd <= cand.MAX_ENST_InitEnd) overEnd = rEnd;
                else overEnd = cand.MAX_ENST_InitEnd;
                len = overEnd - overStart + 1;
        }
        return len;
}

char NucCompl(char ch) 
{
	switch (ch) {
		case 'a': 
			return 't';
		case 'A':
			return 'T';
		case 'c':
			return 'g';
		case 'C':
			return 'G';
		case 'g': 
			return 'c';
		case 'G':
			return 'C';
		case 't':
			return 'a';
		case 'T':
			return 'A';
		case '-':
			return '-';
		case '.': 
			return '.';
		default:
			return '-';
	}
}

