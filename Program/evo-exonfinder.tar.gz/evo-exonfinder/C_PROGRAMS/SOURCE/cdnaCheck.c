#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SHIFT 10

int flagFound = 0;
int flagExclude = 0;

typedef struct map_result {
        char overlap_type[50];
        int length;
        float percent;
        int frontExt;
        int rearExt;
} MAP_RESULT;

typedef struct raw_candidate {
        char Label[10];
        char chr[50];
        int start;
        int end;
        char strand[2];
        char ENSTID[50];
        char ESTID[50];
        int EST_start;
        int EST_end;
        int map_score; // newly added
        int MAP_COUNT;
        MAP_RESULT *mapList;
} CANDIDATE;

typedef struct cdna_excluded_candidate {
	char ESTID[50]; 
	int EST_start; 
	int EST_end; 
	char ENSTID[100];
	int ENST_start; 
	int ENST_end;
} CDNA_EXCLUDE;

int main(int argc, char **argv)
{
	FILE *candFile, *exFile;
	int i = 0, j = 0;
	int countExclude = 0;
	int countMap = 0;
	int OverlapLen = 0;
	int scanVal = 0;
	CANDIDATE entry; 
	CDNA_EXCLUDE ex_entry; 
	CDNA_EXCLUDE *EX_ARR;
	

	if (argc != 3) { 
		fprintf(stderr, "Usage:\n\tcdnaCheck [RAW_CANDIDATES] [CANDIDATES_TO_BE_EXCLUDED]\n\n");
		fprintf(stderr, "\t[RAW_CANDIDATES] contains fields of label, chr, start, end, strand, ENST-ID, EST-ID, EST-start, EST-end, EST_mapping score, mapping result(s).\n");
		fprintf(stderr, "\t[CANDIDATES_TO_BE_EXCLUDED] contains fields of Read-Tag, Read start, Read end, ENST-ID, ENST-start, ENST-end.\n\n");
		exit(EXIT_FAILURE);
	}

	if ((candFile = fopen(argv[1], "r")) == NULL) {
		printf("Error in opening %s.\n", argv[1]);
		exit(EXIT_FAILURE);
	}

	if ((exFile = fopen(argv[2], "r")) == NULL) {
		printf("Error in opening %s.\n", argv[2]);
		exit(EXIT_FAILURE);
	}
	while (fscanf(exFile, "%s %d %d %s %d %d", ex_entry.ESTID, &ex_entry.EST_start, &ex_entry.EST_end, ex_entry.ENSTID, 
	&ex_entry.ENST_start, &ex_entry.ENST_end) != EOF) { // To obtain the number of excluded blocks
		countExclude++;
	}
	fseek(exFile, 0, SEEK_SET);
	
	EX_ARR = (CDNA_EXCLUDE *)malloc(sizeof(CDNA_EXCLUDE) * countExclude);

	while (fscanf(exFile, "%s %d %d %s %d %d", EX_ARR[i].ESTID, &EX_ARR[i].EST_start, &EX_ARR[i].EST_end, EX_ARR[i].ENSTID, 
	&EX_ARR[i].ENST_start, &EX_ARR[i].ENST_end) != EOF) { // To obtain the number of excluded blocks
		i++;
	}
	fclose(exFile);

	while (fscanf(candFile, "%s %s %d %d %s %s %s %d %d %d %d", entry.Label, entry.chr, &entry.start, &entry.end, entry.strand, 
	entry.ENSTID, entry.ESTID, &entry.EST_start, &entry.EST_end, &entry.map_score, &entry.MAP_COUNT) != EOF) { // scanning candidates 
		if (entry.MAP_COUNT == 0) countMap = 1; 
		else countMap = entry.MAP_COUNT; 
		entry.mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT) * countMap);
		if (entry.mapList == NULL) {
			fprintf(stderr, "** Memory allocation error for the candidates **\n");
			exit(EXIT_FAILURE);
		}
		for (j=0; j<countMap; j++) {
			scanVal = fscanf(candFile, "%s %d %f %d %d", entry.mapList[j].overlap_type, &entry.mapList[j].length,
			&entry.mapList[j].percent, &entry.mapList[j].frontExt, &entry.mapList[j].rearExt);
			if (scanVal != 5) fprintf(stderr, " ** File reading error in cdnaCheck **\n");
		}
		for (i=0; i<countExclude; i++) { 
			if (!strcmp(entry.ESTID, EX_ARR[i].ESTID)) { 
				flagFound = 1;
				if (!strcmp(entry.Label, "RETAIN")) { // filtering false-positive novel retained introns
					if (entry.EST_start - EX_ARR[i].EST_start <= SHIFT && EX_ARR[i].EST_start - entry.EST_start <= SHIFT && 
					entry.EST_end - EX_ARR[i].EST_end <= SHIFT && EX_ARR[i].EST_end - entry.EST_end <= SHIFT) { 
						if (!strcmp(entry.ENSTID, EX_ARR[i].ENSTID)) {
							fprintf(stderr, "%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d", entry.Label, entry.chr, entry.start, entry.end, 
							entry.strand, entry.ENSTID, entry.ESTID, entry.EST_start, entry.EST_end, entry.map_score, entry.MAP_COUNT);
							for (i=0; i<countMap; i++) {
								fprintf(stderr, "\t%s\t%d\t%1.4f\t%d\t%d", entry.mapList[i].overlap_type, entry.mapList[i].length, 
								entry.mapList[i].percent, entry.mapList[i].frontExt, entry.mapList[i].rearExt);
							}
							fprintf(stderr, "\n");
							//fprintf(stderr, "due to %s\t%d\t%d **\n", EX_ARR[i].ESTID, EX_ARR[i].EST_start, EX_ARR[i].EST_end); 
						}
						flagExclude = 1;
						break;
					}
				} else if (!strcmp(entry.Label, "NOVEL")) {  // filtering false-positive novel internal exons
					if (EX_ARR[i].EST_start <= entry.EST_start && entry.EST_start <= EX_ARR[i].EST_end && EX_ARR[i].EST_end <= entry.EST_end) {
						OverlapLen = EX_ARR[i].EST_end - entry.EST_start + 1;
					} else if (entry.EST_start <= EX_ARR[i].EST_start && EX_ARR[i].EST_start <= entry.EST_end && entry.EST_end <= EX_ARR[i].EST_end) { 
						OverlapLen = entry.EST_end - EX_ARR[i].EST_start + 1;
					} else if (EX_ARR[i].EST_start <= entry.EST_start && entry.EST_end <= EX_ARR[i].EST_end) { 
						OverlapLen = entry.EST_end - entry.EST_start + 1;
					} else if (entry.EST_start <= EX_ARR[i].EST_start && EX_ARR[i].EST_end <= entry.EST_end) {
						OverlapLen = EX_ARR[i].EST_end - EX_ARR[i].EST_start + 1;
					} else OverlapLen = 0;
					if ((float)OverlapLen/(float)(EX_ARR[i].EST_end - EX_ARR[i].EST_start + 1) > 0.5) { 
						if (!strcmp(entry.ENSTID, EX_ARR[i].ENSTID)) { 
							fprintf(stderr, "%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d", entry.Label, entry.chr, entry.start, entry.end, 
							entry.strand, entry.ENSTID, entry.ESTID, entry.EST_start, entry.EST_end, entry.map_score, entry.MAP_COUNT);
							for (i=0; i<countMap; i++) { 
								fprintf(stderr, "\t%s\t%d\t%1.4f\t%d\t%d", entry.mapList[i].overlap_type, entry.mapList[i].length, 
								entry.mapList[i].percent, entry.mapList[i].frontExt, entry.mapList[i].rearExt);
							}
							fprintf(stderr, "\n");
							//fprintf(stderr, "due to %s\t%d\t%d **\n", EX_ARR[i].ESTID, EX_ARR[i].EST_start, EX_ARR[i].EST_end); 
						}
						flagExclude = 1;
						break;
					} 
				}
			}
		}
		if (flagFound == 0 || (flagFound == 1 && flagExclude == 0)) { 
			printf("%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d", entry.Label, entry.chr, entry.start, entry.end,
			entry.strand, entry.ENSTID, entry.ESTID, entry.EST_start, entry.EST_end, entry.map_score, entry.MAP_COUNT);
			for (i=0; i<countMap; i++) {
				printf("\t%s\t%d\t%1.4f\t%d\t%d", entry.mapList[i].overlap_type, entry.mapList[i].length, entry.mapList[i].percent, 
				entry.mapList[i].frontExt, entry.mapList[i].rearExt);
			}
			printf("\n");
		}
		flagExclude = 0;
		flagFound = 0; 
		free(entry.mapList);
	}
	free(EX_ARR);
	fclose(candFile);
	return 0;
}

