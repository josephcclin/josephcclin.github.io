#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define SHIFT 2

typedef struct map_result {
        char overlap_type[50];
        int length;
        float percent;
        int frontExt;
        int rearExt;
} MAP_RESULT;

typedef struct raw_candidate {
        char Label[10];	
	char signal[5];
        char chr[50];
        int start;
        int end;
        char strand[2];
        char ENSTID[50];
        char ESTID[50];
	int InitStart; // Initial start position of the ref. genome for dn/ds analysis
	int InitEnd; // Initial end position of the ref. genome for dn/ds analysis
        int EST_start;
        int EST_end;
	int map_score; 
        int MAP_COUNT;
        MAP_RESULT *mapList;
	int adjStart; 
	int adjEnd;
	int oriFrontExt;
	int oriRearExt;
	int novelLen;
} CANDIDATE;


void printBlock(CANDIDATE *block, int blockCount);

int main(int argc, char **argv)
{
	FILE *mbFile, *candFile, *cdnaFile;
	char buffer[1024];
	int blockCount = 0; 
	int mapCount = 0;
	int i = 0, j = 0, k = 0; 
	int SHIFT = 2;
	int flagCandidate = 0;
	int numCandidates = 0;
	int numCDNAexons = 0;
	int maxOverLen = 0;
	char tmpType[50] = "";
	float tmpPercent = 0.0000;
	int tmpFrontExt = 0;
	int tmpRearExt = 0;
	int progress = 0;
	CANDIDATE *CAND_ARR;
	CANDIDATE *CDNA_ARR;
	CANDIDATE *BLOCK;
	int scanfVal = 0;

	if (argc != 5) { 
		fprintf(stderr, "\n\t./BlockCorrect [RAW_MAPPABLE_BLOCKS] [SPLICING_CHECKED_CANDIDATES] [SPLICING_CHECKED_CDNA_FILTERED] [IS_INTER_SPECIES]\n\n");
		exit(EXIT_FAILURE);
	}
	if ((mbFile = fopen(argv[1], "r")) == NULL) { 
		fprintf(stderr, "** Cannot open %s. **\n", argv[1]);
		exit(EXIT_FAILURE);
	}
	if ((candFile = fopen(argv[2], "r")) == NULL) { 
		fprintf(stderr, "** Cannot open %s. **\n", argv[2]);
		exit(EXIT_FAILURE);
	}
	if ((cdnaFile = fopen(argv[3], "r")) == NULL) { 
		fprintf(stderr, "** Cannot open %s. **\n", argv[3]);
		exit(EXIT_FAILURE);
	}
	
	if (!strcmp(argv[4], "1")) SHIFT = 10; 
	else if (!strcmp(argv[4], "0")) SHIFT = 2; 
	else { 
		fprintf(stderr, "** [IS_INTER_SPECIES] is either 0 (for intra-species) or 1 (for inter-species) **\n"); 
		exit(EXIT_FAILURE);
	}

	while (fgets(buffer, 1024, candFile) != NULL) {
		numCandidates++;
	}
	CAND_ARR = (CANDIDATE *)malloc(sizeof(CANDIDATE) * numCandidates);
	fseek(candFile, 0, SEEK_SET);

	while (fgets(buffer, 1024, cdnaFile) != NULL) {
		numCDNAexons++;
	}
	CDNA_ARR = (CANDIDATE *)malloc(sizeof(CANDIDATE) * numCDNAexons);
	fseek(cdnaFile, 0, SEEK_SET);

	while (fscanf(candFile, "%s %s %s %d %d %s %s %s %d %d %d %d %d %d", CAND_ARR[i].Label, CAND_ARR[i].signal, CAND_ARR[i].chr, &CAND_ARR[i].start, 
	&CAND_ARR[i].end, CAND_ARR[i].strand, CAND_ARR[i].ENSTID, CAND_ARR[i].ESTID, &CAND_ARR[i].InitStart, &CAND_ARR[i].InitEnd, 
	&CAND_ARR[i].EST_start, &CAND_ARR[i].EST_end, &CAND_ARR[i].map_score, &CAND_ARR[i].MAP_COUNT) != EOF) {
		if (CAND_ARR[i].MAP_COUNT == 0) CAND_ARR[i].mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT));
		else CAND_ARR[i].mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT) * CAND_ARR[i].MAP_COUNT);
                if (CAND_ARR[i].mapList == NULL) {
                        fprintf(stderr, "** Memory allocation error for the candidates. **\n");
                        exit(EXIT_FAILURE);
                }
                if (CAND_ARR[i].MAP_COUNT > 0) {
                        for (j=0; j<CAND_ARR[i].MAP_COUNT; j++) {
                                scanfVal = fscanf(candFile, "%s %d %f %d %d", CAND_ARR[i].mapList[j].overlap_type, &CAND_ARR[i].mapList[j].length,
                                &CAND_ARR[i].mapList[j].percent, &CAND_ARR[i].mapList[j].frontExt, &CAND_ARR[i].mapList[j].rearExt);
				if (scanfVal != 5) fprintf(stderr, "** File reading error in BlockCorrect.c **\n");
                        }
                } else {
                        scanfVal = fscanf(candFile, "%s %d %f %d %d", CAND_ARR[i].mapList[0].overlap_type, &CAND_ARR[i].mapList[0].length,
                        &CAND_ARR[i].mapList[0].percent, &CAND_ARR[i].mapList[0].frontExt, &CAND_ARR[i].mapList[0].rearExt);
			if (scanfVal != 5) fprintf(stderr, "** File reading error in BlockCorrect.c **\n");
                }
		i++;
	}
	fclose(candFile);
	i = 0;

	while (fscanf(cdnaFile, "%s %s %s %d %d %s %s %s %d %d %d %d %d %d", CDNA_ARR[i].Label, CDNA_ARR[i].signal, CDNA_ARR[i].chr, 
	&CDNA_ARR[i].start, &CDNA_ARR[i].end, CDNA_ARR[i].strand, CDNA_ARR[i].ENSTID, CDNA_ARR[i].ESTID, &CDNA_ARR[i].InitStart, &CDNA_ARR[i].InitEnd, 
	&CDNA_ARR[i].EST_start, &CDNA_ARR[i].EST_end, &CDNA_ARR[i].map_score, &CDNA_ARR[i].MAP_COUNT) != EOF) {
		if (CDNA_ARR[i].MAP_COUNT == 0) CDNA_ARR[i].mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT));
		else CDNA_ARR[i].mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT) * CDNA_ARR[i].MAP_COUNT);
                if (CDNA_ARR[i].mapList == NULL) {
                        fprintf(stderr, "** Memory allocation error for the candidates. **\n");
                        exit(EXIT_FAILURE);
                }
                if (CDNA_ARR[i].MAP_COUNT > 0) {
                        for (j=0; j<CDNA_ARR[i].MAP_COUNT; j++) {
                                scanfVal = fscanf(cdnaFile, "%s %d %f %d %d", CDNA_ARR[i].mapList[j].overlap_type, &CDNA_ARR[i].mapList[j].length,
                                &CDNA_ARR[i].mapList[j].percent, &CDNA_ARR[i].mapList[j].frontExt, &CDNA_ARR[i].mapList[j].rearExt);
				if (scanfVal != 5) fprintf(stderr, "** File reading error in BlockCorrect.c **\n");
                        }
                } else {
                        scanfVal = fscanf(cdnaFile, "%s %d %f %d %d", CDNA_ARR[i].mapList[0].overlap_type, &CDNA_ARR[i].mapList[0].length,
                        &CDNA_ARR[i].mapList[0].percent, &CDNA_ARR[i].mapList[0].frontExt, &CDNA_ARR[i].mapList[0].rearExt);
			if (scanfVal != 5) fprintf(stderr, "** File reading error in BlockCorrect.c **\n");
                }
		i++;
	}
	fclose(cdnaFile);
	
	while (fscanf(mbFile, "%d", &blockCount) != EOF) { 
		BLOCK = (CANDIDATE *)malloc(sizeof(CANDIDATE) * blockCount);
		if (BLOCK == NULL) { 
			fprintf(stderr, "** Memory allocation error for a set of blocks. **\n");	
			exit(EXIT_FAILURE);
		}
		progress++;

		for (i=0; i<blockCount; i++) { 
			scanfVal = fscanf(mbFile, "%s %s %d %d %s %s %d %d %d %d %s", BLOCK[i].Label, BLOCK[i].chr, &BLOCK[i].start, &BLOCK[i].end, 
			BLOCK[i].strand, BLOCK[i].ESTID, &BLOCK[i].EST_start, &BLOCK[i].EST_end, &BLOCK[i].map_score, &BLOCK[i].MAP_COUNT, BLOCK[i].ENSTID);
			BLOCK[i].InitStart = BLOCK[i].start;
			BLOCK[i].InitEnd = BLOCK[i].end;
			if (BLOCK[i].MAP_COUNT == 0) mapCount = 1; 
			else mapCount = BLOCK[i].MAP_COUNT;
			BLOCK[i].mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT) * mapCount);
			if (BLOCK[i].mapList == NULL) { 
				fprintf(stderr, "** Memory allocation error for a block. **\n");
				exit(EXIT_FAILURE);
			}
			if (!strcmp(BLOCK[i].Label, "FLANK")) { 
				strcpy(BLOCK[i].signal, "pass");
			} else if (!strcmp(BLOCK[i].Label, "flank")) { 
				strcpy(BLOCK[i].signal, "miss");
			} else if (!strcmp(BLOCK[i].Label, "NOVEL")) { 
				strcpy(BLOCK[i].Label, "novel"); 
				strcpy(BLOCK[i].signal, "miss");
			} else if (!strcmp(BLOCK[i].Label, "RETAIN")) { 
				strcpy(BLOCK[i].Label, "retain");
				strcpy(BLOCK[i].signal, "miss");
			}
			if (scanfVal != 11) fprintf(stderr, "** File reading error in BlockCorrect.c **\n");
			for (j=0; j<mapCount; j++) scanfVal = fscanf(mbFile, "%s %d %f %d %d", BLOCK[i].mapList[j].overlap_type, &BLOCK[i].mapList[j].length, 
			&BLOCK[i].mapList[j].percent, &BLOCK[i].mapList[j].frontExt, &BLOCK[i].mapList[j].rearExt);
			if (scanfVal != 5) fprintf(stderr, "** File reading error in BlockCorrect.c **\n");

			for (k=0; k<numCandidates; k++) { // correct boundaries of candidates
				if (!strcmp(BLOCK[i].ESTID, CAND_ARR[k].ESTID) && !strcmp(BLOCK[i].ENSTID, CAND_ARR[k].ENSTID) && 
				!strcmp(BLOCK[i].chr, CAND_ARR[k].chr) && (!strcmp(BLOCK[i].Label, "novel") || (!strcmp(BLOCK[i].Label, "retain")))) { 
					if (BLOCK[i].start - CAND_ARR[k].start <= SHIFT && CAND_ARR[k].start - BLOCK[i].start <= SHIFT && 
					BLOCK[i].end - CAND_ARR[k].end <= SHIFT && CAND_ARR[k].end - BLOCK[i].end <= SHIFT && 
					CAND_ARR[k].end - CAND_ARR[k].start + 1 >= 50) { 
						strcpy(BLOCK[i].Label, CAND_ARR[k].Label);
						strcpy(BLOCK[i].signal, CAND_ARR[k].signal);
						BLOCK[i].start = CAND_ARR[k].start;
						BLOCK[i].end = CAND_ARR[k].end;
						BLOCK[i].EST_start = CAND_ARR[k].EST_start;
						BLOCK[i].EST_end = CAND_ARR[k].EST_end;
						for (j=0; j<mapCount; j++) {
							BLOCK[i].mapList[j].frontExt = CAND_ARR[k].mapList[j].frontExt;
							BLOCK[i].mapList[j].rearExt = CAND_ARR[k].mapList[j].rearExt;
						}
						break;
					}
				}
			}
			for (k=0; k<numCDNAexons; k++) { // Correct boundaries of cdna-filtered blocks
				if (!strcmp(BLOCK[i].ESTID, CDNA_ARR[k].ESTID) && !strcmp(BLOCK[i].ENSTID, CDNA_ARR[k].ENSTID) && 
				!strcmp(BLOCK[i].chr, CDNA_ARR[k].chr) && (!strcmp(BLOCK[i].Label, "novel") || (!strcmp(BLOCK[i].Label, "retain")))) { 
					if (BLOCK[i].start - CDNA_ARR[k].start <= SHIFT && CDNA_ARR[k].start - BLOCK[i].start <= SHIFT && 
					BLOCK[i].end - CDNA_ARR[k].end <= SHIFT && CDNA_ARR[k].end - BLOCK[i].end <= SHIFT && 
					CDNA_ARR[k].end - CDNA_ARR[k].start + 1 >= 50) { 
						strcpy(BLOCK[i].Label, "CDNA");
						strcpy(BLOCK[i].signal, CDNA_ARR[k].signal);
						BLOCK[i].start = CDNA_ARR[k].start;
						BLOCK[i].end = CDNA_ARR[k].end;
						BLOCK[i].EST_start = CDNA_ARR[k].EST_start;
						BLOCK[i].EST_end = CDNA_ARR[k].EST_end;
						for (j=0; j<mapCount; j++) {
							BLOCK[i].mapList[j].frontExt = CDNA_ARR[k].mapList[j].frontExt;
							BLOCK[i].mapList[j].rearExt = CDNA_ARR[k].mapList[j].rearExt;
						}
						break;
					}
				}
			} 
			if (!strcmp(BLOCK[i].Label, "FLANK") && mapCount > 1) { // Correct flanking exons with multiple mapping hits
				for (k=0; k<mapCount; k++) { 
					if (BLOCK[i].mapList[k].length > maxOverLen) { // Choose the mapping result with the maximum overlapping length
						maxOverLen = BLOCK[i].mapList[k].length;
						strcpy(tmpType, BLOCK[i].mapList[k].overlap_type);
						tmpPercent = BLOCK[i].mapList[k].percent;
						tmpFrontExt = BLOCK[i].mapList[k].frontExt;
						tmpRearExt = BLOCK[i].mapList[k].rearExt;
					}
				}
				free(BLOCK[i].mapList);
				BLOCK[i].mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT)); // replace the mapping result with the one of the maximum overlapping length
				if (BLOCK[i].mapList == NULL) { 
					fprintf(stderr, "** Memory re-allocation error for a set of blocks. **\n");
					exit(EXIT_FAILURE);
				}
				BLOCK[i].MAP_COUNT = 1;
				strcpy(BLOCK[i].mapList[0].overlap_type, tmpType);
				BLOCK[i].mapList[0].length = maxOverLen;
				BLOCK[i].mapList[0].percent = tmpPercent;
				BLOCK[i].mapList[0].frontExt = tmpFrontExt;
				BLOCK[i].mapList[0].rearExt = tmpRearExt;
				strcpy(tmpType, "");
				maxOverLen = 0;
				tmpPercent = 0.0000;
				tmpFrontExt = 0;
				tmpRearExt = 0;
			}
		}
		for (i=0; i<blockCount; i++) { // Keep the blocks having candidates and left the others behind
			if (!strcmp(BLOCK[i].Label, "NOVEL") || !strcmp(BLOCK[i].Label, "RETAIN")) { 
				flagCandidate = 1;
				break;
			}
		}
		if (flagCandidate == 1) printBlock(BLOCK, blockCount); 

		for (i=0; i<blockCount; i++) free(BLOCK[i].mapList); 
		free(BLOCK);
		flagCandidate = 0;	
		if (progress == 10000) fprintf(stderr, "\b\b\b25%%"); 
	}	

	for (i=0; i<numCandidates; i++) free(CAND_ARR[i].mapList);
	free(CAND_ARR);
	for (i=0; i<numCDNAexons; i++) free(CDNA_ARR[i].mapList);
	free(CDNA_ARR);
	fclose(mbFile);
	return 0;
}

void printBlock(CANDIDATE *block, int blockCount)
{
	int i = 0, j = 0, k = 0, l = 0; 
	//int adjStart = 0, adjEnd = 0;
	//int oriFrontExt = 0, oriRearExt = 0;
	int numAdjBlocks = 0;
	int tmpNovelLen = 0;
	int *IF_PRINT = (int *)malloc(sizeof(int) * blockCount);
	for (i=0; i<blockCount; i++) IF_PRINT[i] = 1; // initialization
	
	for (i=0; i<blockCount; i++) {
		if (!strcmp(block[i].Label, "FLANK")) { 
			block[i].adjStart = block[i].start + block[i].mapList[0].frontExt;
			block[i].adjEnd = block[i].end + block[i].mapList[0].rearExt;
			//block[i].oriFrontExt = -block[i].mapList[0].frontExt;
			//block[i].oriRearExt = -block[i].mapList[0].rearExt;
			block[i].novelLen = 0;
		} else if (!strcmp(block[i].Label, "RETAIN") || !strcmp(block[i].Label, "retain")) { 
			block[i].adjStart = block[i].start + block[i].mapList[0].frontExt;
			block[i].adjEnd = block[i].end + block[i].mapList[block[i].MAP_COUNT-1].rearExt;
			//block[i].oriFrontExt = -block[i].mapList[0].frontExt;
			//block[i].oriRearExt = -block[i].mapList[block[i].MAP_COUNT-1].rearExt;
			for (j=1; j<block[i].MAP_COUNT; j++) {
				tmpNovelLen += (block[i].start + block[i].mapList[j].frontExt - (block[i].end + block[i].mapList[j-1].rearExt) - 1);	
			}
			block[i].novelLen = tmpNovelLen;

		} else if (!strcmp(block[i].Label, "CDNA")) { 
			if (block[i].MAP_COUNT > 0) { 
				block[i].adjStart = block[i].start + block[i].mapList[0].frontExt;
				block[i].adjEnd = block[i].end + block[i].mapList[block[i].MAP_COUNT-1].rearExt;
				//block[i].oriFrontExt = -block[i].mapList[0].frontExt;
				//block[i].oriRearExt = -block[i].mapList[block[i].MAP_COUNT-1].rearExt;
				block[i].novelLen = 0;
			} else { 
				block[i].adjStart = block[i].start;
				block[i].adjEnd = block[i].end;
				//block[i].oriFrontExt = 0;
				//block[i].oriRearExt = 0;
				block[i].novelLen = 0;
			}
		} else if (!strcmp(block[i].Label, "NOVEL") || !strcmp(block[i].Label, "novel") || !strcmp(block[i].Label, "flank")) { 
			block[i].adjStart = block[i].start; 
			block[i].adjEnd = block[i].end;
			//block[i].oriFrontExt = 0;
			//block[i].oriRearExt = 0;
			if (!strcmp(block[i].Label, "NOVEL")) block[i].novelLen = block[i].adjEnd - block[i].adjStart + 1;
			else block[i].novelLen = 0;
		} 
	}
	if (blockCount > 1) { // Dealing with overlapping blocks
		for (i=1; i<blockCount; i++) { 
			if (!strcmp(block[i].Label, "FLANK") && !strcmp(block[i-1].Label, "FLANK") && block[i-1].adjStart == block[i].adjStart && 
			block[i-1].adjEnd == block[i].adjEnd) { 
				IF_PRINT[i-1] = 0;
			}
		}
	}
	for (i=0; i<blockCount; i++) { // Dealing with repeated annotated blocks
		if (IF_PRINT[i] == 1) {
			j = (i < blockCount-1)? i+1 : i; 
			k = (i > 0)? i-1 : i; 
			while (j < blockCount-1 && IF_PRINT[j] == 0) j++;
			while (k > 0 && IF_PRINT[k] == 0) k--;
	                if ((IF_PRINT[j] == 1 && !strcmp(block[i].Label, "FLANK") && !strcmp(block[j].Label, "RETAIN") && block[i].adjStart == block[j].adjStart) ||
        	        (IF_PRINT[k] == 1 && !strcmp(block[i].Label, "FLANK") && !strcmp(block[k].Label, "RETAIN") && block[i].adjEnd == block[k].adjEnd)) { 
				IF_PRINT[i] = 0;
			}
		}
	}
	for (i=0; i<blockCount; i++) {
                if (IF_PRINT[i] == 1) numAdjBlocks++;
        }
	printf("%s\t%d\n", block[0].ENSTID, numAdjBlocks);

	for (i=0; i<blockCount; i++) {
		if (IF_PRINT[i] == 1) {
			printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\tscore=%d\t", block[i].Label, block[i].signal, block[i].chr, block[i].adjStart, block[i].adjEnd, 
			block[i].strand, block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].map_score);
			
			// start printing coordinates of flanking exons
			if (!strcmp(block[i].Label, "NOVEL")) { 
				j = (i < blockCount-1)? i+1 : i;
				k = (i > 0)? i-1 : i;

				while ((IF_PRINT[j] == 0 || (strcmp(block[j].Label, "FLANK") && strcmp(block[j].Label, "RETAIN") && strcmp(block[j].Label, "retain") && 
				strcmp(block[j].Label, "CDNA"))) && j < blockCount-1) 
					j++;
				while ((IF_PRINT[k] == 0 || (strcmp(block[k].Label, "FLANK") && strcmp(block[k].Label, "RETAIN") && strcmp(block[k].Label, "retain") && 
				strcmp(block[k].Label, "CDNA"))) && k > 0) 
					k--;

				for (l=k; l<=i-1; l++) { 
					if (IF_PRINT[l] == 1 && (!strcmp(block[l].Label, "FLANK") || !strcmp(block[l].Label, "RETAIN") || !strcmp(block[l].Label, "retain") || 
					!strcmp(block[l].Label, "CDNA"))) { 
						if (!strcmp(block[l].Label, "RETAIN") || !strcmp(block[l].Label, "retain")) 
							printf("%d,%d,", block[l].start + block[l].mapList[block[l].MAP_COUNT-1].frontExt, block[l].adjEnd);
						else if (!strcmp(block[l].Label, "FLANK") || !strcmp(block[l].Label, "CDNA")) 
							printf("%d,%d,", block[l].adjStart, block[l].adjEnd);
						break;
					}
				}
				printf(";");
				for (l=i+1; l<=j; l++) { 
					if (IF_PRINT[l] == 1 && (!strcmp(block[l].Label, "FLANK") || !strcmp(block[l].Label, "RETAIN") || !strcmp(block[l].Label, "retain") || 
					!strcmp(block[l].Label, "CDNA"))) { 
						if (!strcmp(block[l].Label, "RETAIN") || !strcmp(block[l].Label, "retain")) 
							printf("%d,%d,", block[l].adjStart, block[l].end + block[l].mapList[0].rearExt);
						else if (!strcmp(block[l].Label, "FLANK") || !strcmp(block[l].Label, "CDNA"))
							printf("%d,%d,", block[l].adjStart, block[l].adjEnd);
						break;
					}
				}
				printf("\t");
			} else if (!strcmp(block[i].Label, "RETAIN")) { 
				for (l=0; l<block[i].MAP_COUNT-1; l++) printf("%d,%d,;", block[i].start + block[i].mapList[l].frontExt, block[i].end + block[i].mapList[l].rearExt);
					printf("%d,%d,\t", block[i].start + block[i].mapList[block[i].MAP_COUNT-1].frontExt, block[i].adjEnd);
			} else {
				printf("0,0,;0,0,\t");
			}
			printf("%d\n", block[i].novelLen);
		}
	}
	free(IF_PRINT);
}

