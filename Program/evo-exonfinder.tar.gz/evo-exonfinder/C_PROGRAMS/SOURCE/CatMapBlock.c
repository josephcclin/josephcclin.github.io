#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MIN_OVERLAP 50

typedef struct Corrected_Mappable_Block { 
	char Label[10];
	char signal[5];
	char chr[50]; 
	int start; 
	int end; 
	char strand[2];
	char ENSTID[50];
	char ESTID[50];
	int InitStart; 
	int InitEnd;
	int mapScore; 
	int frontFlankStart;
	int frontFlankEnd;
	int rearFlankStart;
	int rearFlankEnd;
	int novelLen;
} MapBlock;

typedef struct ENST_Exon_Block {
        char ENSTID[50];
        char chr[50];
        char strand[2];
        int start;
        int end;
	int rank;
        int phase; 
        int CDS_start;
	int CDS_end;
	int oriStart;
	int oriEnd;
} ENSTBlock;

typedef struct ENST_range_index {
        char ENSTID[50];
        char strand[2];
        int startIndex;
        int endIndex;
        int ENST_CDS_start;
        int ENST_CDS_end;
} ENST_RangeIndex;


ENST_RangeIndex indexSearch(ENST_RangeIndex *index, int numENST, char *queryENST);


int main(int argc, char **argv)
{
	FILE *mbFile, *pcFile; // mbFile: [CORRECTED_MAP_BLOCKS]; pcFile: [ENST_CDS_PROCESSED];
	char BlockENST[50] = "";
	//char Flanking[500] = "";
	int numExons = 0, numPCExons = 0, numENSTPCX = 0, numENST = 0;
	int i = 0, j = 0, j_1 = -1, j_2 = -1, k = 0, l = 0; 
	int tmp_len = 0;
	//int countFlank = 0;
	int flagBlockCDS = 0; // To know where the first coding exon and the last coding exon are in the mapped block
	int flagIllegal = 0; // To know if a set of blocks contains illegal candidates 
	int flagPrint = 0; // To decide if an empty line to separate records is necessary
	int flagDisjoint = 1; // To decide if two blocks overlap
	int flagNovelStart = 0; // To know if a reading frame starts at a novel exon
	int flagIllegalBoundary = 0; // To check if a candidate's boundary is illegal
	int flagBlockPrint = 0; // To print a set of blocks only if they contain candidates
	int blockCDS_start = -1;
	int blockCDS_end = -1;
	int current_ENST_CDS_start = 0;
	int current_ENST_CDS_end = 0;
        int CDS_block_len = 0;
	int scanVal = 0;
	ENSTBlock tmpBlock;
        ENST_RangeIndex qENST_idx;

	if (argc != 3) { 
		fprintf(stderr, "Usage:\n\t./CatMapBlock [CORRECTED_MAP_BLOCKS] [ENST_CODING_PROCESSED]\n\n");
		exit(EXIT_FAILURE);
	}

	if ((mbFile = fopen(argv[1], "r")) == NULL) { 
		fprintf(stderr, "** \"%s\" opening error! **\n", argv[1]);
		exit(EXIT_FAILURE);
	}
	if ((pcFile = fopen(argv[2], "r")) == NULL) { 
		fprintf(stderr, "** \"%s\" opening error! **\n", argv[2]);
		exit(EXIT_FAILURE);
	}

	while (fscanf(pcFile, "%d", &numPCExons) != EOF) { // To derive the number of ENST protein-coding transcripts (numENSTPCX)
		for (k=0; k<numPCExons; k++) { 
			scanVal = fscanf(pcFile, "%s %s %s %d %d %d %d %d %d %d %d", tmpBlock.ENSTID, tmpBlock.chr, tmpBlock.strand, 
			&tmpBlock.start, &tmpBlock.end, &tmpBlock.rank, &tmpBlock.phase, &tmpBlock.CDS_start, 
			&tmpBlock.CDS_end, &tmpBlock.oriStart, &tmpBlock.oriEnd);
			if (scanVal != 11) fprintf(stderr, "** File reading error in CatMapBlock **\n"); 
			numENSTPCX++;
		}
		numENST++;
	}

        ENSTBlock *E_blocks = (ENSTBlock *)malloc(sizeof(ENSTBlock) * numENSTPCX);
        ENST_RangeIndex *ENST_idx = (ENST_RangeIndex *)malloc(sizeof(ENST_RangeIndex) * numENST);

	if (E_blocks == NULL) { 
		fprintf(stderr, "** Memory allocation error for %s. **\n", argv[2]);
		exit(EXIT_FAILURE);
	}
	fseek(pcFile, 0, SEEK_SET);

	while (fscanf(pcFile, "%d", &numPCExons) != EOF) { // Store protein-coding exons into RAM
		for (k=0; k<numPCExons; k++) { 
			scanVal = fscanf(pcFile, "%s %s %s %d %d %d %d %d %d %d %d", E_blocks[j].ENSTID, E_blocks[j].chr, E_blocks[j].strand, 
			&E_blocks[j].start, &E_blocks[j].end, &E_blocks[j].rank, &E_blocks[j].phase, &E_blocks[j].CDS_start, 
			&E_blocks[j].CDS_end, &E_blocks[j].oriStart, &E_blocks[j].oriEnd);
			if (scanVal != 11) fprintf(stderr, "** File reading error in CatMapBlock **\n");
                        if (E_blocks[j].phase == -1) E_blocks[j].phase = 0; // Adjust the phase of the exons containing UTR
			j++;
		}
                strcpy(ENST_idx[l].ENSTID, E_blocks[j-1].ENSTID); // Construct the range index for each ENST protein-coding transcript
                strcpy(ENST_idx[l].strand, E_blocks[j-1].strand);
                ENST_idx[l].startIndex = j - numPCExons;
                ENST_idx[l].endIndex = j - 1;
                if (!strcmp(E_blocks[j-numPCExons].strand, "+")) {
                        ENST_idx[l].ENST_CDS_start = E_blocks[j-numPCExons].start;
                        ENST_idx[l].ENST_CDS_end = E_blocks[j-1].end;
                } else {
                        ENST_idx[l].ENST_CDS_start = E_blocks[j-numPCExons].end;
                        ENST_idx[l].ENST_CDS_end = E_blocks[j-1].start;
                }
                l++;
        }
        fclose(pcFile);

	// Start scanning...
	while (fscanf(mbFile, "%s %d", BlockENST, &numExons) != EOF) { 
		flagBlockCDS = 0;
		flagIllegal = 0;
		flagDisjoint = 1;
		flagNovelStart = 0;
		flagIllegalBoundary = 0;
		flagBlockPrint = 0;
		flagPrint = 0;
		//countFlank = 0;
		blockCDS_start = -1;
		blockCDS_end = -1;
	        CDS_block_len = 0;
		current_ENST_CDS_start = 0;
		current_ENST_CDS_end = 0;

		MapBlock *block = (MapBlock *)malloc(sizeof(MapBlock) * numExons);
		if (block == NULL) { 
			fprintf(stderr, "** Memory allocation error for %s. **\n", argv[1]);
			exit(EXIT_FAILURE); 
		}
                qENST_idx = indexSearch(ENST_idx, numENST, BlockENST);
                current_ENST_CDS_start = qENST_idx.ENST_CDS_start;
                current_ENST_CDS_end = qENST_idx.ENST_CDS_end;

                if (current_ENST_CDS_start == -1) { // The ENST is not protein-coding
                        for (i=0; i<numExons; i++) {
                                scanVal = fscanf(mbFile, "%s %s %s %d %d %s %s %s %d %d %d %d %d %d %d %d", block[i].Label, block[i].signal, block[i].chr, 
				&block[i].start, &block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, &block[i].InitStart, 
				&block[i].InitEnd, &block[i].mapScore, &block[i].frontFlankStart, &block[i].frontFlankEnd, &block[i].rearFlankStart, 
				&block[i].rearFlankEnd, &block[i].novelLen);
                                //fscanf(mbFile, "%s %s %s %d %d %s %s %s %d %d %d %s", &block[i].Label, &block[i].signal, &block[i].chr, 
				//&block[i].start, &block[i].end, &block[i].strand, &block[i].ENSTID, &block[i].ESTID, &block[i].InitStart, 
				//&block[i].InitEnd, &block[i].novelLen, &Flanking);
				//block[i].flanking = (char *)malloc(sizeof(char) * (strlen(Flanking)+1));
				//strcpy(block[i].flanking, Flanking);
				//block[i].flanking[strlen(Flanking)] = '\0';
				if (scanVal != 16) fprintf(stderr, "** File reading error in CatMapBlock **\n");
                        }
			for (i=0; i<numExons; i++) {
				if (!strcmp(block[i].Label, "NOVEL") || !strcmp(block[i].Label, "RETAIN")) {
					fprintf(stderr, "# Non-coding ENST\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
					block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
					block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, 
					block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
				}
			}
			//for (i=0; i<numExons; i++) free(block[i].flanking);
			//free(block);
                        continue; // jump to next set of blocks
                }

                if (!strcmp(qENST_idx.strand, "+")) {
                        for (i=0; i<numExons; i++) {
                                //fscanf(mbFile, "%s %s %s %d %d %s %s %s %d %d %d %s", &block[i].Label, &block[i].signal, &block[i].chr, &block[i].start, 
				//&block[i].end, &block[i].strand, &block[i].ENSTID, &block[i].ESTID, &block[i].InitStart, &block[i].InitEnd, 
				//&block[i].novelLen, &Flanking);
                                scanVal = fscanf(mbFile, "%s %s %s %d %d %s %s %s %d %d %d %d %d %d %d %d", block[i].Label, block[i].signal, block[i].chr, &block[i].start, 
				&block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, &block[i].InitStart, &block[i].InitEnd, &block[i].mapScore, 
				&block[i].frontFlankStart, &block[i].frontFlankEnd, &block[i].rearFlankStart, &block[i].rearFlankEnd, &block[i].novelLen);
				//block[i].flanking = (char *)malloc(sizeof(char) * (strlen(Flanking)+1));
				//strcpy(block[i].flanking, Flanking);
				//block[i].flanking[strlen(Flanking)] = '\0';
				if (scanVal != 16) fprintf(stderr, "** File reading error in CatMapBlock **\n");
				
                                if ((!strcmp(block[i].Label, "RETAIN") && !(block[i].rearFlankStart - 1 < current_ENST_CDS_start || block[i].frontFlankEnd + 1 > current_ENST_CDS_end)) ||
				(strcmp(block[i].Label, "RETAIN") && !(block[i].end < current_ENST_CDS_start || block[i].start > current_ENST_CDS_end))) {
                                        if (flagBlockCDS == 0) {
                                                blockCDS_start = i;
                                                flagBlockCDS = 1;
                                        }
                                } else {
                                        if (flagBlockCDS == 1) {
                                                blockCDS_end = i - 1;
                                                flagBlockCDS = 2; // CDS block is closed by a UTR exon
                                        }
					if (!strcmp(block[i].Label, "NOVEL")) {
						if (block[i].end < current_ENST_CDS_start) {
							fprintf(stderr, "# 5'UTR\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
							block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
							block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, 
							block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
						} else {
							fprintf(stderr, "# 3'UTR\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
							block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
							block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, 
							block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
						}
					} else if (!strcmp(block[i].Label, "RETAIN")) { 
						if (block[i].rearFlankStart - 1 < current_ENST_CDS_start) {
							fprintf(stderr, "# 5'UTR\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
							block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
							block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, 
							block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
						} else {
							fprintf(stderr, "# 3'UTR\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
							block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
							block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, 
							block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
						}
					}
                                }
                        }
                        if (flagBlockCDS == 1) blockCDS_end = i - 1;
                } else {
                        for (i=numExons-1; i>=0; i--) {
                                scanVal = fscanf(mbFile, "%s %s %s %d %d %s %s %s %d %d %d %d %d %d %d %d", block[i].Label, block[i].signal, block[i].chr, &block[i].start, 
				&block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, &block[i].InitStart, &block[i].InitEnd, &block[i].mapScore, 
				&block[i].frontFlankStart, &block[i].frontFlankEnd, &block[i].rearFlankStart, &block[i].rearFlankEnd, &block[i].novelLen);
				if (scanVal != 16) fprintf(stderr, "** File reading error in CatMapBlock.c **\n");

                                if ((!strcmp(block[i].Label, "RETAIN") && !(block[i].rearFlankStart - 1 < current_ENST_CDS_end || block[i].frontFlankEnd + 1 > current_ENST_CDS_start)) ||
				(strcmp(block[i].Label, "RETAIN") && !(block[i].end < current_ENST_CDS_end || block[i].start > current_ENST_CDS_start))) {
                                        if (flagBlockCDS == 0) {
                                                blockCDS_end = i;
                                                flagBlockCDS = 1;
                                        }
                                } else {
                                        if (flagBlockCDS == 1) {
                                                blockCDS_start = i + 1;
                                                flagBlockCDS = 2; // CDS block is closed by a UTR exon
                                        }
					if (!strcmp(block[i].Label, "NOVEL")) {
						if (block[i].end < current_ENST_CDS_end) { 
							fprintf(stderr, "# 3'UTR\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
							block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
							block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, 
							block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
						} else { 
							fprintf(stderr, "# 5'UTR\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
							block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
							block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, 
							block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
						}
					} else if (!strcmp(block[i].Label, "RETAIN")) { 
						if (block[i].rearFlankStart - 1 < current_ENST_CDS_end) { 
							fprintf(stderr, "# 3'UTR\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
							block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
							block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, 
							block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
						} else { 
							fprintf(stderr, "# 5'UTR\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
							block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
							block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, 
							block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
						}
					}
                                }
                        }
                        if (flagBlockCDS == 1) blockCDS_start = i + 1;
                }

                if (flagBlockCDS == 0) { 
			//for (i=0; i<numExons; i++) free(block[i].flanking);
			//free(block);
			continue;
		}

		for (i=blockCDS_start; i<=blockCDS_end; i++) { 
			if (!strcmp(block[i].Label, "novel") || !strcmp(block[i].Label, "flank")) {
				flagIllegal = 1; // illegal splicing sites or ambiguous mapping due to multiple AS form
				break;
			}
		}

		//for (i=blockCDS_start; i<=blockCDS_end; i++) { 
		//	if (!strcmp(block[i].Label, "FLANK")) countFlank++;
		//}
		//if (countFlank % 2 != 0) flagIllegal = 1;
		
		for (i=blockCDS_start; i<=blockCDS_end; i++) {
			if ((!strcmp(block[i].Label, "NOVEL") || !strcmp(block[i].Label, "RETAIN")) && block[i].end <= block[i].start) {
				fprintf(stderr, "# Illegal boundary\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label,
				block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, 
				block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, block[i].frontFlankEnd, 
				block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
				flagIllegalBoundary = 1;
			}
		}

		if (blockCDS_end - blockCDS_start >= 1) { 
			if (!strcmp(block[blockCDS_start].strand, "+")) {
				for (i=blockCDS_start+1; i<=blockCDS_end; i++) { 
					if (block[i].start < block[i-1].end + 5) { 
						flagDisjoint = 0; // blocks that overlap are found
						break;
					}
				}
			} else {
				for (i=blockCDS_start+1; i<=blockCDS_end; i++) { 
					if (block[i].end + 5 > block[i-1].start) { 
						flagDisjoint = 0; // blocks that overlap are found
						break;
					}
				}
			}
		}
		if (flagIllegal == 1) { 
			for (i=blockCDS_start; i<=blockCDS_end; i++) {
				if (!strcmp(block[i].Label, "NOVEL") || !strcmp(block[i].Label, "RETAIN")) {
					fprintf(stderr, "# Suspecious frame\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
					block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, 
					block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, block[i].frontFlankEnd, 
					block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
				}
			}
		}
		if (flagDisjoint == 0) { 
			for (i=blockCDS_start; i<=blockCDS_end; i++) {
				if (!strcmp(block[i].Label, "NOVEL") || !strcmp(block[i].Label, "RETAIN")) {
					fprintf(stderr, "# Overlapping blocks\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[i].Label, 
					block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, 
					block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, block[i].frontFlankEnd, 
					block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
				}
			}
		}
		if (!strcmp(block[blockCDS_start].Label, "NOVEL") || !strcmp(block[blockCDS_start].Label, "CDNA")) { 
			flagNovelStart = 1;
			for (i=blockCDS_start; i<=blockCDS_end; i++) {
				if (!strcmp(block[i].Label, "NOVEL") || !strcmp(block[i].Label, "RETAIN")) {
					fprintf(stderr, "# Due to %s start\t%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d,%d;%d,%d\t%d\n", block[blockCDS_start].Label, 
					block[i].Label, block[i].signal, block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID,
					block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].frontFlankStart, block[i].frontFlankEnd, 
					block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
				}
			}
		}
		for (i=blockCDS_start; i<=blockCDS_end; i++) { 
			if (!strcmp(block[i].Label, "NOVEL") || !strcmp(block[i].Label, "RETAIN")) { 
				flagBlockPrint = 1;
				break;
			}
		}
                if (flagIllegal == 1 || flagDisjoint == 0 || flagNovelStart == 1 || flagIllegalBoundary == 1 || flagBlockPrint == 0) { 
			//for (i=0; i<numExons; i++) free(block[i].flanking);
			//free(block);
			continue;
		}
		
		for (i=blockCDS_start; i<=blockCDS_end; i++) {  // Start checking the first exons in a mappable block
			if (!strcmp(block[i].strand, "+")) {
				if (!strcmp(block[i].Label, "FLANK")) {
					for (j=qENST_idx.startIndex; j<= qENST_idx.endIndex; j++) { 
						if (block[i].start == E_blocks[j].oriStart && block[i].end == E_blocks[j].oriEnd) {
							flagPrint = 1;
			                                if (i == blockCDS_start) {
	       	                                        	printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;0,0,0\t%d\n", block[i].Label, block[i].signal, 
								block[i].chr, E_blocks[j].start+((3-E_blocks[j].phase)%3), E_blocks[j].end, block[i].strand,
								block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, 
								block[i].mapScore, E_blocks[j].start, E_blocks[j].end, block[i].frontFlankStart, block[i].frontFlankEnd, 
								block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
								CDS_block_len += (E_blocks[j].end - (E_blocks[j].start + ((3-E_blocks[j].phase)%3))+1);
							} else if (i == blockCDS_end) {
								CDS_block_len += (E_blocks[j].end - E_blocks[j].start + 1);
								if (E_blocks[j].end - (CDS_block_len % 3) < E_blocks[j].start) {
									printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;0,0,0\t%d\n", block[i].Label, 
									block[i].signal, block[i].chr, E_blocks[j].start, E_blocks[j].end, block[i].strand, 
									block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, 
									E_blocks[j].start, E_blocks[j].end, block[i].frontFlankStart, block[i].frontFlankEnd, 
									block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
									CDS_block_len -= (CDS_block_len % 3);
								} else {
									printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;0,0,0\t%d\n", block[i].Label, 
									block[i].signal, block[i].chr, E_blocks[j].start, E_blocks[j].end - (CDS_block_len % 3), block[i].strand,
									block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, 
									block[i].novelLen, E_blocks[j].start, E_blocks[j].end, block[i].frontFlankStart, block[i].frontFlankEnd, 
									block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
									CDS_block_len -= (CDS_block_len % 3);
								}
							} else {
								printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;0,0,0\t%d\n", block[i].Label, block[i].signal, 
								block[i].chr, E_blocks[j].start, E_blocks[j].end, block[i].strand, block[i].ENSTID, block[i].ESTID, 
								block[i].InitStart, block[i].InitEnd, block[i].mapScore, E_blocks[j].start, E_blocks[j].end, 
								block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
								CDS_block_len += (E_blocks[j].end - E_blocks[j].start + 1);
							}
							break;
						}
					}
				} else if (!strcmp(block[i].Label, "NOVEL") || !strcmp(block[i].Label, "CDNA")) {
					printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, block[i].signal, block[i].chr, 
					block[i].start, block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, 
					block[i].start, block[i].end, block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, 
					(CDS_block_len % 3), current_ENST_CDS_start, current_ENST_CDS_end, block[i].novelLen); 
					CDS_block_len += (block[i].end - block[i].start + 1);
					flagPrint = 1;

				} else if (!strcmp(block[i].Label, "RETAIN") || !strcmp(block[i].Label, "retain")) { 
                                        for (j_1=qENST_idx.startIndex; j_1<=qENST_idx.endIndex; j_1++) {
                                                if (block[i].start <= E_blocks[j_1].oriStart && block[i].end >= E_blocks[j_1].oriEnd) break;
                                        }
                                        for (j_2=qENST_idx.endIndex; j_2>=qENST_idx.startIndex; j_2--) {
                                                if (block[i].start <= E_blocks[j_2].oriStart && block[i].end >= E_blocks[j_2].oriEnd) break;
                                        }

					flagPrint = 1;
					if (i == blockCDS_start) {
						if (i == blockCDS_end) {
							tmp_len = CDS_block_len;
							CDS_block_len += (E_blocks[j_2].end - (E_blocks[j_1].start + ((3-E_blocks[j_1].phase)%3)) + 1);
							printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, block[i].signal, 
							block[i].chr, E_blocks[j_1].start + ((3-E_blocks[j_1].phase)%3), E_blocks[j_2].end - (CDS_block_len % 3), 
							block[i].strand, block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, 
							block[i].mapScore, block[i].start, block[i].end, block[i].frontFlankStart, block[i].frontFlankEnd, 
							block[i].rearFlankStart, block[i].rearFlankEnd, (tmp_len % 3), current_ENST_CDS_start, current_ENST_CDS_end, block[i].novelLen); 
							CDS_block_len -= (CDS_block_len % 3); 
						} else {
							printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, block[i].signal, 
							block[i].chr, E_blocks[j_1].start + ((3-E_blocks[j_1].phase)%3), block[i].end, block[i].strand, 
							block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].start, block[i].end, 
							block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, 
							CDS_block_len % 3, current_ENST_CDS_start, current_ENST_CDS_end, block[i].novelLen); 
							CDS_block_len += (block[i].end - (E_blocks[j_1].start + ((3-E_blocks[j_1].phase)%3)) + 1);
						}
					} else if (i == blockCDS_end) { 
						tmp_len = CDS_block_len;
						CDS_block_len += (E_blocks[j_2].end - block[i].start + 1);
						printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, block[i].signal, 
						block[i].chr, block[i].start, E_blocks[j_2].end - (CDS_block_len % 3), block[i].strand,
						block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].start, block[i].end, 
						block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, 
						(tmp_len % 3), current_ENST_CDS_start, current_ENST_CDS_end, block[i].novelLen);
						CDS_block_len -= (CDS_block_len % 3);
					} else { 
						printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, block[i].signal, 
						block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, 
						block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].start, block[i].end, 
						block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, 
						(CDS_block_len % 3), current_ENST_CDS_start, current_ENST_CDS_end, block[i].novelLen);
						CDS_block_len += (block[i].end - block[i].start + 1);
					}
				}
			} else { // for the minus strand
				if (!strcmp(block[i].Label, "FLANK")) {
					for (j=qENST_idx.startIndex; j<= qENST_idx.endIndex; j++) { 
						if (block[i].start == E_blocks[j].oriStart && block[i].end == E_blocks[j].oriEnd) {
							flagPrint = 1;
			                                if (i == blockCDS_start) {
	       	                                        	printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;0,0,0\t%d\n", block[i].Label, 
								block[i].signal, block[i].chr, E_blocks[j].start, E_blocks[j].end - ((3-E_blocks[j].phase)%3), 
								block[i].strand, block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, 
								block[i].mapScore, E_blocks[j].start, E_blocks[j].end, block[i].frontFlankStart, block[i].frontFlankEnd, 
								block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
								CDS_block_len += (E_blocks[j].end - ((3-E_blocks[j].phase)%3) - E_blocks[j].start + 1);
							} else if (i == blockCDS_end) {
								CDS_block_len += (E_blocks[j].end - E_blocks[j].start + 1);
								if (E_blocks[j].start + (CDS_block_len % 3) > E_blocks[j].end) {
									printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;0,0,0\t%d\n", block[i].Label, 
									block[i].signal, block[i].chr, E_blocks[j].start, E_blocks[j].end, block[i].strand, block[i].ENSTID, 
									block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, E_blocks[j].start, 
									E_blocks[j].end, block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, 
									block[i].rearFlankEnd, block[i].novelLen);
									CDS_block_len -= (CDS_block_len % 3);
								} else {
									printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;0,0,0\t%d\n", block[i].Label, 
									block[i].signal, block[i].chr, E_blocks[j].start + (CDS_block_len % 3), E_blocks[j].end, block[i].strand,
									block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, 
									block[i].mapScore, E_blocks[j].start, E_blocks[j].end, block[i].frontFlankStart, block[i].frontFlankEnd, 
									block[i].rearFlankStart, block[i].rearFlankEnd, block[i].novelLen);
									CDS_block_len -= (CDS_block_len % 3);
								}
							} else {
								printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;0,0,0\t%d\n", block[i].Label, block[i].signal, 
								block[i].chr, E_blocks[j].start, E_blocks[j].end, block[i].strand, block[i].ENSTID,
								block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, E_blocks[j].start, 
								E_blocks[j].end, block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, 
								block[i].rearFlankEnd, block[i].novelLen);
								CDS_block_len += (E_blocks[j].end - E_blocks[j].start + 1);
							}
							break;
						}
					}
				} else if (!strcmp(block[i].Label, "NOVEL") || !strcmp(block[i].Label, "CDNA")) {
					flagPrint = 1;
					printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, block[i].signal, block[i].chr, 
					block[i].start, block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, 
					block[i].mapScore, block[i].start, block[i].end, block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, 
					block[i].rearFlankEnd, (CDS_block_len %3), current_ENST_CDS_end, current_ENST_CDS_start, block[i].novelLen); 
					CDS_block_len += (block[i].end - block[i].start + 1);

				} else if (!strcmp(block[i].Label, "RETAIN") || !strcmp(block[i].Label, "retain")) { 
                                        for (j_2=qENST_idx.startIndex; j_2<=qENST_idx.endIndex; j_2++) {
                                                if (block[i].start <= E_blocks[j_2].oriStart && block[i].end >= E_blocks[j_2].oriEnd) break;
                                        }
                                        for (j_1=qENST_idx.endIndex; j_1>=qENST_idx.startIndex; j_1--) {
                                                if (block[i].start <= E_blocks[j_1].oriStart && block[i].end >= E_blocks[j_1].oriEnd) break;
                                        }

					flagPrint = 1;
					if (i == blockCDS_start) {
						if (i == blockCDS_end) { 
							tmp_len = CDS_block_len;
							CDS_block_len += (E_blocks[j_2].end - ((3-E_blocks[j_2].phase)%3) - E_blocks[j_1].start + 1);
							printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, block[i].signal, 
							block[i].chr, E_blocks[j_1].start + (CDS_block_len % 3), E_blocks[j_2].end - ((3-E_blocks[j_2].phase)%3), 
							block[i].strand, block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].start, 
							block[i].end, block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, 
							(tmp_len %3), current_ENST_CDS_end, current_ENST_CDS_start, block[i].novelLen); 
							CDS_block_len -= (CDS_block_len % 3);
						} else {
							printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, 
							block[i].signal, block[i].chr, block[i].start, E_blocks[j_2].end - ((3-E_blocks[j_2].phase)%3), block[i].strand, 
							block[i].ENSTID, block[i].ESTID, block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].start, block[i].end, 
							block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, 
							(CDS_block_len % 3), current_ENST_CDS_end, current_ENST_CDS_start, block[i].novelLen); 
							CDS_block_len += (E_blocks[j_2].end - ((3-E_blocks[j_2].phase)%3) - block[i].start + 1);
						}
					} else if (i == blockCDS_end) { 
						tmp_len = CDS_block_len;
						CDS_block_len += (block[i].end - E_blocks[j_1].start + 1);
						printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, block[i].signal, 
						block[i].chr, E_blocks[j_1].start + (CDS_block_len % 3), block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, 
						block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].start, block[i].end, block[i].frontFlankStart, block[i].frontFlankEnd, 
						block[i].rearFlankStart, block[i].rearFlankEnd, (tmp_len %3), current_ENST_CDS_end, current_ENST_CDS_start, block[i].novelLen);
						CDS_block_len -= (CDS_block_len % 3);
					} else { 
						printf("%s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d,%d;%d,%d;%d,%d,%d\t%d\n", block[i].Label, block[i].signal, 
						block[i].chr, block[i].start, block[i].end, block[i].strand, block[i].ENSTID, block[i].ESTID, 
						block[i].InitStart, block[i].InitEnd, block[i].mapScore, block[i].start, block[i].end, 
						block[i].frontFlankStart, block[i].frontFlankEnd, block[i].rearFlankStart, block[i].rearFlankEnd, 
						(CDS_block_len %3), current_ENST_CDS_end, current_ENST_CDS_start, block[i].novelLen);
						CDS_block_len += (block[i].end - block[i].start + 1);
					}
				}
			}

		} 
		if (flagPrint == 1) printf("\n");
		//for (i=0; i<numExons; i++) free(block[i].flanking);
		free(block);
	}

	free(E_blocks);
	free(ENST_idx);
	fclose(mbFile);
	return 0;
}

ENST_RangeIndex indexSearch(ENST_RangeIndex *ENST_R_idx, int numENST, char *qENST)
{
        int i;
        ENST_RangeIndex nullIndex = {"", "", -1, -1, -1, -1};

        for (i=0; i<numENST; i++) {
                if (!strcmp(ENST_R_idx[i].ENSTID, qENST)) {
                        return ENST_R_idx[i];
                }
        }
        //fprintf(stderr, "** Error in indexSearch for %s (possibly not protein-coding) **\n", qENST);
        return nullIndex;
}

