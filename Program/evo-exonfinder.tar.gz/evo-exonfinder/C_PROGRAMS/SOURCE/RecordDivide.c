#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char **argv)
{
        FILE *fp_tmp, *fp_ChrList;
	char Candidate_to_divide[300] = "cat ";
	char Candidate_to_divide_backup[300] = ""; 
	char command_tmp[50] = "\") printf(\"%s\\n\\n\", $0); }' > _tmp_";
	char *command_GetAll;
	char index_column[20];
	char chr_scan[50];
	int command_len = 10;

	if (argc != 4) { 
		fprintf(stderr, "Usage:\n\t./RecordDivide [RECORDS] [INDEX_COLUMN] [TAG_LIST]\n\n");
		exit(EXIT_FAILURE);
	}
	if ((fp_tmp = fopen(argv[1], "r")) == NULL) {
		fprintf(stderr, "** %s opening error **\n", argv[1]);
		exit(EXIT_FAILURE);
	}
	fclose(fp_tmp);
	if ((fp_ChrList = fopen(argv[3], "r")) == NULL) { 
		fprintf(stderr, "** %s opening error **\n", argv[3]);
		exit(EXIT_FAILURE);
	}
	while (fscanf(fp_ChrList, "%s", chr_scan) != EOF) { 
		command_len += (strlen(chr_scan) + 10);
	}
	command_GetAll = (char *)malloc(sizeof(char) * command_len);
	strcpy(command_GetAll, "cat ");
	fseek(fp_ChrList, 0, SEEK_END);
	if (ftell(fp_ChrList) == 0) { 
		if (system("echo -e \"\" > _tmp_ALL_") < 0) fprintf(stderr, "** system call error **\n");;
		return 0;
	} else 
		fseek(fp_ChrList, 0, SEEK_SET);
	strcpy(index_column, argv[2]);
	strcat(Candidate_to_divide, argv[1]);
	strcat(Candidate_to_divide, " | awk 'BEGIN { RS = \"\"; } { if ($");
	strcat(Candidate_to_divide, index_column);
	strcat(Candidate_to_divide, " == \"");
	strcpy(Candidate_to_divide_backup, Candidate_to_divide);

	while (fscanf(fp_ChrList, "%s", chr_scan) != EOF) { 
		strcat(Candidate_to_divide, chr_scan);
		strcat(Candidate_to_divide, command_tmp);
		strcat(Candidate_to_divide, chr_scan);
		//printf("%s\n", Candidate_to_divide);
		if (system(Candidate_to_divide) < 0) fprintf(stderr, "** system call error **\n");
		strcpy(Candidate_to_divide, Candidate_to_divide_backup);
		strcat(command_GetAll, " _tmp_");
		strcat(command_GetAll, chr_scan);
		strcat(command_GetAll, " ");
	}
	strcat(command_GetAll, " > _tmp_ALL_");
	//printf("%s\n", command_GetAll);
	if (system(command_GetAll) < 0) fprintf(stderr, "** system call error **\n");
	//free(command_GetAll);
	return 0;
}

