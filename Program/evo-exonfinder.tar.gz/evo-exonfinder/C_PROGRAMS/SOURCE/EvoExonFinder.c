#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv)
{
	int i = 0, j = 1;
	int flagConf = 0;
	int pConf = 0;
	int flagCross = 0; 
	int pCross = 0;
	int flagSame = 0;
	int pSame = 0; 
	int flagBoth = 0;
	int flagOutput = 0;
	int pOutput = 0;
	char ParaItem[200];
	int indexParas = -1;
	char ParaName[9][25] = { "INPUT_ENSTS", "INPUT_ENSTS_CDS_PHASE", "CDNA_LIBRARY", "TARGET_GENOME", "MAX_GAP_LEN", \
	"CROSS_SPECIES_EST", "TARGET_SPECIES_EST", "MIN_SCORE_DIFF", "THREADS"};
	int flagFound = 0;
	char ParaVal[9][200] = { "", "", "", "", "", "", "", "", ""};
	char command[1000] = "NE-Extractor.sh "; 
	char command_merge[1000] = "Merge_Results.sh ";
	char command_dnds[1000] = "dnds_analysis.sh ";
	FILE *confp, *pThreads; 
	int sysCallRes = 0;
	

	if (argc == 1 || !strcmp(argv[1], "--help")) { 
		fprintf(stderr, "Usage:\n\tEvoExonFinder --config [CONFIG_FILE] -x [CROSS-SPECIES_MAPPING_PSL] -o [TASK_NAME]\n\t");
		fprintf(stderr, "EvoExonFinder --config [CONFIG_FILE] -t [TARGET-SPECIES_MAPPING_PSL] -o [TASK_NAME]\n\t");
		fprintf(stderr, "EvoExonFinder --config [CONFIG_FILE] -b -1 [CROSS-SPECIES_MAPPING_PSL] -2 [TARGET-SPECIES_MAPPING_PSL] -o [TASK_NAME]\n\n\t");
		fprintf(stderr, "-x: identify novel exons through cross-species EST mapping\n\t");
		fprintf(stderr, "-t: identify novel exons through target-species EST mapping\n\t");
		fprintf(stderr, "-b: identify novel exons through both target and cross species EST mapping\n\n");
		exit(EXIT_FAILURE);
	} 

	for (i=0; i<argc; i++) { 
		if (!strcmp(argv[i], "--config")) { 
			flagConf = 1;
			pConf = i+1;
		} else if (!strcmp(argv[i], "-x")) { 
			flagCross = 1;
			pCross = i+1;
		} else if (!strcmp(argv[i], "-t")) { 
			flagSame = 1;
			pSame = i+1;
		} else if (!strcmp(argv[i], "-b")) { 
			flagBoth = 1;
			for (j=1; j<argc; j++) {
				if (!strcmp(argv[j], "-1")) pCross = j+1;
				else if (!strcmp(argv[j], "-2")) pSame = j+1;
			}
		} else if (!strcmp(argv[i], "-o")) { 
			flagOutput = 1;
			pOutput = i+1;
		}
	}

	if (flagConf == 0) { 
		fprintf(stderr, "** --config or the config file is missing. **\n");
		exit(EXIT_FAILURE);
	}

	if (flagCross + flagSame + flagBoth != 1) { 
		fprintf(stderr, "** Use either \'-x\', \'-t\', or \'b\' **\n");
		exit(EXIT_FAILURE);
	} 

	if (flagOutput == 0) { 
		fprintf(stderr, "** -o or [TASK_NAME] is missing. **\n");	
		exit(EXIT_FAILURE);
	}
 
	if (flagCross == 1) { 
		if (argc != 7) { 
			fprintf(stderr, "** [CROSS-SPECIES_MAPPING_PSL] is missing. **\n");
			exit(EXIT_FAILURE);
		}
	} else if (flagSame == 1) { 
		if (argc != 7) { 
			fprintf(stderr, "** [TARGET-SPECIES_MAPPING_PSL] is missing. **\n");
			exit(EXIT_FAILURE);
		}
	} else if (flagBoth == 1) { 
		if (argc != 10) { 
			fprintf(stderr, "** [CROSS-SPECIES_MAPPING_PSL] or [TARGET-SPECIES_MAPPING_PSL] is missing. **\n");
			exit(EXIT_FAILURE);
		} else { 
			for (j=1; j<argc; j++) {
				if (!strcmp(argv[j], "-1")) pCross = j+1;
				else if (!strcmp(argv[j], "-2")) pSame = j+1;
			}

		}
	} else { 
		fprintf(stderr, "** Argument error **\n\nType \'EvoExonFinder --help\' for help.\n");
		exit(EXIT_FAILURE);
	}
	
	if ((confp = fopen(argv[pConf], "r")) == NULL) {  
		fprintf(stderr, "** File [CONFIG_FILE] error **\n");	
		exit(EXIT_FAILURE);
	}

	while (fscanf(confp, "%s", ParaItem) != EOF) { 
		for (i=0; i<9; i++) { 
			if (!strcmp(ParaItem, ParaName[i])) { 
				indexParas = i;
				flagFound = 1;
				break;
			}
		} 
		if (flagFound == 0) { 
			strcpy(ParaVal[indexParas], ParaItem);
			indexParas = -1; 
		} 
		flagFound = 0;
	}
	fclose(confp);

	if (!strcmp(ParaVal[4], "")) strcpy(ParaVal[4], "10"); 
	if (!strcmp(ParaVal[7], "")) strcpy(ParaVal[7], "20"); 
	if (!strcmp(ParaVal[8], "")) strcpy(ParaVal[8], "1");

	if (flagCross == 1) { 
		if (access( argv[pCross], F_OK ) == -1) { 
			fprintf(stderr, "** File [CROSS-SPECIES_MAPPING_PSL] error **\n");
			exit(EXIT_FAILURE);
		}
	} else if (flagSame == 1) { 
		if (access( argv[pSame], F_OK ) == -1) { 
			fprintf(stderr, "** File [TARGET-SPECIES_MAPPING_PSL] error **\n");
			exit(EXIT_FAILURE);
		}
	} else if (flagBoth == 1) { 
		if (access( argv[pCross], F_OK ) == -1) { 
			fprintf(stderr, "** File [CROSS-SPECIES_MAPPING_PSL] error **\n");
			exit(EXIT_FAILURE);
		}
		if (access( argv[pSame], F_OK ) == -1) { 
			fprintf(stderr, "** File [TARGET-SPECIES_MAPPING_PSL] error **\n");
			exit(EXIT_FAILURE);
		}
	}

	for (i=0; i<4; i++) { 
		if (i != 2) { 
			if (access( ParaVal[i], F_OK ) == -1) {
				fprintf(stderr, "** In %s: File %s error **\n", argv[pConf], ParaName[i]);
				exit(EXIT_FAILURE);
			} 
		} else { // cDNA library is not given
			if (!strcmp(ParaVal[2], "") || access( ParaVal[2], F_OK ) == -1) { 
				sysCallRes = system("echo -e "" > _EMPTY_CDNA_");
				if (sysCallRes == 0) { 
					strcpy(ParaVal[2], "_EMPTY_CDNA_");
				}
			}
		}
	}
	if (atoi(ParaVal[4]) <= 0) { 
		fprintf(stderr, "** In %s: MAX_GAP_LEN must be greater than 0 **\n", argv[pConf]);
		exit(EXIT_FAILURE);
	}
	if (atoi(ParaVal[7]) < 0) { 
		fprintf(stderr, "** In %s: MIN_SCORE_DIFF must be non-negative **\n", argv[pConf]);
		exit(EXIT_FAILURE);
	}

	if (flagCross == 1 || flagBoth == 1) { 
		if (access( ParaVal[5], F_OK ) == -1) {
			fprintf(stderr, "** In %s: File %s error **\n", argv[pConf], ParaName[5]);
			exit(EXIT_FAILURE);
		}
		if (flagBoth == 1) { 
			if (access( ParaVal[6], F_OK ) == -1) {
				fprintf(stderr, "** In %s: File %s error **\n", argv[pConf], ParaName[6]);
				exit(EXIT_FAILURE);
			}
		}  
	} else if (access( ParaVal[6], F_OK ) == -1) {
		fprintf(stderr, "** In %s: File %s error **\n", argv[pConf], ParaName[6]);
		exit(EXIT_FAILURE);
	}

	pThreads = fopen("_THREADS_", "w");
	if (pThreads == NULL) { 
		fprintf(stderr, "** Error in opening _THREADS_ to write. **\n");
		exit(EXIT_FAILURE);
	}

	if (!system("which blat > _WHERE_IS_BLAT_ 2> _CHECK_BLAT_")) { 
		if (!system("which pblat > _WHERE_IS_PBLAT_ 2> _CHECK_PBLAT_")) { 
			if (!strcmp(ParaVal[8], "1")) { 
				fprintf(pThreads, "blat\n1");
			} else { 
				fprintf(pThreads, "pblat\n%s", ParaVal[8]);
			}
		} else { // Only blat is available...
			fprintf(pThreads, "blat\n1");
		}
	} else { // blat is unavailable...
		if (!system("which pblat > _WHERE_IS_PBLAT_ 2> _CHECK_PBLAT_")) { // Yet pblat is available...
			fprintf(pThreads, "pblat\n%s", ParaVal[8]);
		} else { // Both are unavailable...
			fprintf(stderr, "** Neither blat nor pblat is available **\n");
			exit(EXIT_FAILURE);
		}
	}
	fclose(pThreads);
	//system("rm -f _CHECK_*BLAT_ _WHERE_IS_*BLAT_");

	if (flagCross == 1) { 
		strcat(command, argv[pCross]);
		strcat(command, " ");
		strcat(command, ParaVal[0]);
		strcat(command, " ");
		strcat(command, ParaVal[1]);
		strcat(command, " ");
		strcat(command, ParaVal[3]);
		strcat(command, " ");
		strcat(command, ParaVal[5]);
		strcat(command, " ");
		strcat(command, ParaVal[2]);
		strcat(command, " ");
		strcat(command, ParaVal[4]);
		strcat(command, " ");
		strcat(command, argv[pOutput]);
		strcat(command, "_cross ");
		strcat(command, "1"); 
		strcat(command, " "); 
		strcat(command, ParaVal[7]);
		//printf("%s\n", command);
		//system(command);
		sysCallRes = system(command);
		if (sysCallRes != 0) {
			fprintf(stderr, "** Program terminated (%d) **\n", sysCallRes);
			return EXIT_FAILURE;
		}

		strcat(command_dnds, argv[pOutput]);
		strcat(command_dnds, "_cross ");
		strcat(command_dnds, ParaVal[3]);
		strcat(command_dnds, " ");
		strcat(command_dnds, ParaVal[5]);
		//printf("%s\n", command_dnds);
		//system(command_dnds);
		sysCallRes = system(command_dnds);
		if (sysCallRes != 0) {
			fprintf(stderr, "** Program terminated (%d) **\n", sysCallRes);
			return EXIT_FAILURE;
		}
	} else if (flagSame == 1) { 
		strcat(command, argv[pSame]);
		strcat(command, " ");
		strcat(command, ParaVal[0]);
		strcat(command, " ");
		strcat(command, ParaVal[1]);
		strcat(command, " ");
		strcat(command, ParaVal[3]);
		strcat(command, " ");
		strcat(command, ParaVal[6]);
		strcat(command, " ");
		strcat(command, ParaVal[2]);
		strcat(command, " ");
		strcat(command, ParaVal[4]);
		strcat(command, " ");
		strcat(command, argv[pOutput]);
		strcat(command, "_same ");
		strcat(command, "0");
		strcat(command, " "); 
		strcat(command, ParaVal[7]);
		//printf("%s\n", command);
		//system(command);
		sysCallRes = system(command);
		if (sysCallRes != 0) {
			fprintf(stderr, "** Program terminated (%d) **\n", sysCallRes);
			return EXIT_FAILURE;
		} else { 
			sysCallRes = system("rm -f *final_coding *final_noncoding *final_all *identified_candidates.tsv");
			if (sysCallRes == 0) 
				sysCallRes += system("rm -f *_basic *_result_after_filtering_internal_retained *.sites");
			if (sysCallRes == 0) 
				sysCallRes += system("rm -f *_raw_mappable.blocks *_mappable.blocks *cdna_exclusion.tsv");
			if (sysCallRes != 0) {
				fprintf(stderr, "** Program terminated (%d) **\n", sysCallRes);
				return EXIT_FAILURE;
			}
		}
	} else if (flagBoth == 1) { 
		strcat(command, argv[pCross]);
		strcat(command, " ");
		strcat(command, ParaVal[0]);
		strcat(command, " ");
		strcat(command, ParaVal[1]);
		strcat(command, " ");
		strcat(command, ParaVal[3]);
		strcat(command, " ");
		strcat(command, ParaVal[5]);
		strcat(command, " ");
		strcat(command, ParaVal[2]);
		strcat(command, " ");
		strcat(command, ParaVal[4]);
		strcat(command, " ");
		strcat(command, argv[pOutput]);
		strcat(command, "_cross ");
		strcat(command, "1");
		strcat(command, " "); 
		strcat(command, ParaVal[7]);
		//printf("%s\n", command);
		sysCallRes = system(command);
		if (sysCallRes != 0) { 
			fprintf(stderr, "** Program terminated (%d) **\n", sysCallRes);
			return EXIT_FAILURE;
		}
		
		strcpy(command, "NE-Extractor.sh ");
		strcat(command, argv[pSame]);
		strcat(command, " ");
		strcat(command, ParaVal[0]);
		strcat(command, " ");
		strcat(command, ParaVal[1]);
		strcat(command, " ");
		strcat(command, ParaVal[3]);
		strcat(command, " ");
		strcat(command, ParaVal[6]);
		strcat(command, " ");
		strcat(command, ParaVal[2]);
		strcat(command, " ");
		strcat(command, ParaVal[4]);
		strcat(command, " ");
		strcat(command, argv[pOutput]);
		strcat(command, "_same ");
		strcat(command, "0");
		strcat(command, " "); 
		strcat(command, ParaVal[7]);
		//printf("%s\n", command);
		sysCallRes = system(command);
		if (sysCallRes != 0) { 
			fprintf(stderr, "** Program terminated (%d) **\n", sysCallRes);
			return EXIT_FAILURE;
		}

		strcat(command_merge, argv[pOutput]);
		strcat(command_merge, "_cross ");
		strcat(command_merge, argv[pOutput]);
		strcat(command_merge, "_same ");
		strcat(command_merge, argv[pOutput]);
		strcat(command_merge, "_cross_same");
		//printf("%s\n", command_merge); 
		sysCallRes = system(command_merge);
		if (sysCallRes != 0) { 
			fprintf(stderr, "** Program terminated (%d) **\n", sysCallRes);
			return EXIT_FAILURE;
		}
		
		strcat(command_dnds, argv[pOutput]);
		strcat(command_dnds, "_cross_same_filtered ");
		strcat(command_dnds, ParaVal[3]);
		strcat(command_dnds, " ");
		strcat(command_dnds, ParaVal[5]);
		//printf("%s\n", command_dnds);
		sysCallRes = system(command_dnds); 
		if (sysCallRes != 0) {
			fprintf(stderr, "** Program terminated (%d) **\n", sysCallRes);
			return EXIT_FAILURE;
		}
	}
	sysCallRes = system("rm -f _THREADS_ _EMPTY_CDNA_");  
	if (sysCallRes != 0) {
		fprintf(stderr, "** Program terminated (%d) **\n", sysCallRes);
		return EXIT_FAILURE;
	}
	return 0;
}
