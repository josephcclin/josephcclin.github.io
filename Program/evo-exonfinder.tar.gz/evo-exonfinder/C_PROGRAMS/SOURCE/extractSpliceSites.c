#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct EST_DNA {
	char Tag[50];
	int length; 
	char DNA[2000];
} READS; 

typedef struct map_result {
        char overlap_type[50];
        int length;
        float percent;
        int frontExt;
        int rearExt;
} MAP_RESULT;

typedef struct raw_candidate {
        char Label[10];
        char chr[50];
        int start;
        int end;
        char strand[2];
        char ENSTID[50];
        char ESTID[50];
        int EST_start;
        int EST_end;
	int map_score; // newly added
        int MAP_COUNT;
        MAP_RESULT *mapList;
} CANDIDATE;


char NucComplement(char Nuc);
void print_gDNA_Splice(char *DNA, int size, CANDIDATE entry, int shift);
//void printCandidate(FILE *fp, CANDIDATE entry);


int main(int argc, char** argv)
{
	FILE *candFile, *fpChr;
	//int i = 0; 
	int j = 0; 
	int shift = 2;
	int countMap = 0;
	CANDIDATE entryExon; 
	char tmpDIR[150] = "";
	char chr_name[50];
	char tmpChr[50] = "";
	int chr_size;
	char *chr_DNA = ""; 
	char delim; 
	int flagNovelExist = 0;
	int scanVal = 0;

	if (argc != 4) { 
		fprintf(stderr, "Usage: \n\t./extractSpliceSites [CANDIDATES_FILE] [CHROMOSOMES_DIR] [IS_INTER_SPECIES]\n\n");
		exit(EXIT_FAILURE);
	}

	if ((candFile = fopen(argv[1], "r")) == NULL) {
		fprintf(stderr, "** Error in opening %s **\n", argv[1]);
		exit(EXIT_FAILURE);
	}
	if (!strcmp(argv[3], "1")) shift = 10; 
	else shift = 2;

	while (fscanf(candFile, "%s %s %d %d %s %s %s %d %d %d %d", entryExon.Label, entryExon.chr, &entryExon.start, &entryExon.end, entryExon.strand, 
	entryExon.ENSTID, entryExon.ESTID, &entryExon.EST_start, &entryExon.EST_end, &entryExon.map_score, &entryExon.MAP_COUNT) != EOF) {
                if (entryExon.MAP_COUNT == 0) countMap = 1;
                else countMap = entryExon.MAP_COUNT;
                entryExon.mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT) * countMap);
                if (entryExon.mapList == NULL) {
                        fprintf(stderr, "** Memory allocation error for the candidates **\n");
                        exit(EXIT_FAILURE);
                }
                for (j=0; j<countMap; j++) {
                        scanVal = fscanf(candFile, "%s %d %f %d %d", entryExon.mapList[j].overlap_type, &entryExon.mapList[j].length,
                        &entryExon.mapList[j].percent, &entryExon.mapList[j].frontExt, &entryExon.mapList[j].rearExt);
			if (scanVal != 5) fprintf(stderr, "** File reading error in extractSpliceSites **\n");
                }
		if (!strcmp(entryExon.Label, "NOVEL")) { 
			flagNovelExist = 1;
			if (strcmp(tmpChr, entryExon.chr)) { 
			        if (strcmp(tmpChr, "")) { 
					free(chr_DNA);
				}
				//chr_DNA = malloc(sizeof(char) * 250000000);
				strcpy(tmpChr, entryExon.chr);
			        strcpy(tmpDIR, argv[2]); 
	
	        		if (tmpDIR[strlen(tmpDIR)-1] != '/') {
        	        		strcat(tmpDIR, "/");
			        }
	        		strcat(tmpDIR, entryExon.chr);
		        	strcat(tmpDIR, ".fa");

				fprintf(stderr, "-- Scanning candidates in %s --\n", entryExon.chr);
		        	if ((fpChr = fopen(tmpDIR, "r")) == NULL) {
	                		fprintf(stderr, "** Error in opening %s **\n", tmpDIR);
			                exit(EXIT_FAILURE);
        			}
			        while (fscanf(fpChr, "%s %d", chr_name, &chr_size) != EOF) {
					chr_DNA = malloc(sizeof(char) * (chr_size + 1));
					if (chr_DNA == NULL) {
						fprintf(stderr, "** Memory allocation error for %s **\n", chr_name);
						exit(EXIT_FAILURE);
					}
        	        		scanVal = fscanf(fpChr, "%c", &delim);
					if (scanVal != 1) fprintf(stderr, "** File reading error in extractSpliceSites **\n");
			                /*while (i < chr_size) {
                			        fscanf(fpChr, "%c", &(chr_DNA[i]));
		                	        i++;
	                		}*/
					if (fgets(chr_DNA, chr_size+1, fpChr) == NULL) fprintf(stderr, "** File reading error in extractSpliceSites **\n");
			                chr_DNA[chr_size] = '\0';
					//i = 0;
        			}
			        fclose(fpChr);
			}
			print_gDNA_Splice(chr_DNA, chr_size, entryExon, shift); 
			free(entryExon.mapList);
		} else free(entryExon.mapList); 
	}
	if (flagNovelExist == 1) free(chr_DNA);
	fclose(candFile);
	return 0;
}

char NucComplement(char c)
{
	switch(c) {
		case 'A':  
			return 'T';
			break;
		case 'C':
			return 'G';
			break;
		case 'G':
			return 'C';
			break;
		case 'T': 
			return 'A';
			break;
		case 'a':
			return 't';
			break;
		case 'c':
			return 'g';
			break;
		case 'g':
			return 'c'; 
			break;
		case 't': 
			return 'a';
			break;
		default:
			//fprintf(stderr, "NucComplement error!\n");
			return '-';
			break;
	}
}

void print_gDNA_Splice(char *chr_DNA, int chr_size, CANDIDATE entry, int shift)
{
	int i = 0, j = 0;
	int countMap = 0;
	int qStart = entry.start - 1 - 2 + shift;
	int qEnd = entry.end - 1 + 2 - shift;
	shift *= 2;

	if (entry.MAP_COUNT == 0) countMap = 1;
	else countMap = entry.MAP_COUNT;

	printf("%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d", entry.Label, entry.chr, entry.start, entry.end, entry.strand, 
	entry.ENSTID, entry.ESTID, entry.start, entry.end, entry.EST_start, entry.EST_end, entry.map_score, entry.MAP_COUNT);
	
	for (i=0; i<countMap; i++) { 
		printf("\t%s\t%d\t%1.4f\t%d\t%d", entry.mapList[i].overlap_type, entry.mapList[i].length, entry.mapList[i].percent, 
		entry.mapList[i].frontExt, entry.mapList[i].rearExt);
	}
        printf("\n");
	

	if (!strcmp(entry.strand, "-")) { 
		for (j=0; j<=shift; j++) { 
			printf("%c%c\t", NucComplement(chr_DNA[qEnd+j]), NucComplement(chr_DNA[qEnd-1+j])); 
			printf("%c%c\n", NucComplement(chr_DNA[qStart+1-j]), NucComplement(chr_DNA[qStart-j])); 
		}
	} else { 
		for (j=0; j<=shift; j++) { 
			printf("%c%c\t", chr_DNA[qStart-j], chr_DNA[qStart+1-j]); 
			printf("%c%c\n", chr_DNA[qEnd-1+j], chr_DNA[qEnd+j]); 
		}
	}

	printf("\n");
}

