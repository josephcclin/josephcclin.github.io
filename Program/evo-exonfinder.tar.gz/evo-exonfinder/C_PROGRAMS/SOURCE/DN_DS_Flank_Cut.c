#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MIN_INTRON_LEN 11

typedef struct RegionStartEnd {
	int start;
	int end;
} REGION;

typedef struct candidate {
        char chr[50];
        int start;
        int end;
        char strand;
	//char ENSTID[10000];
	char Label[10];
	//int numFlanking;
	//REGION *Flanking;
	int frontFlankStart;
	int frontFlankEnd;
	int rearFlankStart;
	int rearFlankEnd; 
	int phase;
	int CDSstart;
	int CDSend;
	char MAX_ENST[50];
	int MAX_ENST_InitStart;
	int MAX_ENST_InitEnd; 
        char MAX_EST[50];
        int MAX_ENST_AdjStart;
        int MAX_ENST_AdjEnd;
} CANDIDATE;

typedef struct SeqAlign { 
	char TargetChr[50];
	int TargetStart; 
	int TargetEnd;
	char TargetStrand;
	int TargetLength; 
	char *TargetString;
	char QueryTag[50];
	int QueryStart; 
	int QueryEnd;
	char QueryStrand;
	int QueryLength;
	char *QueryString;
} ALIGNMENT; 

ALIGNMENT searchSeq(CANDIDATE cand, ALIGNMENT *alignList, int numAlign);
ALIGNMENT RevAlign(ALIGNMENT intputAlignment, int isReverse);
int OverLapLen(CANDIDATE cand, int RegionStart, int RegionEnd);
int AlignCutOut(CANDIDATE *cand, int numNovel, ALIGNMENT goalAlign);
char NucCompl(char ch);

int main(int argc, char **argv)
{
	FILE *CandFile = NULL, *MafSeqFile = NULL, *p_NUM_MAF_BLOCKS_ = NULL; 
	int i = 0;
	int numNovel = 0;
	//int numCandidates = 0;
	int numAlign = 0;
	//int *flanking;
	int scanVal = 0;
	char delim;
	ALIGNMENT goalAlign;
	CANDIDATE tmpForSearch;

	if ((CandFile = fopen(argv[1], "r")) == NULL || (MafSeqFile = fopen(argv[2], "r")) == NULL || argc != 3) {
		if (argc != 3) fprintf(stderr, "Usage:\n\t./DN_DS_Seq_Cut [DN_DS_INPUT_CANDIDATES] [MAF_To_DNDS_INPUT]\n\n");
                else if (CandFile == NULL) fprintf(stderr, "** File ([DN_DS_INPUT_CANDIDATES]) error! **\n");
                else if (MafSeqFile == NULL) fprintf(stderr, "** File ([MAF_To_DNDS_INPUT]) error! **\n");
                exit(EXIT_FAILURE);
        }

	//while (fgets(AlignLine, 20000, MafSeqFile) != NULL) {
	//	if (AlignLine[0] == 'c' && AlignLine[1] == 'h' && AlignLine[2] == 'r') numAlign++;
	//}
	//fseek(MafSeqFile, 0, SEEK_SET);

	//CANDIDATE *candList = (CANDIDATE *)malloc(sizeof(CANDIDATE) * numCandidates);
	if ((p_NUM_MAF_BLOCKS_ = fopen("_NUM_MAF_BLOCKS_", "r")) == NULL) {
		fprintf(stderr, "** File _NUM_MAF_BLOCKS_ error!  **\n");
		exit(EXIT_FAILURE);
	} 
	if (fscanf(p_NUM_MAF_BLOCKS_, "%d", &numAlign) != 1) { 
		fprintf(stderr, "** File _NUM_MAF_BLOCKS_ error!  **\n");
		exit(EXIT_FAILURE);
	}
	fclose(p_NUM_MAF_BLOCKS_);
	
	ALIGNMENT *alignList = (ALIGNMENT *)malloc(sizeof(ALIGNMENT) * numAlign);
	
	while (fscanf(MafSeqFile, "%s %d %d %c %d", alignList[i].TargetChr, &alignList[i].TargetStart, &alignList[i].TargetEnd, &alignList[i].TargetStrand, &alignList[i].TargetLength) != EOF) {
		alignList[i].TargetString = (char *)malloc(sizeof(char) * (alignList[i].TargetLength + 1));
		scanVal = fscanf(MafSeqFile, "%c", &delim);
		if (scanVal != 1) fprintf(stderr, "** File reading error in DN_DS_Novel_Cut **\n");
		if (fgets(alignList[i].TargetString, (alignList[i].TargetLength + 1), MafSeqFile) == NULL) 
			fprintf(stderr, "** Target string reading error in DN_DS_Novel_Cut **\n");
		alignList[i].TargetString[alignList[i].TargetLength] = '\0';

		scanVal = fscanf(MafSeqFile, "%s %d %d %c %d", alignList[i].QueryTag, &alignList[i].QueryStart, &alignList[i].QueryEnd, &alignList[i].QueryStrand, &alignList[i].QueryLength); 
		if (scanVal != 5) fprintf(stderr, "** File reading error in DN_DS_Novel_Cut **\n");
		alignList[i].QueryString = (char *)malloc(sizeof(char) * (alignList[i].QueryLength + 1));
		scanVal = fscanf(MafSeqFile, "%c", &delim);
		if (scanVal != 1) fprintf(stderr, "** File reading error in DN_DS_Novel_Cut **\n");
		if (fgets(alignList[i].QueryString, (alignList[i].QueryLength + 1), MafSeqFile) == NULL) 
			fprintf(stderr, "** Query string reading error in DN_DS_Novel_Cut **\n");
		alignList[i].QueryString[alignList[i].QueryLength] = '\0';
		//strcpy(alignList[i].QueryString, AlignLine);
		i++;
	}
	fclose(MafSeqFile);
	i = 0;

	while (fscanf(CandFile, "%d", &numNovel) != EOF) {
		CANDIDATE *candList = (CANDIDATE *)malloc(sizeof(CANDIDATE) * numNovel);

		//printf("@@ numNovel = %d @@\n", numNovel);
		for (i=0; i<numNovel; i++) { 
			scanVal = fscanf(CandFile, "%s %d %d %c %s %d %d %d %d %d %d %d %s %d %d %s %d %d", candList[i].chr, &candList[i].start, &candList[i].end, &candList[i].strand, candList[i].Label, 
			&candList[i].frontFlankStart, &candList[i].frontFlankEnd, &candList[i].rearFlankStart, &candList[i].rearFlankEnd, &candList[i].phase, &candList[i].CDSstart, &candList[i].CDSend, candList[i].MAX_ENST, 
			&candList[i].MAX_ENST_InitStart, &candList[i].MAX_ENST_InitEnd, candList[i].MAX_EST, &candList[i].MAX_ENST_AdjStart, &candList[i].MAX_ENST_AdjEnd); 
		} 
		if (scanVal != 18) fprintf(stderr, "** File reading error in DN_DS_Flank_Cut **\n");
		strcpy(tmpForSearch.chr, candList[0].chr);
		tmpForSearch.start = candList[0].frontFlankEnd;
		tmpForSearch.end = candList[0].rearFlankStart;
		tmpForSearch.strand = candList[0].strand;
		//strcpy(tmpForSearch.ENSTID, candList[0].ENSTID);
		strcpy(tmpForSearch.Label, candList[0].Label);
		tmpForSearch.frontFlankStart = candList[0].frontFlankStart;
		tmpForSearch.frontFlankEnd = candList[0].frontFlankEnd;
		tmpForSearch.rearFlankStart = candList[0].rearFlankStart;
		tmpForSearch.rearFlankEnd = candList[0].rearFlankEnd;
		//tmpForSearch.phase = candList[0].phase;
		//tmpForSearch.CDSstart = candList[0].CDSstart;
		//tmpForSearch.CDSend = candList[0].CDSend;
		strcpy(tmpForSearch.MAX_ENST, candList[0].MAX_ENST);
		//tmpForSearch.MAX_ENST_InitStart = candList[0].MAX_ENST_InitStart;
		//tmpForSearch.MAX_ENST_InitEnd = candList[numNovel-1].MAX_ENST_InitEnd;
		strcpy(tmpForSearch.MAX_EST, candList[0].MAX_EST);
		tmpForSearch.MAX_ENST_AdjStart = candList[0].MAX_ENST_AdjStart;
		tmpForSearch.MAX_ENST_AdjEnd = candList[numNovel-1].MAX_ENST_AdjEnd;
		
		/*for (i=0; i<numNovel; i++) {  // for checking
			printf("%s\t%d\t%d\t%c\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%d\t%d\t%s\t%d\t%d\n", candList[i].chr, candList[i].start, candList[i].end, 
			candList[i].strand, candList[i].ENSTID, candList[i].Label, candList[i].frontFlankStart, candList[i].frontFlankEnd, candList[i].rearFlankStart, 
			candList[i].rearFlankEnd, candList[i].phase, candList[i].CDSstart, candList[i].CDSend, candList[i].MAX_ENST,
                	candList[i].MAX_ENST_InitStart, candList[i].MAX_ENST_InitEnd, candList[i].MAX_EST, candList[i].MAX_ENST_AdjStart, candList[i].MAX_ENST_AdjEnd);
                }*/
		//printf("@@ %s\t%d\t%d\t%c\t%s\t%s\t%s\n", tmpForSearch.chr, tmpForSearch.start, tmpForSearch.end,  // for checking
		//tmpForSearch.strand, tmpForSearch.ENSTID, tmpForSearch.Label, tmpForSearch.MAX_ENST, tmpForSearch.MAX_EST); // for checking
		goalAlign = searchSeq(tmpForSearch, alignList, numAlign);
		//printf("%s\t%d\t%d\t%c\n%s\n%s\t%d\t%d\t%c\n%s\n\n", goalAlign.TargetChr, goalAlign.TargetStart, goalAlign.TargetEnd, goalAlign.TargetStrand, // for checking
		//goalAlign.TargetString, goalAlign.QueryTag, goalAlign.QueryStart, goalAlign.QueryEnd, goalAlign.QueryStrand, goalAlign.QueryString); // for checking
		//printf("%s\t%d\t%d\t%c\n%s\t%d\t%d\t%c\n\n", goalAlign.TargetChr, goalAlign.TargetStart, goalAlign.TargetEnd, goalAlign.TargetStrand, // for checking
		//goalAlign.QueryTag, goalAlign.QueryStart, goalAlign.QueryEnd, goalAlign.QueryStrand); // for checking
		AlignCutOut(candList, numNovel, goalAlign);
		free(goalAlign.TargetString);
		free(goalAlign.QueryString);
		free(candList);
	}
	fclose(CandFile);

	for (i=0; i<numAlign; i++) {
		free(alignList[i].TargetString); 
		free(alignList[i].QueryString);
	}
	free(alignList);
	return 0;
}

ALIGNMENT searchSeq(CANDIDATE cand, ALIGNMENT *alignList, int numAlign)
{
	int i = 0, j = 0, k = 0, p = 0;
	//int flagExactFound = 0;
	int flagJointFound = 0;
	int flagJointCoverExist = 0;
	int flagErr = 1;
	int flagOverlap = 0;
	int tmpLen = 0;
	int CoverLen = 0;
	int MaxCoverLen = 0;
	ALIGNMENT outAlign    = { "", 0, 0, '*', 0, "", "", 0, 0, '*', 0, "" };
	ALIGNMENT outRevAlign = { "", 0, 0, '*', 0, "", "", 0, 0, '*', 0, "" };

	for (i=0; i<numAlign; i++) { 
		if (!strcmp(cand.chr, alignList[i].TargetChr) && !strcmp(cand.MAX_EST, alignList[i].QueryTag)) {
			flagErr = 0;
			break;
		}
	}
	if (flagErr == 1) { 
		fprintf(stderr, "** Error in searching for the corresponding alignment result. **\n");
		exit(EXIT_FAILURE);
	}

	for (i=0; i<numAlign; i++) { // One can cover
		if (!strcmp(cand.chr, alignList[i].TargetChr) && !strcmp(cand.MAX_EST, alignList[i].QueryTag) && 
		((cand.frontFlankEnd - alignList[i].TargetStart >= 10 && alignList[i].TargetEnd - cand.rearFlankStart >= 10) || 
		((float)(cand.frontFlankEnd - alignList[i].TargetStart)/(float)(cand.frontFlankEnd - cand.frontFlankStart) >= 0.5 && 
		(float)(alignList[i].TargetEnd - cand.rearFlankStart)/(float)(cand.rearFlankEnd - cand.rearFlankStart) >= 0.5)) && 
		cand.strand == alignList[i].TargetStrand) { 
			//flagExactFound = 1;
			//printf("# ONE COVER #\n"); // for checking
			return RevAlign(alignList[i], 0); 
		}
	} 
	
	for (i=0; i<numAlign; i++) { // Exactly match except the strand
		if (!strcmp(cand.chr, alignList[i].TargetChr) && !strcmp(cand.MAX_EST, alignList[i].QueryTag) && 
		((cand.frontFlankEnd - alignList[i].TargetStart >= 10 && alignList[i].TargetEnd - cand.rearFlankStart >= 10) || 
		((float)(cand.frontFlankEnd - alignList[i].TargetStart)/(float)(cand.frontFlankEnd - cand.frontFlankStart) >= 0.5 &&
		(float)(alignList[i].TargetEnd - cand.rearFlankStart)/(float)(cand.rearFlankEnd - cand.rearFlankStart) >= 0.5))) { 
			//flagExactFound = 1;
			//printf("# ONE COVER (EXCEPT STRAND) #\n"); // for checking
			return RevAlign(alignList[i], 1);
		}
	}

	for (i=0; i<numAlign; i++) { // Merge separated blocks to cover the candidate 
		flagOverlap = 0;
		flagJointFound = 0;
		CoverLen = 0;

		if (!strcmp(cand.chr, alignList[i].TargetChr) && !strcmp(cand.MAX_EST, alignList[i].QueryTag) && 
		alignList[i].TargetStart <= cand.frontFlankEnd && alignList[i].TargetEnd >= cand.frontFlankStart) { 
			//printf("# HERE # (cand.frontFlankEnd = %d, i = %d, alignList[i].TargetStart = %d, alignList[i].TargetEnd = %d)\n", // for checking
			//cand.frontFlankEnd, i, alignList[i].TargetStart, alignList[i].TargetEnd); // for checking
			if (alignList[i].TargetStrand == '+') { 
				if (i < numAlign-1 && (strcmp(cand.chr, alignList[i+1].TargetChr) || (!strcmp(cand.chr, alignList[i+1].TargetChr) && 
				alignList[i+1].TargetStart < alignList[i].TargetEnd))) continue;
				for (j=i+1; j<numAlign; j++) { 
					if (!strcmp(cand.chr, alignList[j].TargetChr) && !strcmp(cand.MAX_EST, alignList[j].QueryTag) && 
					alignList[j].TargetStrand == '+' && cand.rearFlankStart < alignList[j].TargetEnd && alignList[j].TargetStart < cand.rearFlankEnd) { 
							//printf("# (+) HERE # (cand.rearFlankStart = %d, j = %d, alignList[j].TargetStart = %d, alignList[j].TargetEnd = %d)\n", // for checking
							//cand.rearFlankStart, j, alignList[j].TargetStart, alignList[j].TargetEnd); // for checking
							
							//if (cand.strand == alignList[i].TargetStrand) { 
							//	printf("# Joint #\n"); // for checking
							//} else { 
							//	printf("# Joint (EXCEPT STRAND) #\n"); // for checking
							//}
						flagJointFound = 1;
						//break;
					} 
					if (strcmp(cand.chr, alignList[j].TargetChr) || alignList[j].TargetStrand != '+' || 
					(!strcmp(cand.chr, alignList[j].TargetChr) && (alignList[j].TargetStart > cand.rearFlankEnd || 
					alignList[j].TargetStart < alignList[j-1].TargetEnd))) { 
						j--;
						break;
					}
					//if (alignList[j+1].TargetStart < alignList[j].TargetEnd) break; 
				}

				if (flagJointFound == 1) { 
					for (k=i; k<=j; k++) {
						if ((cand.frontFlankStart <= alignList[k].TargetStart && alignList[k].TargetStart <= cand.frontFlankEnd) || 
						(cand.frontFlankStart <= alignList[k].TargetEnd && alignList[k].TargetEnd <= cand.frontFlankEnd) || 
						(alignList[k].TargetStart <= cand.frontFlankStart && cand.frontFlankEnd <= alignList[k].TargetEnd)) { 
							flagOverlap++;
							break;
						}
					}
					for (k=i; k<=j; k++) {
						if ((cand.rearFlankStart <= alignList[k].TargetEnd && alignList[k].TargetEnd <= cand.rearFlankEnd) || 
						(cand.rearFlankStart <= alignList[k].TargetStart && alignList[k].TargetStart <= cand.rearFlankEnd) ||
						(alignList[k].TargetStart <= cand.rearFlankStart && cand.rearFlankEnd <= alignList[k].TargetEnd)) { 
							flagOverlap++;
							break;
						}
					}
					if (flagOverlap < 2) continue;
					flagJointCoverExist = 1;

					//printf("### j - i = %d (i = %d, j = %d) ##\n", j-i, i, j); // for checking

					for (k=i; k<=j; k++) CoverLen += OverLapLen(cand, alignList[k].TargetStart, alignList[k].TargetEnd);
					if (CoverLen <= MaxCoverLen) continue;
					else { 
						if (MaxCoverLen > 0) { 
							free(outAlign.TargetString);
							free(outAlign.QueryString);
						}
						MaxCoverLen = CoverLen;
					}
					//printf("## CoverLen = %d ##\n", CoverLen); // for checking

					tmpLen = strlen(alignList[i].TargetString);
					for (k=i+1; k<=j; k++) { 
						tmpLen += strlen(alignList[k].TargetString);
						tmpLen += (alignList[k].TargetStart - alignList[k-1].TargetEnd - 1);
					}
					strcpy(outAlign.TargetChr, alignList[i].TargetChr); 
					outAlign.TargetStart = alignList[i].TargetStart;
					outAlign.TargetEnd = alignList[j].TargetEnd;
					outAlign.TargetStrand = alignList[i].TargetStrand;
					strcpy(outAlign.QueryTag, alignList[i].QueryTag); 
					if (alignList[i].QueryStrand == '+') { 
						outAlign.QueryStart = alignList[i].QueryStart;
						outAlign.QueryEnd = alignList[j].QueryEnd;
					} else { 
						outAlign.QueryStart = alignList[j].QueryStart;
						outAlign.QueryEnd = alignList[i].QueryEnd;
					}
					outAlign.QueryStrand = alignList[i].QueryStrand;
					outAlign.TargetString = (char *)malloc((sizeof(char) * (tmpLen+1)));
					outAlign.QueryString = (char *)malloc((sizeof(char) * (tmpLen+1)));
					strcpy(outAlign.TargetString, alignList[i].TargetString);
					for (k=i+1; k<=j; k++) { 
						for (p=0; p<alignList[k].TargetStart - alignList[k-1].TargetEnd - 1; p++) 
							strcat(outAlign.TargetString, ".");
						strcat(outAlign.TargetString, alignList[k].TargetString);
					}
					strcpy(outAlign.QueryString, alignList[i].QueryString);
					for (k=i+1; k<=j; k++) { 
						for (p=0; p<alignList[k].TargetStart - alignList[k-1].TargetEnd - 1; p++)
							strcat(outAlign.QueryString, ".");
						strcat(outAlign.QueryString, alignList[k].QueryString);
					}
					//break;
				}
			} else { // for the minus strand
				if (i > 0 && (strcmp(cand.chr, alignList[i-1].TargetChr) || (!strcmp(cand.chr, alignList[i-1].TargetChr) && 
				alignList[i-1].TargetStart < alignList[i].TargetEnd))) continue;
				for (j=i-1; j>=0; j--) { 
					if (!strcmp(cand.chr, alignList[j].TargetChr) && !strcmp(cand.MAX_EST, alignList[j].QueryTag) && 
					alignList[j].TargetStrand == '-' && cand.rearFlankStart < alignList[j].TargetEnd && alignList[j].TargetStart < cand.rearFlankEnd) { 
							//printf("# (-) HERE # (cand.rearFlankStart = %d, j = %d, alignList[j].TargetStart = %d, alignList[j].TargetEnd = %d)\n", // for checking
							//cand.rearFlankStart, j, alignList[j].TargetStart, alignList[j].TargetEnd); // for checking
							//if (cand.strand == alignList[i].TargetStrand) { 
								//printf("# Joint #\n"); // for checking
							//} else { 
								//printf("# Joint (EXCEPT STRAND) #\n"); // for checking
							//}
							flagJointFound = 1;
							//break;
					} 
					if (strcmp(cand.chr, alignList[j].TargetChr) || alignList[j].TargetStrand != '-' || 
					(!strcmp(cand.chr, alignList[j].TargetChr) && (alignList[j].TargetStart > cand.rearFlankEnd || 
					alignList[j].TargetStart < alignList[j+1].TargetEnd))) {
						j++; 
						break;
					}
					//if (alignList[j-1].TargetStart < alignList[j].TargetEnd) break;
				}

				if (flagJointFound == 1) { 
					for (k=i; k>=j; k--) {
						if ((cand.frontFlankStart <= alignList[k].TargetStart && alignList[k].TargetStart <= cand.frontFlankEnd) || 
						(cand.frontFlankStart <= alignList[k].TargetEnd && alignList[k].TargetEnd <= cand.frontFlankEnd) ||
						(alignList[k].TargetStart <= cand.frontFlankStart && cand.frontFlankEnd <= alignList[k].TargetEnd)) { 
							flagOverlap++;
							break;
						}
					}
					for (k=i; k>=j; k--) {
						if ((cand.rearFlankStart <= alignList[k].TargetEnd && alignList[k].TargetEnd <= cand.rearFlankEnd) || 
						(cand.rearFlankStart <= alignList[k].TargetStart && alignList[k].TargetStart <= cand.rearFlankEnd) || 
						(alignList[k].TargetStart <= cand.rearFlankStart && cand.rearFlankEnd <= alignList[k].TargetEnd)) { 
							flagOverlap++;
							break;
						}
					}
					if (flagOverlap < 2) continue;
					flagJointCoverExist = 1;

					//printf("### i - j = %d (i = %d, j = %d) ##\n", i-j, i, j); // for checking

					for (k=i; k>=j; k--) CoverLen += OverLapLen(cand, alignList[k].TargetStart, alignList[k].TargetEnd);
					if (CoverLen <= MaxCoverLen) continue;
					else { 
						if (MaxCoverLen > 0) { 
							free(outAlign.TargetString);
							free(outAlign.QueryString);
						}
						MaxCoverLen = CoverLen;
					}
					//printf("## CoverLen = %d ##\n", CoverLen); // for checking

					//tmpLen = strlen(alignList[i].TargetString);	
					tmpLen = strlen(alignList[j].TargetString);	
					//for (k=i-1; k>=j; k--) { 
					for (k=j+1; k<=i; k++) { 
						tmpLen += strlen(alignList[k].TargetString);
						//tmpLen += alignList[k].TargetStart - alignList[k+1].TargetEnd - 1;
						tmpLen += (alignList[k-1].TargetStart - alignList[k].TargetEnd - 1);
					}
					strcpy(outAlign.TargetChr, alignList[i].TargetChr); 
					outAlign.TargetStart = alignList[i].TargetStart;
					outAlign.TargetEnd = alignList[j].TargetEnd;
					outAlign.TargetStrand = alignList[i].TargetStrand;
					strcpy(outAlign.QueryTag, alignList[i].QueryTag); 
					if (alignList[i].QueryStrand == '+') { 
						outAlign.QueryStart = alignList[j].QueryStart;
						outAlign.QueryEnd = alignList[i].QueryEnd;
					} else { 
						outAlign.QueryStart = alignList[i].QueryStart;
						outAlign.QueryEnd = alignList[j].QueryEnd;
					}
					outAlign.QueryStrand = alignList[i].QueryStrand;
					outAlign.TargetString = (char *)malloc((sizeof(char) * (tmpLen+1)));
					outAlign.QueryString = (char *)malloc((sizeof(char) * (tmpLen+1)));
					//strcpy(outAlign.TargetString, alignList[i].TargetString);
					strcpy(outAlign.TargetString, alignList[j].TargetString);
					//for (k=i-1; k>=j; k--) { 
					for (k=j+1; k<=i; k++) { 
						//for (p=0; p<alignList[k].TargetStart - alignList[k+1].TargetEnd - 1; p++) 
						for (p=0; p<alignList[k-1].TargetStart - alignList[k].TargetEnd - 1; p++)
							strcat(outAlign.TargetString, ".");
						strcat(outAlign.TargetString, alignList[k].TargetString);
					}
					//strcpy(outAlign.QueryString, alignList[i].QueryString);
					strcpy(outAlign.QueryString, alignList[j].QueryString);
					//for (k=i-1; k>=j; k--) { 
					for (k=j+1; k<=i; k++) { 
						//for (p=0; p<alignList[k].TargetStart - alignList[k+1].TargetEnd - 1; p++)
						for (p=0; p<alignList[k-1].TargetStart - alignList[k].TargetEnd - 1; p++)
							strcat(outAlign.QueryString, ".");
						strcat(outAlign.QueryString, alignList[k].QueryString);
					}
					//break;
				}
			} 
		}
	}
	if (flagJointCoverExist == 1) { 
		if (cand.strand == outAlign.TargetStrand) { 
			//printf("@@ The same strand  @@\n"); // for checking
			return outAlign;
		} else {
			//printf("@@ Different strand @@\n"); // for checking
			outRevAlign = RevAlign(outAlign, 1);
			free(outAlign.TargetString);
			free(outAlign.QueryString);
			return outRevAlign;
		}
	}
	printf("** Possibly error here **\n"); // for checking
	return outAlign;
}

ALIGNMENT RevAlign(ALIGNMENT intAlign, int isRev)
{
	int i = 0;
	int len = strlen(intAlign.TargetString);
	ALIGNMENT outAlign = { "", 0, 0, '*', 0, "", "", 0, 0, '*', 0, "" };
	outAlign.TargetString = (char *)malloc(sizeof(char) * (len+1));
	outAlign.QueryString = (char *)malloc(sizeof(char) * (len+1));

	if (isRev == 0) {
		strcpy(outAlign.TargetChr, intAlign.TargetChr);
		outAlign.TargetStart = intAlign.TargetStart;
		outAlign.TargetEnd = intAlign.TargetEnd;
		outAlign.TargetStrand = intAlign.TargetStrand;
		strcpy(outAlign.TargetString, intAlign.TargetString);
		strcpy(outAlign.QueryTag, intAlign.QueryTag);
		outAlign.QueryStart = intAlign.QueryStart;
		outAlign.QueryEnd = intAlign.QueryEnd;
		outAlign.QueryStrand = intAlign.QueryStrand;
		strcpy(outAlign.QueryString, intAlign.QueryString);
	} else {
		if (intAlign.TargetStrand == '+') outAlign.TargetStrand = '-';
		else outAlign.TargetStrand = '+';
		if (intAlign.QueryStrand == '+') outAlign.QueryStrand = '-';
		else outAlign.QueryStrand = '+';
		strcpy(outAlign.TargetChr, intAlign.TargetChr);
		strcpy(outAlign.QueryTag, intAlign.QueryTag);
		outAlign.TargetStart = intAlign.TargetStart;
		outAlign.TargetEnd = intAlign.TargetEnd;
		outAlign.QueryStart = intAlign.QueryStart;
		outAlign.QueryEnd = intAlign.QueryEnd;
		for (i=0; i<len; i++) outAlign.TargetString[i] = NucCompl(intAlign.TargetString[len-1-i]);
		outAlign.TargetString[len] = '\0';
		for (i=0; i<len; i++) outAlign.QueryString[i] = NucCompl(intAlign.QueryString[len-1-i]);
		outAlign.QueryString[len] = '\0';
	}	
	return outAlign;
}


int AlignCutOut(CANDIDATE *cand, int numNovel, ALIGNMENT goalAlign)
{
	int i = 0, j = 0, k = 0, l = 0; 
	int alignLen = strlen(goalAlign.TargetString);
	int refinedLen = 0;
	int tmpPhase = 0;
	int *IS_PRINT; 
	char *RefinedTargetString; 
	char *RefinedQueryString;
	int matchBases = 0;
	int totalBases = 0;
	int flankLen = 0;
	int numFlank = 2;

	REGION flanks[2];
	REGION intron = { 0, 0 };
	int relFlankLen[2]; 
	int relFlankStart[2];
	int relFlankEnd[2];
	
	if (!strcmp(cand[0].Label, "RETAIN")) { 
		intron.start = cand[0].frontFlankEnd + 1;
		intron.end = cand[0].rearFlankStart - 1;
	}
	if (!strcmp(cand[0].Label, "RETAIN")) {
		if (cand[0].strand == '+') cand[0].frontFlankStart = cand[0].MAX_ENST_AdjStart;
		else cand[0].rearFlankEnd = cand[0].MAX_ENST_AdjEnd;
	}


	if (cand[0].strand == '+') { 
		flanks[0].end = cand[0].frontFlankEnd;
		flanks[1].start = cand[0].rearFlankStart;
		if (cand[0].CDSstart > cand[0].frontFlankStart) { 
			flanks[0].start = cand[0].CDSstart;
			tmpPhase = 0;
			//printf("## boundary changed by CDS start ##\n"); // for checking
		} else { 
			flanks[0].start = cand[0].frontFlankStart; 
			if (!strcmp(cand[0].Label, "NOVEL")) { 
				tmpPhase = (3 + cand[0].phase - (flanks[0].end - flanks[0].start + 1)%3) % 3; 
			} else if (!strcmp(cand[0].Label, "RETAIN")) { 
				tmpPhase = cand[0].phase;
			}
		}
		if (cand[0].CDSend < cand[0].rearFlankEnd) { 
			flanks[1].end = cand[0].CDSend;
			//printf("## boundary changed by CDS end ##\n"); // for checking
		} else {
			flanks[1].end = cand[0].rearFlankEnd;
		}
	} else { 
		flanks[0].start = cand[0].rearFlankStart;
		flanks[1].end = cand[0].frontFlankEnd;
		if (cand[0].CDSend < cand[0].rearFlankEnd) { 
			flanks[0].end = cand[0].CDSend;
			tmpPhase = 0;
			//printf("## boundary changed by CDS end ##\n"); // for checking
		} else { 
			flanks[0].end = cand[0].rearFlankEnd;
			if (!strcmp(cand[0].Label, "NOVEL")) { 
				tmpPhase = (3 + cand[0].phase - (flanks[0].end - flanks[0].start + 1)%3) % 3;
			} else if (!strcmp(cand[0].Label, "RETAIN")) { 
				tmpPhase = cand[0].phase;
			}
		}
		if (cand[0].CDSstart > cand[0].frontFlankStart) { 
			flanks[1].start = cand[0].CDSstart;
			//printf("## boundary changed by CDS start ##\n"); // for checking
		} else { 
			flanks[1].start = cand[0].frontFlankStart;
		}
	}

	//printf("# tmpPhase = %d, flanks[0].start = %d, flanks[0].end = %d, flanks[1].start = %d, flanks[1].end = %d #\n", // for checking
	//tmpPhase, flanks[0].start, flanks[0].end, flanks[1].start, flanks[1].end); // for checking

	if (flanks[1].end < flanks[1].start) numFlank = 1;
	for (i=0; i<numFlank; i++) flankLen += (flanks[i].end - flanks[i].start + 1);

	if (cand[0].strand == '+') { 
		if (flanks[0].start < goalAlign.TargetStart) { 
			tmpPhase = (tmpPhase + goalAlign.TargetStart - flanks[0].start)%3;
			flankLen -= (goalAlign.TargetStart - flanks[0].start);
			flanks[0].start = goalAlign.TargetStart;
		} 
		if (flanks[numFlank-1].end > goalAlign.TargetEnd) { 
			flankLen -= (flanks[numFlank-1].end - goalAlign.TargetEnd); 
			flanks[numFlank-1].end = goalAlign.TargetEnd;
		}
		flanks[0].start += ((3-tmpPhase)%3);
		flankLen -= ((3-tmpPhase)%3);
		flanks[numFlank-1].end -= (flankLen%3);
		flankLen -= (flankLen%3);
		
		for (i=0; i<numFlank; i++) { 
			relFlankLen[i] = flanks[i].end - flanks[i].start + 1;
			relFlankStart[i] = flanks[i].start - goalAlign.TargetStart;
			relFlankEnd[i] = flanks[i].end - goalAlign.TargetStart;
			//printf("relFlankStart[%d] = %d, relFlankEnd[%d] = %d \t", i, relFlankStart[i], i, relFlankEnd[i]); // for checking
		}
		//printf("\n\n"); // for checking
	} else { 
		if (flanks[0].end > goalAlign.TargetEnd) { 
			tmpPhase = (tmpPhase + flanks[0].end - goalAlign.TargetEnd)%3;
			flankLen -= (flanks[0].end - goalAlign.TargetEnd);
			flanks[0].end = goalAlign.TargetEnd;
		} 
		if (flanks[numFlank-1].start < goalAlign.TargetStart) { 
			flankLen -= (goalAlign.TargetStart - flanks[numFlank-1].start);
			flanks[numFlank-1].start = goalAlign.TargetStart;
		}
		flanks[0].end -= ((3-tmpPhase)%3);
		flankLen -= ((3-tmpPhase)%3);
		flanks[numFlank-1].start += (flankLen%3);
		flankLen -= (flankLen%3);

		for (i=0; i<numFlank; i++) { 
			relFlankLen[i] = flanks[i].end - flanks[i].start + 1;
			relFlankStart[i] = goalAlign.TargetEnd - flanks[i].end;
			relFlankEnd[i] = goalAlign.TargetEnd - flanks[i].start;
			//printf("relFlankStart[%d] = %d, relFlankEnd[%d] = %d \t", i, relFlankStart[i], i, relFlankEnd[i]); // for checking
		}
		//printf("\n\n"); // for checking
	}
	for (i=0; i<numFlank; i++) refinedLen += relFlankLen[i];
	//if (refinedLen != flankLen) fprintf(stderr, "** refinedLen == %d  != flankLen == %d **\n", refinedLen, flankLen); // for checking

	RefinedTargetString = (char *)malloc(sizeof(char) * (refinedLen + 1));
	RefinedQueryString =  (char *)malloc(sizeof(char) * (refinedLen + 1));
	IS_PRINT = (int *)malloc(sizeof(int) * refinedLen);
	for (i=0; i<refinedLen; i++) { 
		IS_PRINT[i] = 1;
		RefinedTargetString[i] = 'q';
		RefinedQueryString[i] = 'q';
	}

	l = 0; // count the bases of the chopped (final) sequence
	for (k=0; k<numFlank; k++) { 
		j = 0; // count the non-gap bases
		for (i=0; i<alignLen; i++) {
			if (l < refinedLen) {
				if (goalAlign.TargetString[i] != '-') {
					if (j <= relFlankEnd[k] && j >= relFlankStart[k]) {
						RefinedTargetString[l] = goalAlign.TargetString[i];
						RefinedQueryString[l] = goalAlign.QueryString[i];
						//if (goalAlign.TargetString[i] == goalAlign.QueryString[i]) matchBases++;
						//totalBases++;
						l++;
					}
					j++;
				} 
			} else break;
		}
	}

	RefinedTargetString[refinedLen] = '\0';
	RefinedQueryString[refinedLen] = '\0';
	//printf("RefinedTargetString:\n%s\nRefinedQueryString:\n%s\n\n", RefinedTargetString, RefinedQueryString); // for checking

	for (i=0; i<refinedLen-2; i+=3) { 
		if (RefinedQueryString[i] == '-' || RefinedQueryString[i+1] == '-' || RefinedQueryString[i+2] == '-' || 
		RefinedTargetString[i] == '-' || RefinedTargetString[i+1] == '-' || RefinedTargetString[i+2] == '-' || 
		RefinedTargetString[i] == '.' || RefinedTargetString[i+1] == '.' || RefinedTargetString[i+2] == '.' || 
		RefinedQueryString[i] == '.' || RefinedQueryString[i+1] == '.' || RefinedQueryString[i+2] == '.' || 
		RefinedTargetString[i] == 'q' || RefinedTargetString[i+1] == 'q' || RefinedTargetString[i+2] == 'q' || 
		RefinedQueryString[i] == 'q' || RefinedQueryString[i+1] == 'q' || RefinedQueryString[i+2] == 'q' || 
		((RefinedTargetString[i] == 't' || RefinedTargetString[i] == 'T') && (RefinedTargetString[i+1] == 'a' || RefinedTargetString[i+1] == 'A' ) && 
		(RefinedTargetString[i+2] == 'g'|| RefinedTargetString[i+2] == 'G' || RefinedTargetString[i+2] == 'a' || RefinedTargetString[i+2] == 'A')) || 
		((RefinedTargetString[i] == 't' || RefinedTargetString[i] == 'T') && (RefinedTargetString[i+1] == 'g' || RefinedTargetString[i+1] == 'G' ) && 
		(RefinedTargetString[i+2] == 'a'|| RefinedTargetString[i+2] == 'A')) || 
		((RefinedQueryString[i] == 't' || RefinedQueryString[i] == 'T') && (RefinedQueryString[i+1] == 'a' || RefinedQueryString[i+1] == 'A' ) && 
		(RefinedQueryString[i+2] == 'g'|| RefinedQueryString[i+2] == 'G' || RefinedQueryString[i+2] == 'a' || RefinedQueryString[i+2] == 'A')) || 
		((RefinedQueryString[i] == 't' || RefinedQueryString[i] == 'T') && (RefinedQueryString[i+1] == 'g' || RefinedQueryString[i+1] == 'G' ) && 
		(RefinedQueryString[i+2] == 'a'|| RefinedQueryString[i+2] == 'A')) ) { 
			IS_PRINT[i] = 0;
			IS_PRINT[i+1] = 0;
			IS_PRINT[i+2] = 0;
		}
	}

	for (i=0; i<refinedLen; i++) {
		if (IS_PRINT[i] != 0) {
			if (RefinedTargetString[i] == RefinedQueryString[i]) matchBases++;
			totalBases++;
		}
	}
	printf(">%s_", cand[0].chr);
	if (numNovel == 1) { 
		if (!strcmp(cand[0].Label, "NOVEL")) { 
			printf("%d_%d_%c_%s_identity=%2.2f_length=%d\n", cand[0].start, cand[0].end, cand[0].strand, cand[0].Label, 
			(float)matchBases/(float)totalBases, totalBases);
		} else if (!strcmp(cand[0].Label, "RETAIN")) { 
			printf("%d_%d_%c_%s_identity=%2.2f_length=%d\n", intron.start, intron.end, cand[0].strand, cand[0].Label, 
			(float)matchBases/(float)totalBases, totalBases);
		}
	} else { 
		for (i=0; i<numNovel; i++) printf("%d_%d_", cand[i].start, cand[i].end);
		printf("%c_%s_identity=%2.2f_length=%d\n", cand[0].strand, cand[0].Label, (float)matchBases/(float)totalBases, totalBases);
	}
	for (i=0; i<refinedLen; i++) { 
		if (IS_PRINT[i] != 0) printf("%c", RefinedTargetString[i]);
	}
	printf("\n");
	printf(">%s_%c\n", cand[0].MAX_EST, goalAlign.QueryStrand);
	for (i=0; i<refinedLen; i++) { 
		if (IS_PRINT[i] != 0) printf("%c", RefinedQueryString[i]);
	}
	printf("\n\n");

	free(IS_PRINT);
	free(RefinedTargetString);
	free(RefinedQueryString);
	
	return 0;
}

int OverLapLen(CANDIDATE cand, int rStart, int rEnd)
{
	int len = 0;
	int overStart = 0, overEnd = 0;

 	if (rStart <= cand.frontFlankStart) { 
		overStart = cand.frontFlankStart;
		if (cand.frontFlankStart <= rEnd) { 
			if (rEnd <= cand.frontFlankEnd) overEnd = rEnd;
			else overEnd = cand.frontFlankEnd;
			len = overEnd - overStart + 1;
		}
	} else if (rStart <= cand.frontFlankEnd) { 
		overStart = rStart;
		if (rEnd <= cand.frontFlankEnd) overEnd = rEnd;
		else overEnd = cand.frontFlankEnd;
		len = overEnd - overStart + 1;
	}

 	if (rStart <= cand.rearFlankStart) { 
		overStart = cand.rearFlankStart;
		if (cand.rearFlankStart <= rEnd) { 
			if (rEnd <= cand.rearFlankEnd) overEnd = rEnd;
			else overEnd = cand.rearFlankEnd;
			len += (overEnd - overStart + 1);
		}
	} else if (rStart <= cand.rearFlankEnd) { 
		overStart = rStart;
		if (rEnd <= cand.rearFlankEnd) overEnd = rEnd;
		else overEnd = cand.rearFlankEnd;
		len += (overEnd - overStart + 1);
	}
	return len;
}


char NucCompl(char ch) 
{
	switch (ch) {
		case 'a': 
			return 't';
		case 'A':
			return 'T';
		case 'c':
			return 'g';
		case 'C':
			return 'G';
		case 'g': 
			return 'c';
		case 'G':
			return 'C';
		case 't':
			return 'a';
		case 'T':
			return 'A';
		case '-':
			return '-';
		case '.': 
			return '.';
		default:
			return '-';
	}
}

