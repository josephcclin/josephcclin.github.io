#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SHIFT 10

typedef struct ENST_Exons {
        char chr[50];
        int start;
        int end;
        char strand[2];
        char ENSTID[50];
        char BioType[50];
} EXON;

typedef struct chr_search_range {
	int start_idx;
	int end_idx;                               
} CHR_SEARCH_RANGE;

typedef struct map_result { 
	char overlap_type[50];
	int length;
	float percent;
	int frontExt;
	int rearExt;
} MAP_RESULT;

typedef struct raw_candidate { 
	char Label[10];
	char chr[50];
	int start; 
	int end; 
	char strand[2];
	char ENSTID[50];
	char ESTID[50];
	int EST_start;
	int EST_end;
	int map_score; // newly added
	int MAP_COUNT;
	MAP_RESULT *mapList;
} CANDIDATE;

typedef struct MAX_EXON_LEN_AND_INDEX_IN_A_CHROMOSOME {
        char chr[50];
        int len;
        int start_idx;
        int end_idx;
} EXON_MAX_LEN_INDEX;


CHR_SEARCH_RANGE indexSearch(EXON_MAX_LEN_INDEX *Exon_Len_Idx, int numChrs, EXON *ExonList, CANDIDATE entry);
void printCandidate(FILE *fp, CANDIDATE entry);


int main(int argc, char **argv)
{
        FILE *CandFile, *ExonFile, *outputFile, *MaxExonLenFile;
	int i = 0, j = 0;
	int numChrs = 0;
	int numEnstExons = 0;
	int flagFalsePositive = 0;
	int OverlapLen = 0;
	char tmpChr[50] = "";
	char buffer[512];
	CANDIDATE entry = {"", "", 0, 0, "", "", "", 0, 0, 0, 0, NULL};
	CHR_SEARCH_RANGE searchRange = {-1, -1};
	int scanVal = 0;

        if (argc != 4) {
                printf("Usage:\n\t./AS_Exon_Removal [RAW_CANDIDATES] [EXONS_PROCESSED] [OUTPUT_FILE]\n\n");
                exit(EXIT_FAILURE);
        }

        if ((CandFile = fopen(argv[1], "r")) == NULL ) {
                fprintf(stderr, "** Error in opening %s. **\n", argv[1]);
                exit(EXIT_FAILURE);
        }
        if ((ExonFile = fopen(argv[2], "r")) == NULL ) {
                fprintf(stderr, "** Error in opening %s. **\n", argv[2]);
                exit(EXIT_FAILURE);
        }
        if ((outputFile = fopen(argv[3], "w")) == NULL ) {
                fprintf(stderr, "** Error in opening %s. **\n", argv[3]);
                exit(EXIT_FAILURE);
        }
        if ((MaxExonLenFile = fopen("ENST_EXON_LEN", "r")) == NULL) {
                fprintf(stderr, "** Error in opening ENST_EXON_LEN (initialization stage). **\n");
                exit(EXIT_FAILURE);
        }

	while (fgets(buffer, 512, MaxExonLenFile) != NULL) {
                numChrs++;
        }
        fseek(MaxExonLenFile, 0, SEEK_SET);
        EXON_MAX_LEN_INDEX *Exon_Len_Idx = (EXON_MAX_LEN_INDEX *)malloc(sizeof(EXON_MAX_LEN_INDEX) * numChrs);

        while (fscanf(MaxExonLenFile, "%s %d", Exon_Len_Idx[i].chr, &Exon_Len_Idx[i].len) != EOF) {
		i++;
        }
        i = 0;
        fclose(MaxExonLenFile);

        while (fgets(buffer, 512, ExonFile) != NULL) {
		numEnstExons++;
        }
        EXON *ExonList = (EXON *)malloc(sizeof(EXON) * numEnstExons);

        if (ExonList == NULL) {
                fprintf(stderr, "** Memory allocation error for %s. **\n", argv[3]);
                exit(EXIT_FAILURE);
        }
        if (Exon_Len_Idx == NULL) {
                fprintf(stderr, "** Memory allocation error for indexing exons. **\n");
                exit(EXIT_FAILURE);
        }
        fseek(ExonFile, 0, SEEK_SET);

        while (fscanf(ExonFile, "%s %d %d %s %s %s", ExonList[j].chr, &ExonList[j].start, &ExonList[j].end, ExonList[j].strand,
        ExonList[j].ENSTID, ExonList[j].BioType) != EOF) {
		if (strcmp(tmpChr, ExonList[j].chr)) { 
			strcpy(tmpChr, ExonList[j].chr); 
			for (i=0; i<numChrs; i++) { 
				if (!strcmp(tmpChr, Exon_Len_Idx[i].chr)) { 
					Exon_Len_Idx[i].start_idx = j;
					Exon_Len_Idx[i].end_idx = j;
					break;
				}
			}	
			
		} else {
			Exon_Len_Idx[i].end_idx = j;
		}
		j++;
        }
        fclose(ExonFile);
	i = 0;

	while (fscanf(CandFile, "%s %s %d %d %s %s %s %d %d %d %d", entry.Label, entry.chr, &entry.start, &entry.end, entry.strand, 
	entry.ENSTID, entry.ESTID, &entry.EST_start, &entry.EST_end, &entry.map_score, &entry.MAP_COUNT) != EOF)  {
		if (entry.MAP_COUNT == 0) entry.mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT));
		else entry.mapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT) * entry.MAP_COUNT);

		if (entry.mapList == NULL) {
			fprintf(stderr, "** Memory allocation error for the candidates. **\n"); 
			exit(EXIT_FAILURE);
		}
		if (entry.MAP_COUNT > 0) { 
			for (j=0; j<entry.MAP_COUNT; j++) { 
				scanVal = fscanf(CandFile, "%s %d %f %d %d", entry.mapList[j].overlap_type, &entry.mapList[j].length, 
				&entry.mapList[j].percent, &entry.mapList[j].frontExt, &entry.mapList[j].rearExt);
				if (scanVal != 5) fprintf(stderr, "** File reading error in AS_Exon_Removal **\n");
			}
		} else {
			scanVal = fscanf(CandFile, "%s %d %f %d %d", entry.mapList[0].overlap_type, &entry.mapList[0].length, 
			&entry.mapList[0].percent, &entry.mapList[0].frontExt, &entry.mapList[0].rearExt);
			if (scanVal != 5) fprintf(stderr, "** File reading error in AS_Exon_Removal **\n");
		}
		searchRange = indexSearch(Exon_Len_Idx, numChrs, ExonList, entry);
		if (searchRange.start_idx != -1) {
			for (i=searchRange.start_idx; i<=searchRange.end_idx; i++) { 
				if (!strcmp(entry.Label, "RETAIN")) { // filtering false-positive novel retained introns
					if (ExonList[i].start <= entry.end + entry.mapList[0].rearExt + 1 &&
					entry.start + entry.mapList[1].frontExt - 1 <= ExonList[i].end) {
						flagFalsePositive = 1;
						break;
					}
				} else if (!strcmp(entry.Label, "NOVEL")) { // filtering false-positive novel internal exons 
                                        if (ExonList[i].start <= entry.start && entry.start <= ExonList[i].end && ExonList[i].end <= entry.end) {
                                                OverlapLen = ExonList[i].end - entry.start + 1;
                                        } else if (entry.start <= ExonList[i].start && ExonList[i].start <= entry.end && entry.end <= ExonList[i].end) {
                                                OverlapLen = entry.end - ExonList[i].start + 1;
                                        } else if (ExonList[i].start <= entry.start && entry.end <= ExonList[i].end) {
                                                OverlapLen = entry.end - entry.start + 1;
                                        } else if (entry.start <= ExonList[i].start && ExonList[i].end <= entry.end) {
                                                OverlapLen = ExonList[i].end - ExonList[i].start + 1;
                                        } else OverlapLen = 0;
					if ((float)OverlapLen/(float)(ExonList[i].end - ExonList[i].start + 1) > 0.5) {
						//printf("** OverlapLen = %d ** \n", OverlapLen);
						flagFalsePositive = 1;
						break;
					}
				}
			}
		}
		if (flagFalsePositive == 0) printCandidate(outputFile, entry);
		else flagFalsePositive = 0;
		free(entry.mapList);
	}

	free(Exon_Len_Idx);
	free(ExonList);
	fclose(CandFile);
	fclose(outputFile);
	return 0;
}

CHR_SEARCH_RANGE indexSearch(EXON_MAX_LEN_INDEX *Exon_Len_Idx, int numChrs, EXON *ExonList, CANDIDATE entry)
{
	int i = 0; 
	int maxExonLen = 0; 
	int begin = 0; 
	int end = 0;
	int tmp_begin = 0;
	int tmp_end = 0;
	int flagNotFound = 0;
	int minEntryStart = 0;
	int maxEntryEnd = 0;
	CHR_SEARCH_RANGE rIndex = {-1, -1};
	
	for (i=0; i<numChrs; i++) {
		if (!strcmp(entry.chr, Exon_Len_Idx[i].chr)) { 
			tmp_begin = Exon_Len_Idx[i].start_idx;
			tmp_end = Exon_Len_Idx[i].end_idx;
			maxExonLen = Exon_Len_Idx[i].len;
			break;
		}
	}
	if (!strcmp(entry.Label, "RETAIN")) {
		minEntryStart = (entry.start < entry.start + entry.mapList[0].frontExt) ? entry.start : entry.start + entry.mapList[0].frontExt;
		maxEntryEnd = (entry.end > entry.end + entry.mapList[1].rearExt) ? entry.end : entry.end + entry.mapList[1].rearExt;
		while (ExonList[tmp_begin].start + maxExonLen < minEntryStart) {
			begin = tmp_begin;
			if (tmp_end - tmp_begin > 1) tmp_begin = (tmp_begin + tmp_end)/2;
			else if (tmp_end - tmp_begin == 1) tmp_begin++;
			else {
				flagNotFound = 1;
				break;
			}
		}
		if (flagNotFound == 0) {
			while (ExonList[tmp_end].start > maxEntryEnd) {
				end = tmp_end;
				if (tmp_end - begin > 1) tmp_end = (begin + tmp_end)/2;
				else if (tmp_end - begin == 1) break;
				else {
					flagNotFound = 1;
					break;
				}
			}
		}
		if (flagNotFound == 0) {
			rIndex.start_idx = begin;
			rIndex.end_idx = end;
		}
	} else {
		while (ExonList[tmp_begin].start + maxExonLen < entry.start) {
			begin = tmp_begin;
			if (tmp_end - tmp_begin > 1) tmp_begin = (tmp_begin + tmp_end)/2;
			else if (tmp_end - tmp_begin == 1) tmp_begin++;
			else {
				flagNotFound = 1;
				break;
			}
		}
		if (flagNotFound == 0) {
			while (ExonList[tmp_end].start > entry.end) {
				end = tmp_end;
				if (tmp_end - begin > 1) tmp_end = (begin + tmp_end)/2;
				else if (tmp_end - begin == 1) break;
				else {
					flagNotFound = 1;
					break;
				}
			}
		}
		if (flagNotFound == 0) {
			rIndex.start_idx = begin;
			rIndex.end_idx = end;
		}
	}
	return rIndex;
}

void printCandidate(FILE *fp, CANDIDATE entry)
{
	int i = 0, count = 0;
	
	fprintf(fp, "%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d", entry.Label, entry.chr, entry.start, entry.end, 
	entry.strand, entry.ENSTID, entry.ESTID, entry.EST_start, entry.EST_end, entry.map_score, entry.MAP_COUNT);
	if (entry.MAP_COUNT == 0) count = 1;
	else count = entry.MAP_COUNT;

	for (i=0; i<count; i++) fprintf(fp, "\t%s\t%d\t%1.4f\t%d\t%d", entry.mapList[i].overlap_type, 
	entry.mapList[i].length, entry.mapList[i].percent, entry.mapList[i].frontExt, entry.mapList[i].rearExt);
	fprintf(fp, "\n");
}

