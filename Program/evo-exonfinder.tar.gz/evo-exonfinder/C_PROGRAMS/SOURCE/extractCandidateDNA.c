#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct candidate { 
	char Label[10]; 
	char signal[5];
	char chr[50]; 
	int start; 
	int end; 
	char strand[2]; 
	char ENSTID[50]; 
	char ESTID[50]; 
	int InitStart;
	int InitEnd;
	int mapScore;
	int ENST_start;
	int ENST_end;
	char *flanking;
	int novelLen;
} CANDIDATE;

char codon[64][2][3] = { 
	{"AAA", "K"}, {"AAC", "N"}, {"AAG", "K"}, {"AAT", "N"}, 
	{"ACA", "T"}, {"ACC", "T"}, {"ACG", "T"}, {"ACT", "T"}, 
	{"AGA", "R"}, {"AGC", "S"}, {"AGG", "R"}, {"AGT", "S"}, 
	{"ATA", "I"}, {"ATC", "I"}, {"ATG", "M"}, {"ATT", "I"},
	{"CAA", "Q"}, {"CAC", "H"}, {"CAG", "Q"}, {"CAT", "H"}, 
	{"CCA", "P"}, {"CCC", "P"}, {"CCG", "P"}, {"CCT", "P"}, 
	{"CGA", "R"}, {"CGC", "R"}, {"CGG", "R"}, {"CGT", "R"}, 
	{"CTA", "L"}, {"CTC", "L"}, {"CTG", "L"}, {"CTT", "L"},
	{"GAA", "E"}, {"GAC", "D"}, {"GAG", "E"}, {"GAT", "D"},
	{"GCA", "A"}, {"GCC", "A"}, {"GCG", "A"}, {"GCT", "A"}, 
	{"GGA", "G"}, {"GGC", "G"}, {"GGG", "G"}, {"GGT", "G"},
	{"GTA", "V"}, {"GTC", "V"}, {"GTG", "V"}, {"GTT", "V"}, 
	{"TAA", "*"}, {"TAC", "Y"}, {"TAG", "*"}, {"TAT", "Y"}, 
	{"TCA", "S"}, {"TCC", "S"}, {"TCG", "S"}, {"TCT", "S"}, 
	{"TGA", "*"}, {"TGC", "C"}, {"TGG", "W"}, {"TGT", "C"}, 
	{"TTA", "L"}, {"TTC", "F"}, {"TTG", "L"}, {"TTT", "F"},      
};

char NucComplement(char Nuc);
void print_candidate_gDNA(char *DNA, int sizeChr, CANDIDATE *candidateArray, int numExons, int seqLen);
int AA_map(char *sequence, int sequence_length);

int main(int argc, char** argv)
{
	FILE *candFile, *fpChr;
	int i = 0; 
	//int j = 0;
	int numExons;
	int sizeChr = 0;
	int seqLen = 0;
	int progress = 0;
        char tmpChr[50] = "";
	char chr_name[50] = "";
        char tmpDIR[150] = "";
	char Flanking[500];
	char *chr_DNA = "";
	char delim;
	int scanVal = 0;

	if ((candFile = fopen(argv[1], "r")) == NULL || argc != 3) {
		if (argc != 3) fprintf(stderr, "Usage:\n\t./extractCandidateDNA [PROTEIN_CODING_MAP_BLOCKS] [DIR_CHROMOSOMES]\n\n");
		else if (argv[1] == NULL) fprintf(stderr, "** File ([PROTEIN_CODING_MAP_BLOCKS]) error! **\n");
		exit(EXIT_FAILURE);
	}

	while (fscanf(candFile, "%d", &numExons) != EOF) { 
		CANDIDATE *entArr = (CANDIDATE *)malloc(sizeof(CANDIDATE) * numExons); 
		if (entArr == NULL) { 
			fprintf(stderr, "** Memory allocation error for [CANDIDATES.CATMAP] **\n");
			exit(EXIT_FAILURE);
		}
		for (i=0; i<numExons; i++) { 
			scanVal = fscanf(candFile, "%s %s %s %d %d %s %s %s %d %d %d %d %d %s %d", entArr[i].Label, entArr[i].signal, entArr[i].chr, &entArr[i].start, 
			&entArr[i].end, entArr[i].strand, entArr[i].ENSTID, entArr[i].ESTID, &entArr[i].InitStart, &entArr[i].InitEnd, &entArr[i].mapScore, 
			&entArr[i].ENST_start, &entArr[i].ENST_end, Flanking, &entArr[i].novelLen); 
			if (scanVal != 15) fprintf(stderr, "** File reading error in extractCandidateDNA **\n");
			seqLen += (entArr[i].end - entArr[i].start + 1);
			entArr[i].flanking = (char *)malloc(sizeof(char) * (strlen(Flanking)+1));
			strcpy(entArr[i].flanking, Flanking);
		}
		/*for (i=0; i<numExons; i++) { 
			printf("%s %s %s %d %d %s %s %s %d %d %d %d %d %s %d\n", entArr[i].Label, entArr[i].signal, entArr[i].chr, entArr[i].start, entArr[i].end, 
			entArr[i].strand, entArr[i].ENSTID, entArr[i].ESTID, entArr[i].InitStart, entArr[i].InitEnd, entArr[i].mapScore, entArr[i].ENST_start, entArr[i].ENST_end, 
			entArr[i].flanking, entArr[i].novelLen); 
		}*/
                if (strcmp(tmpChr, entArr[0].chr)) {
			if (strcmp(tmpChr, "")) {
				free(chr_DNA);
			}
			progress++;
			strcpy(tmpChr, entArr[0].chr);
			strcpy(tmpDIR, argv[2]);

                        if (tmpDIR[strlen(tmpDIR)-1] != '/') {
                                strcat(tmpDIR, "/");
                        }
			strcat(tmpDIR, entArr[0].chr);
			strcat(tmpDIR, ".fa");
                       
			//fprintf(stderr, "## Scanning candidates in %s\n", entArr[0].chr);
			if ((fpChr = fopen(tmpDIR, "r")) == NULL) {
				fprintf(stderr, "** Error in opening %s **\n", tmpDIR);
				exit(EXIT_FAILURE);
			}
			while (fscanf(fpChr, "%s %d", chr_name, &sizeChr) != EOF) {
				chr_DNA = malloc(sizeof(char) * (sizeChr + 1));
				if (chr_DNA == NULL) {
					fprintf(stderr, "** Memory allocation error for %s. **\n", chr_name);
					exit(EXIT_FAILURE);
				}
				scanVal = fscanf(fpChr, "%c", &delim);
				if (scanVal != 1) fprintf(stderr, "** File reading error in extractCandidateDNA **\n");
				/*while (j < sizeChr) {
				        fscanf(fpChr, "%c", &(chr_DNA[j]));
				        j++;
				}*/
				if (fgets(chr_DNA, (sizeChr + 1), fpChr) == NULL) fprintf(stderr, "** File reading error in extractCandidateDNA **\n");
				chr_DNA[sizeChr] = '\0';
				//j = 0;
			}
			fclose(fpChr);
			if (progress == 2) fprintf(stderr, "\b\b\b25%%");
			else if (progress == 6) fprintf(stderr, "\b\b\b50%%");
			else if (progress == 10) fprintf(stderr, "\b\b\b75%%");
			else if (progress == 15) fprintf(stderr, "\b\b\b90%%");
		}
		print_candidate_gDNA(chr_DNA, sizeChr, entArr, numExons, seqLen);
		for (i=0; i<numExons; i++) free(entArr[i].flanking);
		free(entArr);
		seqLen = 0;
	}
	//free(chr_DNA);
	fclose(candFile);
	return 0;
}

char NucComplement(char c)
{
	switch(c) {
                case 'A':
                        return 'T';
                        break;
                case 'C':
                        return 'G';
                        break;
                case 'G':
                        return 'C';
                        break;
                case 'T':
                        return 'A';
                        break;
                case 'a':
                        return 't';
                        break;
                case 'c':
                        return 'g';
                        break;
                case 'g':
                        return 'c';
                        break;
                case 't':
                        return 'a';
                        break;
                default:
			//fprintf(stderr, "NucComplement error!\n");
			return '-';
			break;                                                                        
	}
}
                
void print_candidate_gDNA(char *chr_DNA, int sizeChr, CANDIDATE *canArr, int numExons, int seqLen)
{
	int i = 0, j = 0, k = 0; 
	int is_STOP;
	int qStart = 0, qEnd = 0;
	char *outSeq = (char *)malloc((sizeof(char) * seqLen) + 1);

	for (i=0; i<numExons; i++) {
		printf("## %s\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%s\t%d\n", canArr[i].Label, canArr[i].signal, canArr[i].chr, 
		canArr[i].start, canArr[i].end, canArr[i].strand, canArr[i].ENSTID, canArr[i].ESTID, canArr[i].InitStart, canArr[i].InitEnd, 
		canArr[i].mapScore, canArr[i].ENST_start, canArr[i].ENST_end, canArr[i].flanking, canArr[i].novelLen);
	}
	for (i=0; i<numExons; i++) { 
		qStart = canArr[i].start - 1;
		qEnd = canArr[i].end - 1;

	        if (!strcmp(canArr[i].strand, "-")) {
			for (j = qEnd; j >= qStart; j--) {
				outSeq[k] = NucComplement(chr_DNA[j]);
				k++;
			}
		} else {
			for (j = qStart; j<= qEnd; j++) {
				outSeq[k] = chr_DNA[j];
				k++;
			}
		}
	}
	outSeq[k] = '\0';
	is_STOP = AA_map(outSeq, seqLen);
	if (is_STOP != -1) printf("## STOP: %d\n\n", is_STOP); 
	free(outSeq);
}

int AA_map(char *seq, int seqLen)
{
	int i = 0, j = 0, k = 0;
	int isSTOP = -1;
	char *PepSeq = (char *)malloc(sizeof(char) * seqLen/3 + 1);
	if (PepSeq == NULL) {
		fprintf(stderr, "** Memory allocation error in running AA_map (seqLen = %d) **\n", seqLen);
		exit(EXIT_FAILURE);
	}

	for (i=0; i<seqLen-2; i+=3) { 
		for (j=0; j<64; j++) { 
			if (seq[i] == codon[j][0][0] && seq[i+1] == codon[j][0][1] && seq[i+2] == codon[j][0][2]) {
				if (codon[j][1][0] == '*') { isSTOP = i; break; } 
				else PepSeq[k] = codon[j][1][0];
			}
		}
		if (isSTOP != -1) break;
		else k++;
	}
	PepSeq[seqLen/3] = '\0';
	if (isSTOP == -1) printf("%s\n\n", PepSeq);
	free(PepSeq);
	return isSTOP;
}
