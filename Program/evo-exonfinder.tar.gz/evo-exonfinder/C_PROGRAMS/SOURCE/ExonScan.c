#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct ENST_Exons {
        char chr[50]; 
        int start; 
        int end;
	char strand[5];
	char ENSTID[50];
	char BioType[50];
} Exon;

typedef struct EST_META_BLOCK {
        char chr[50]; 
        int start; 
        int end;
	char strand[5];
	char EST_ID[50];
	int map_score; // Newly added
	int blockCount; 
} METABLOCK;

typedef struct EST_BLOCK {
        char chr[50]; 
        int start; 
        int end;
	char strand[5];
	char EST_ID[50];
	int map_score;
	int EST_start; 
	int EST_end; 
} BLOCK;

typedef struct ENST_Index { 
	char chr[50];
	int start; 
	int end;
	char strand[5];
	char ENSTID[50]; 
	char BioType[50];
	int idx_first; 
	int idx_last; 
	int maxENSTlen;
} ENST_Index;

typedef struct ENST_search_range { 
	int ENST_start_idx;
	int ENST_end_idx;
} ENST_SEARCH_RANGE; 

typedef struct MAX_ENST_LEN_AND_INDEX_IN_A_CHROMOSOME { 
	char chr[50];
	int len;
	int start_idx;
	int end_idx;
	int ENST_start_idx;
	int ENST_end_idx;
} ENST_MAX_LEN;

typedef struct map_result {
        char overlap_type[50];
        int length;
        float percent;
        int frontExt;
        int rearExt;
} MAP_RESULT;

typedef struct scan_result {
        char chr[50];
        int start;
        int end;
        char strand[2];
        char ESTID[50];
        int EST_START;
        int EST_END;
	int map_score;
        int MAP_COUNT;
        char ENSTID[50];
        MAP_RESULT *mapList;
} SCAN_RESULT;


int maxLenSearch(char *chromosome, ENST_MAX_LEN *LenArray, int numChrs); // Obtain the length of the longest transcript in the specified chromosome
int ShowProgress(int current, int all);
ENST_SEARCH_RANGE indexSearch(ENST_Index *indexList, int numENSTs, ENST_MAX_LEN *ENST_LEN_LIST, int numChrs, METABLOCK qEntry);
SCAN_RESULT OverLapCheck(FILE *fp, BLOCK entry, Exon *ExonList, int first_index, int last_index);
void printBlock(FILE *fp, SCAN_RESULT entryScan);


int main(int argc, char **argv)
{
	FILE *BlockFile, *EnstFile, *outputFile, *MaxENSTLenFile;
	//clock_t start_time, end_time;
	int i = 0, j = 0, k = 0, l = 0, p = 0; 
	int countExons = 0; 
	int numChrs = 0, numENSTExons = 0, numENSTs = 0;
	//int flag = 0; 
	int flagPrint = 0; 
	int setCount = 0, setCurrent = 0, totalBlockCount = 0; // required for ShowProgress
	//float total_time = 0;
	char buffer[512];
	char tmpChr[50] = "";
	int scanVal = 0;
	METABLOCK m_entry= {"", 0, 0, "", "", 0, 0}; 
	ENST_SEARCH_RANGE qENST_idx; 
	
	if (argc < 4) { 
		printf("Usage:\n\t./ExonScan [BLAT_BLOCKS] [ENST_PROCESSED] [OUTPUT_FILE]\n\n");
		exit(EXIT_FAILURE);
	}
	if ((BlockFile = fopen(argv[1], "r")) == NULL ) {
                fprintf(stderr, "** Error in opening %s. **\n", argv[1]);
                exit(EXIT_FAILURE);
        }
	if ((EnstFile = fopen(argv[2], "r")) == NULL ) {
                fprintf(stderr, "** Error in opening %s. **\n", argv[2]);
                exit(EXIT_FAILURE);
        }
	if ((outputFile = fopen(argv[3], "w")) == NULL ) {
                fprintf(stderr, "** Error in opening %s. **\n", argv[3]);
                exit(EXIT_FAILURE);
        }
	if ((MaxENSTLenFile = fopen("ENST_LEN", "r")) == NULL) {
		fprintf(stderr, "** Error in opening ENST_Range (initialization stage). **\n");
		exit(EXIT_FAILURE);
	}

	// Start time: 
	//start_time = clock(); /* microseconds */
 
	while (fgets(buffer, 512, MaxENSTLenFile) != NULL) {  // get the total number of lines of the target file
		numChrs++;
	}
	fseek(MaxENSTLenFile, 0, SEEK_SET);
	ENST_MAX_LEN *ENST_LEN_LIST = (ENST_MAX_LEN *)malloc(sizeof(ENST_MAX_LEN) * numChrs);

	while (fscanf(MaxENSTLenFile, "%s %d", ENST_LEN_LIST[i].chr, &ENST_LEN_LIST[i].len) != EOF) { 
		// To derive the maximum length of a transcript in a specific chromosome
		i++;
	}
	i = 0;
	fclose(MaxENSTLenFile);

	while (fgets(buffer, 512, BlockFile) != NULL) {  // get the total number of lines of the target file
		if (buffer[0] == 'c') { 
			setCount++;
		} else { 
			totalBlockCount++;
		}
	}
	fseek(BlockFile, 0, SEEK_SET);
	fprintf(stderr, "## %d set of %d blocks to check.\n", setCount, totalBlockCount);

	while (fgets(buffer, 512, EnstFile) != NULL) { // To derive the number of transcripts and exons
		if (buffer[0] == 'c') { 
			numENSTs++;
		} else { 
			numENSTExons++;
		}
	}
	Exon *ExonList = (Exon *)malloc(sizeof(Exon) * numENSTExons);
	ENST_Index *ENST_IDX = (ENST_Index *)malloc(sizeof(ENST_Index) * numENSTs);
	
	if (ExonList == NULL) { 
		fprintf(stderr, "** Memory allocation error for %s. **\n", argv[3]);
		exit(EXIT_FAILURE);
	}
	if (ENST_IDX == NULL) { 
		fprintf(stderr, "** Memory allocation error for indexing exons. **\n");
		exit(EXIT_FAILURE);
	}
	fseek(EnstFile, 0, SEEK_SET);

	while (fscanf(EnstFile, "%s %d %d %s %s %s %d", ENST_IDX[i].chr, &ENST_IDX[i].start, &ENST_IDX[i].end, ENST_IDX[i].strand, 
	ENST_IDX[i].ENSTID, ENST_IDX[i].BioType, &countExons) != EOF) {
		if (strcmp(tmpChr, ENST_IDX[i].chr)) { 
			strcpy(tmpChr, ENST_IDX[i].chr);
			for (l=0; l<numChrs; l++) { 
				if (!strcmp(ENST_IDX[i].chr, ENST_LEN_LIST[l].chr)) { 
					ENST_LEN_LIST[l].start_idx = j;
					ENST_LEN_LIST[l].end_idx = j + countExons - 1;
					ENST_LEN_LIST[l].ENST_start_idx = i;
					ENST_LEN_LIST[l].ENST_end_idx = i;
					break;
				}
			}
		} else { 
			ENST_LEN_LIST[l].end_idx += countExons; 
			ENST_LEN_LIST[l].ENST_end_idx += 1;
		}

		ENST_IDX[i].idx_first = j;
		ENST_IDX[i].idx_last = j+countExons-1;
		ENST_IDX[i].maxENSTlen = maxLenSearch(ENST_IDX[i].chr, ENST_LEN_LIST, numChrs);
		for (k=0; k<countExons; k++) { 
			scanVal = fscanf(EnstFile, "%d %d", &ExonList[j].start, &ExonList[j].end); 
			if (scanVal != 2) fprintf(stderr, "** File reading error in ExonScan **\n");
			strcpy(ExonList[j].chr,     ENST_IDX[i].chr);
			strcpy(ExonList[j].strand,  ENST_IDX[i].strand); 
			strcpy(ExonList[j].ENSTID,  ENST_IDX[i].ENSTID); 
			strcpy(ExonList[j].BioType, ENST_IDX[i].BioType);
			j++; 
		}
		i++;
	}
	fclose(EnstFile);

	fprintf(stderr, "Progress:   %%");
	fprintf(outputFile, "#Chr\tStart\tEnd\tStrand\tEST_ID\tEST_Start\tEST_End\tMapping_Score\t#Mapped_Exons\tENST_ID\t");
	fprintf(outputFile, "Overlap_Type\tAlignable_Length\tAlignable_Percentage\tFront_Extend\tRear_Extend\n");

	
	while (fscanf(BlockFile, "%s %d %d %s %s %d %d", m_entry.chr, &m_entry.start, &m_entry.end, m_entry.strand, 
	m_entry.EST_ID, &m_entry.map_score, &m_entry.blockCount) != EOF) { 
		setCurrent++;
		qENST_idx = indexSearch(ENST_IDX, numENSTs, ENST_LEN_LIST, numChrs, m_entry);
		BLOCK *entry = (BLOCK *)malloc(sizeof(BLOCK) * m_entry.blockCount);

		for (i=0; i<m_entry.blockCount; i++) { 
			scanVal = fscanf(BlockFile, "%d %d %d %d", &entry[i].start, &entry[i].end, &entry[i].EST_start, &entry[i].EST_end); 
			strcpy(entry[i].chr, m_entry.chr);
			if (scanVal != 4) fprintf(stderr, "** File reading error in ExonScan **\n");
			strcpy(entry[i].strand, m_entry.strand);
			strcpy(entry[i].EST_ID, m_entry.EST_ID);
			entry[i].map_score = m_entry.map_score;
		}
		if (qENST_idx.ENST_start_idx != -1) { // scanning the current set of blocks
			for (j=qENST_idx.ENST_start_idx; j<=qENST_idx.ENST_end_idx; j++) { 
				SCAN_RESULT *entryScan = (SCAN_RESULT *)malloc(sizeof(SCAN_RESULT) * m_entry.blockCount);
				if (entryScan == NULL) { 
					fprintf(stderr, "** Memory allocation error for scanning result (entryScan) **\n"); 
					exit(EXIT_FAILURE);
				}
				for (i=0; i<m_entry.blockCount; i++) { 
					entryScan[p] = OverLapCheck(outputFile, entry[i], ExonList, ENST_IDX[j].idx_first, ENST_IDX[j].idx_last);
					p++;
				}
				for (p=0; p<m_entry.blockCount; p++) { 
					if (entryScan[p].MAP_COUNT > 0) {
						flagPrint = 1;
						break;
					}
				}
				if (flagPrint == 1) { 
					for (p=0; p<m_entry.blockCount; p++) { 
						printBlock(outputFile, entryScan[p]);
						free(entryScan[p].mapList);
					}
					fprintf(outputFile, "\n");
					flagPrint = 0;
				} else { 
					for (p=0; p<m_entry.blockCount; p++) { 
						free(entryScan[p].mapList);
					}
				}
				p = 0;
				free(entryScan);
			}
		}
		free(entry); 
		ShowProgress(setCurrent, setCount);
	}

	free(ENST_LEN_LIST);
	free(ExonList);
	free(ENST_IDX);

	fclose(BlockFile);
	fclose(outputFile);
	// End time:
	//end_time = clock();
	//total_time = (float)(end_time - start_time)/CLOCKS_PER_SEC; // Total execution time: 
	//fprintf(stderr, "## Execution Time of Adding Ensembl Annotations: %f seconds. ##\n", total_time);
	return 0;
}

int maxLenSearch(char *qChr, ENST_MAX_LEN *LenArray, int numChrs)
{
	int i; 

	for (i=0; i<numChrs; i++) { 
		if (!strcmp(LenArray[i].chr, qChr)) return LenArray[i].len;
	}
	fprintf(stderr, "** Error in searching for longest ENST transcript in %s**\n", qChr);
	return 0;
}


int ShowProgress(int current, int all)
{
	float progress = (float)current/(float)all;
        if (progress >= 0.001 && progress < 0.00105) {
        	fprintf(stderr, "\b\b\b<1%%");
	} else if (progress >= 0.01 && progress < 0.0105) {
		fprintf(stderr, "\b\b\b 1%%");
	} else if (progress >= 0.05 && progress < 0.0505) {
		fprintf(stderr, "\b\b\b 5%%");
	} else if (progress >= 0.1 && progress < 0.105) {
		fprintf(stderr, "\b\b\b10%%");
	} else if (progress >= 0.2 && progress < 0.205) {
		fprintf(stderr, "\b\b\b20%%");
	} else if (progress >= 0.25 && progress < 0.255) {
		fprintf(stderr, "\b\b\b25%%");
	} else if (progress >= 0.5 && progress < 0.55) {
		fprintf(stderr, "\b\b\b50%%");
	} else if (progress >= 0.75 && progress < 0.7505) {
		fprintf(stderr, "\b\b\b75%%");
	} else if (progress >= 0.9 && progress < 0.905) {
		fprintf(stderr, "\b\b\b90%%");
	} else if (progress >= 0.99 && progress < 0.9905) {
		fprintf(stderr, "\b\b\b99%%");
	} else if (progress == 1) {
		fprintf(stderr, "\b\b\b100%%\n");
	} else {
                        // do nothing
	}
	return 0;
}


ENST_SEARCH_RANGE indexSearch(ENST_Index *indexList, int numENSTs, ENST_MAX_LEN *ENST_LEN_LIST, int numChrs, METABLOCK qEntry)
{
	int i = 0; 
	int begin = 0, end = 0, tmp_begin = 0, tmp_end = 0; 
	//int chr_start = 0, chr_end = 0;
	int chr_enst_start = 0, chr_enst_end = 0;	
	int flagNotFound = 0;
	ENST_SEARCH_RANGE reIndex = {-1, -1}; 
	
	for (i=0; i<numChrs; i++) { 
		if (!strcmp(ENST_LEN_LIST[i].chr, qEntry.chr)) { 
			//chr_start = ENST_LEN_LIST[i].start_idx; 
			//chr_end = ENST_LEN_LIST[i].end_idx; 
			chr_enst_start = ENST_LEN_LIST[i].ENST_start_idx; 
			chr_enst_end = ENST_LEN_LIST[i].ENST_end_idx; 
			break;
		}
	}
	tmp_begin = chr_enst_start;
	tmp_end = chr_enst_end;

	while (indexList[tmp_begin].start + indexList[tmp_begin].maxENSTlen < qEntry.start) {
		begin = tmp_begin; 
		if (tmp_end - tmp_begin > 1) tmp_begin = (tmp_begin + tmp_end)/2;
		else if (tmp_end - tmp_begin == 1) tmp_begin++; 
		else { 
			flagNotFound = 1;
			break;
		}
	}
	if (flagNotFound == 0) {
		while (indexList[tmp_end].start > qEntry.end) {
			end = tmp_end;
			if (tmp_end - begin > 1) tmp_end = (begin + tmp_end)/2;
			else if (tmp_end - begin == 1) break;
			else { 
				flagNotFound = 1;
				break;
			}
		}
	}
	if (flagNotFound == 0) {
		for (i=begin; i<=end; i++) { 
			if ((indexList[i].start <= qEntry.start && qEntry.start + 10 <= indexList[i].end) || 
			(indexList[i].start + 10 <= qEntry.end && qEntry.end <= indexList[i].end) || 
			(qEntry.start <= indexList[i].start && indexList[i].end <= qEntry.end)) {
                                if (reIndex.ENST_start_idx == -1) {
                                        reIndex.ENST_start_idx = i;
                                        reIndex.ENST_end_idx = i;
                                } else {
                                        reIndex.ENST_end_idx = i;
                                }
                        } else if (qEntry.end < indexList[i].start) break;
                }
	}  
	return reIndex;
}

SCAN_RESULT OverLapCheck(FILE *fp, BLOCK entry, Exon *ExonList, int first_index, int last_index) 
{
	int i = 0, k = 0, mapCount = 0; 
	enum { headOverlap = 1, tailOverlap = 2, fullyContain = 3, properSubset = 4 };
	int exonLen = 0;
	int *Flag = malloc(sizeof(int)* (last_index - first_index + 1));
	SCAN_RESULT entryScan = {"", 0, 0, "", "", 0, 0, 0, 0, "", NULL};
	MAP_RESULT *tmpMapList;

	strcpy(entryScan.chr, entry.chr);
	entryScan.start = entry.start;
	entryScan.end = entry.end;
	//strcpy(entryScan.strand, entry.strand);
	strcpy(entryScan.strand, ExonList[first_index].strand);
	strcpy(entryScan.ESTID, entry.EST_ID);
	entryScan.map_score = entry.map_score;
	entryScan.EST_START = entry.EST_start;
	entryScan.EST_END = entry.EST_end;

	for (i=0; i < last_index-first_index + 1; i++) Flag[i] = 0;

	for (i=first_index; i<=last_index; i++) {
		if (ExonList[i].start <= entry.start && entry.start <= ExonList[i].end && ExonList[i].end <= entry.end) { 
			Flag[i-first_index] = headOverlap;
			mapCount++;
		} else if (ExonList[i].start <= entry.end && entry.end <= ExonList[i].end && entry.start <= ExonList[i].start) {
			Flag[i-first_index] = tailOverlap;
			mapCount++;
		} else if (ExonList[i].start < entry.start && entry.end < ExonList[i].end) { 
			Flag[i-first_index] = fullyContain;
			mapCount++;
		} else if (entry.start < ExonList[i].start && ExonList[i].end < entry.end) {
			Flag[i-first_index] = properSubset;
			mapCount++;
		}
	}
	entryScan.MAP_COUNT = mapCount;
	strcpy(entryScan.ENSTID, ExonList[first_index].ENSTID);

	if (mapCount > 0) { 
		//fprintf(fp, "%s\t%d\t%d\t%s\t%s\t%d\t%d\t%d\t%s", entry.chr, entry.start, entry.end, entry.strand, entry.EST_ID, 
		//entry.EST_start, entry.EST_end, mapCount, ExonList[first_index].ENSTID); 
		tmpMapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT) * mapCount);

		for (i=first_index; i<=last_index; i++) {
			exonLen = ExonList[i].end - ExonList[i].start + 1;
			if (Flag[i-first_index] == headOverlap) { 
				//fprintf(fp, "\tHeadOverlap\t%d\t%1.4f\t", ExonList[i].end-entry.start+1, (float)(ExonList[i].end-entry.start+1)/exonLen);
				strcpy(tmpMapList[k].overlap_type, "HeadOverlap");
				tmpMapList[k].length = ExonList[i].end-entry.start+1;
				tmpMapList[k].percent = (float)(ExonList[i].end-entry.start+1)/exonLen;
			} else if (Flag[i-first_index] == tailOverlap) { 
				//fprintf(fp, "\tTailOverlap\t%d\t%1.4f\t", entry.end-ExonList[i].start+1, (float)(entry.end-ExonList[i].start+1)/exonLen);
				strcpy(tmpMapList[k].overlap_type, "TailOverlap");
				tmpMapList[k].length = entry.end-ExonList[i].start+1;
				tmpMapList[k].percent = (float)(entry.end-ExonList[i].start+1)/exonLen;
			} else if (Flag[i-first_index] == fullyContain) { 
				//fprintf(fp, "\tFullyContain\t%d\t%1.4f\t", entry.end-entry.start+1, (float)(entry.end-entry.start+1)/exonLen);
				strcpy(tmpMapList[k].overlap_type, "FullyContain");
				tmpMapList[k].length = entry.end-entry.start+1; 
				tmpMapList[k].percent = (float)(entry.end-entry.start+1)/exonLen;
			} else if (Flag[i-first_index] == properSubset) {
				//fprintf(fp, "\tProperSubset\t%d\t%1.4f\t", ExonList[i].end-ExonList[i].start+1, 1.0000);
				strcpy(tmpMapList[k].overlap_type, "ProperSubset");
				tmpMapList[k].length = ExonList[i].end-ExonList[i].start+1; 
				tmpMapList[k].percent = 1.0000;
			} else { 
				//fprintf(fp, "\there(%s):flag=0\t0\t0.0000\t", ExonList[i].ENSTID);
			}
			if (Flag[i-first_index] > 0) { 
				//fprintf(fp, "%d\t%d", ExonList[i].start - entry.start, ExonList[i].end - entry.end);
				tmpMapList[k].frontExt = ExonList[i].start - entry.start; 
				tmpMapList[k].rearExt = ExonList[i].end - entry.end;
				k++;
			}
			//else fprintf(fp, "-9999\t-9999\n");
			
			//fprintf(fp, "\t%d\t%d\t%d", ExonList[i].end-ExonList[i].start+1, 0, 0);
		}
		k = 0;
		//fprintf(fp, "\n");
	} else { 
		tmpMapList = (MAP_RESULT *)malloc(sizeof(MAP_RESULT));
		strcpy(tmpMapList[0].overlap_type, "----N/A----");
		tmpMapList[0].length = 0;
		tmpMapList[0].percent = 0.0000;
		tmpMapList[0].frontExt = -9999;
		tmpMapList[0].rearExt = -9999; 
	}
	entryScan.mapList = tmpMapList; 
	free(Flag);
	return entryScan;
}

void printBlock(FILE *fp, SCAN_RESULT entry)
{
        int i = 0, count = 0;

        fprintf(fp, "%s\t%d\t%d\t%s\t%s\t%d\t%d\tscore=%d\t%d\t%s", entry.chr, entry.start, entry.end, entry.strand,
        entry.ESTID, entry.EST_START, entry.EST_END, entry.map_score, entry.MAP_COUNT, entry.ENSTID);
        if (entry.MAP_COUNT == 0) count = 1;
        else count = entry.MAP_COUNT;

        for (i=0; i<count; i++) fprintf(fp, "\t%s\t%d\t%1.4f\t%d\t%d", entry.mapList[i].overlap_type,
        entry.mapList[i].length, entry.mapList[i].percent, entry.mapList[i].frontExt, entry.mapList[i].rearExt);
        fprintf(fp, "\n");
}

