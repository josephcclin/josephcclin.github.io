#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Genes { 
	char GeneID[50];
	char TxID[50];
	char chrName[50]; 
	int strand; 
	int ExonStart; 
	int ExonEnd; 
	int rank;
	int phase; 
	int CDS_Start;
	int CDS_End;
} GENES;

typedef struct Biotype { 
	char TranxID[50];
	char GeneBiotype[50];
	char TranxBiotype[50];
	char Status[50];
} BIOTYPE;

typedef struct biotype_node { 
	BIOTYPE entry; 
	struct biotype_node *next;
	struct biotype_node *last;
} BioNode; 

int main(int argc, char **argv)
{
	FILE *fp_biotype; 
	int countTx = 0;
	int countCurrent = 0;
	char GeID[50] = ""; 
	char TxID[50] = "";
	char chrName[50] = "";
	int strand = 0; 
	int ExonStart = 0;
	int ExonEnd = 0;
	int ExonRank; 
	int ExonPhase; 
	int CDS_Start = 0; 
	int CDS_End = 0;
	char TxBio[50] = ""; 
	char Stat[50] = "";
	char targetTxID[50] = ""; 
	char targetTxBiotype[50] = "";
	int flagFound = 0;

	BioNode *head = (BioNode *)malloc(sizeof(BioNode)); 
	BioNode *tail = (BioNode *)malloc(sizeof(BioNode));
	BioNode *prev = (BioNode *)malloc(sizeof(BioNode));
	BioNode *temp, *current;
	head->next = NULL;
	head->last = NULL;
	tail->next = NULL;
	tail->last = NULL;
	prev->next = NULL;
	prev->last = NULL;
	strcpy(head->entry.TranxID, "DUMMY");
	strcpy(head->entry.TranxBiotype, "DUMMY");
	strcpy(head->entry.Status, "DUMMY");
	strcpy(tail->entry.TranxID, "DUMMY");
	strcpy(tail->entry.TranxBiotype, "DUMMY");
	strcpy(tail->entry.Status, "DUMMY");

	/*	if ((fp_genes = fopen(argv[1], "r")) == NULL) { 
		fprintf(stderr, "** Gene annotation file error **\n");
		exit(EXIT_FAILURE);
	}*/
	
	if ((fp_biotype = fopen(argv[1], "r")) == NULL) { 
		fprintf(stderr, "** Gene biotype file error **\n");
		exit(EXIT_FAILURE);
	}
	
	while (fscanf(fp_biotype, "%s %s %s", TxID, TxBio, Stat) != EOF) {
		countTx++;
		temp = (BioNode *)malloc(sizeof(BioNode));
		strcpy(temp->entry.TranxID, TxID);
		strcpy(temp->entry.TranxBiotype, TxBio);
		strcpy(temp->entry.Status, Stat);
		if (!strcmp(head->entry.TranxID, "DUMMY")) { 
			temp->next = NULL;
			temp->last = NULL;
			head = temp;
			tail = temp;
		} else { 
			temp->next = head;
			temp->last = NULL;
			head->last = temp;
			head = temp;
		}
        }
	current = tail;
	fclose(fp_biotype);

	fprintf(stderr, "Progress:    ");

	while (fscanf(stdin, "%s %s %s %d %d %d %d %d %d %d", GeID, TxID, chrName, &strand, &ExonStart, &ExonEnd, &ExonRank, &ExonPhase, &CDS_Start, &CDS_End) != EOF) {
		fprintf(stdout, "%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t", GeID, TxID, chrName, strand, ExonStart, ExonEnd, ExonRank, ExonPhase, CDS_Start, CDS_End);
		
		if (!strcmp(TxID, targetTxID)) { 
			fprintf(stdout, "%s\n", targetTxBiotype);
			flagFound = 2;
		} else { 
			current = tail;
			while (current != NULL) { 
				if (!strcmp(TxID, current->entry.TranxID)) { 
					flagFound = 1;
					countCurrent++;
					fprintf(stdout, "%s\n", current->entry.TranxBiotype);
					if (countCurrent == 5*countTx/100) fprintf(stderr, "\b\b\b 5%%");
					else if (countCurrent == countTx/10) fprintf(stderr, "\b\b\b10%%");
					else if (countCurrent == countTx/4) fprintf(stderr, "\b\b\b25%%");
					else if (countCurrent == countTx/2) fprintf(stderr, "\b\b\b50%%");
					else if (countCurrent == 3*countTx/4) fprintf(stderr, "\b\b\b75%%");
					else if (countCurrent == 9*countTx/10) fprintf(stderr, "\b\b\b90%%");

					strcpy(targetTxID, current->entry.TranxID);
					strcpy(targetTxBiotype, current->entry.TranxBiotype);

					if (current->last != NULL) { 
						current->last->next = prev;
					}
					prev->last = current->last;
					free(current);
					break;
				} else { 
					prev = current; 
					current = current->last; 
				}
			} 
			if (flagFound != 1) { 
				flagFound = 0;
				fprintf(stdout, "NOT_FOUND\tNOT_FOUND\n");
				fprintf(stderr, "** Some item is missing in the annotation files **\n");
			}
		}
	} 
	fprintf(stderr, "\b\b\b100%%\n\n");
	//fclose(fp_genes);
	return 0;
}
