#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char **argv)
{
	FILE *chrFile; 
	char chrName[200] = "";
	char chrFolder[100] = "chrs/";
	char chrFolder_Bak[100];
	char MakeDir[200] = "mkdir ";
	char Nuc = 'n';
	struct stat folderState;
	int i = 0;
	int current = 0;
	int chrLen = 0;
	int scanVal = 0;

	// mkdir chromosomes/
	strcpy(chrFolder, argv[1]);

	stat(chrFolder, &folderState);
	if (!S_ISDIR(folderState.st_mode)) {
		strcat(MakeDir, chrFolder);
		//system(MakeDir);
		if (system(MakeDir) == -1) fprintf(stderr, "** system call error **\n");
	}

	if (chrFolder[strlen(chrFolder)-1] != '/') strcat(chrFolder, "/");
	strcpy(chrFolder_Bak, chrFolder); 
	fprintf(stderr, "## Starting transforming the genome...\nProgress:    ");

	while (fscanf(stdin, "%s %d", chrName, &chrLen) != EOF) { // read input genome from stdin
		current++;
		strcpy(chrFolder, chrFolder_Bak);
		if (!strcmp(chrName, "chrM")) strcpy(chrName, "chrMT");
		strcat(chrFolder, chrName);
		strcat(chrFolder, ".fa");
		chrFile = fopen(chrFolder, "w"); // Create a file to write down dna of the chromosome 
		fprintf(chrFile, "%s\t%d", chrName, chrLen);
		for (i=0; i<=chrLen; i++) { 
			scanVal = fscanf(stdin, "%c", &Nuc);
			fprintf(chrFile, "%c", Nuc);
		}
		if (scanVal == 0) fprintf(stderr, "** File reading error in GenomeTransform **\n");
		//fscanf(stdin, "%c", &delim);
		fprintf(chrFile, "\n");
		if (current == 10) { 
			fprintf(stderr, "\b\b\b 5%%");
		} else if (current == 10) { 
			fprintf(stderr, "\b\b\b20%%");
		} else if (current == 20) { 
			fprintf(stderr, "\b\b\b25%%");
		} else if (current == 50) { 
			fprintf(stderr, "\b\b\b50%%");
		} else if (current == 5000) { 
			fprintf(stderr, "\b\b\b75%%");
		} else if (current == 10000) { 
			fprintf(stderr, "\b\b\b80%%");
		} else if (current == 20000) { 
			fprintf(stderr, "\b\b\b85%%");
		} else if (current == 50000) { 
			fprintf(stderr, "\b\b\b90%%");
		}
		fclose(chrFile);
	}
	fprintf(stderr, "\b\b\b100%%\n\n");
	return 0;
}

