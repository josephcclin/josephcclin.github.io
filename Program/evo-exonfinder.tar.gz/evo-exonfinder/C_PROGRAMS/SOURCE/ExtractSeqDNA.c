#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Seq_Read {
	char Tag[50];
	int length; 
	char *DNA;
} Read; 

typedef struct SeqTagNode { 
	char Tag[50];
	struct SeqTagNode *next;
} TagNode;


int main(int argc, char** argv)
{
	FILE *inFile, *tagFile;
	char TAG[50] = "";
	//int i = 0, j = 0, k = 0; 
	int countCurrent = 0, countTag = 0;
	char delim; 
	int scanVal = 0;
	
	Read entry;
	TagNode *head = (TagNode *)malloc(sizeof(TagNode)); 
	TagNode *prev = (TagNode *)malloc(sizeof(TagNode));
	TagNode *temp, *current;
	strcpy(head->Tag, "DUMMY");
	head->next = NULL;
	prev->next = NULL;

	if (argc < 3) { 
		fprintf(stderr, "Usage: \n");
		fprintf(stderr, "\t./ExtractSeqDNA [Sequenced_Reads] [Interested_Read-Tags]\n\n");
		exit(EXIT_FAILURE);
	}

	if ((inFile = fopen(argv[1], "r")) == NULL) {
		fprintf(stderr, "** Error in opening %s. **\n", argv[1]);
		exit(EXIT_FAILURE);
	}

	if ((tagFile = fopen(argv[2], "r")) == NULL) {
		fprintf(stderr, "** Error in opening %s. **\n", argv[2]);
		exit(EXIT_FAILURE);
	}

	while (fscanf(tagFile, "%s", TAG) != EOF) { 
		countTag++;
		temp = (TagNode *)malloc(sizeof(TagNode));
		strcpy(temp->Tag, TAG);
		if (head->next == NULL) { 
			head->next = temp;
			head->next->next = NULL;
		} else { 
			current = head;
			while (current->next != NULL) 
				current = current->next;
			current->next = temp;
			current = temp;
			current->next = NULL;
		}
	}
	current = head;
	fclose(tagFile);
	fprintf(stderr, "Progress:  0%%");

	while (fscanf(inFile, "%s %d", entry.Tag, &entry.length) != EOF) {
		entry.DNA = (char *)malloc(sizeof(char) * (entry.length + 1));
		if (entry.DNA == NULL) { 
			fprintf(stderr, "** Memory allocation error for a DNA sequence! **\n");
			exit(EXIT_FAILURE);
		}
		
		scanVal = fscanf(inFile, "%c", &delim);
		if (scanVal == 0) fprintf(stderr, "** File reading error in ExtractSeqDNA **\n");
		/*while (k < entry.length) { 
			fscanf(inFile, "%c", &((entry.DNA)[k]));
			k++;
		}*/
		if (fgets(entry.DNA, entry.length+1, inFile) == NULL) fprintf(stderr, "** File reading error in ExtractSeqDNA **\n");
		entry.DNA[entry.length] = '\0';
		//k = 0;
                
		while (current != NULL) {
			if (!strcmp(entry.Tag, current->Tag)) { 
				countCurrent++;
				if (countCurrent == countTag/10) fprintf(stderr, "\b\b\b10%%");
				else if (countCurrent == countTag/4) fprintf(stderr, "\b\b\b25%%");
				else if (countCurrent == countTag/2) fprintf(stderr, "\b\b\b50%%");
				else if (countCurrent == 3*countTag/4) fprintf(stderr, "\b\b\b75%%");
				else if (countCurrent == 9*countTag/10) fprintf(stderr, "\b\b\b90%%");
				
				//fprintf(stderr, "\b\b\b%2.0f%%", 100*(float)countCurrent/(float)countTag);
				if (countCurrent == countTag) fprintf(stderr, "\b\b\b100%%\n\n");
				printf(">%s\n%s\n", entry.Tag, entry.DNA);
				
				prev->next = current->next;
				free(current);
				current = NULL;
			} else { 
				prev = current;
				current = current->next;
			}
		}
		free(entry.DNA); 
		if (head->next == NULL) break; 
		else current = head;
	}
	free(head);
	fclose(inFile);
	return 0;
}
