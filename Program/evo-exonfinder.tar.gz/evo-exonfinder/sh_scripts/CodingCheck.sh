#!/bin/bash
# 1. Transform the mappable blocks of novel internal exons, novel extended exons, and novel retained-introns and checking their reading frames
# 2. Checking coding potential of the sets of blocks containing candidates

test -z $1 && echo -e "Usage: \n\tCodingCheck.sh [TASK_NAME] [ENST_CODING_PROCESSED] [IS_INTER_SPECIES]\n" && exit 0
test -z $2 && echo -e "Usage: \n\tCodingCheck.sh [TASK_NAME] [ENST_CODING_PROCESSED] [IS_INTER_SPECIES]\n" && exit 0
test ! -f $2 && echo -e "** [PROTEIN_CODING_ENST_BLOCKS] error **\n" && exit 0
test -z $3 && echo -e "Usage: \n\tCodingCheck.sh [TASK_NAME] [ENST_CODING_PROCESSED] [IS_INTER_SPECIES]\n" && exit 0

TASK_NAME=$1
ENST_CODING_PROCESSED=$2
IS_INTER_SPECIES=$3
DIR_CHROMOSOMES="DIR_CHRS"

RAW_MAPPABLE_BLOCKS="$TASK_NAME""_raw_mappable.blocks"
CORRECTED_MAP_BLOCKS="$TASK_NAME""_corrected_mappable.blocks"
CORRECTED_MAP_BLOCKS_SCORE="$TASK_NAME""_corrected_mappable_score.blocks"
#CORRECTED_MAP_BLOCKS_DEBUG="$TASK_NAME""_corrected_mappable.log"

CDNA_CHECKED_CANDIDATES="$TASK_NAME""_cdnaChecked"
CDNA_FILTERED_CANDIDATES="$TASK_NAME""_cdnaFiltered"
SPLICING_CHECKED_CANDIDATES="$CDNA_CHECKED_CANDIDATES""_splicingChecked"
SPLICING_CHECKED_CDNA_FILTERED="$CDNA_FILTERED_CANDIDATES""_splicingChecked"

PROTEIN_CODING_MAP_BLOCKS="$TASK_NAME""_corrected_mappable_coding.blocks"
PROTEIN_CODING_MAP_BLOCKS_TMP="$TASK_NAME""_corrected_mappable_coding.blocks.tmp"
PROTEIN_CODING_MAP_BLOCKS_FILTERED="$TASK_NAME""_corrected_mappable_coding.log"
PROTEIN_CODING_MAP_BLOCKS_AA_CHECKED="$TASK_NAME""_corrected_mappable_AA-checked"

FINAL_CANDIDATES_NONCODING="$TASK_NAME""_final_noncoding"
FINAL_CANDIDATES_CODING="$TASK_NAME""_final_coding"
FINAL_CANDIDATES_ALL="$TASK_NAME""_final_all"
FINAL_CANDIDATES_ALL_TSV="$TASK_NAME""_identified_candidates.tsv"
FINAL_CANDIDATES_CODING_TSV="$TASK_NAME""_identified_CDS_candidates.tsv"
FINAL_CANDIDATES_NONCODING_TSV="$TASK_NAME""_identified_UTR_candidates.tsv"

test ! -f $RAW_MAPPABLE_BLOCKS && echo -e "** File ($RAW_MAPPABLE_BLOCKS) error **\n" && exit 0

# Correct mapping blocks by the splicing signals

echo -e "## Correcting mapping blocks by splicing signals...\nProgress:  0%\c"
BlockCorrect $RAW_MAPPABLE_BLOCKS $SPLICING_CHECKED_CANDIDATES $SPLICING_CHECKED_CDNA_FILTERED $IS_INTER_SPECIES | sed 's/,;/\t/g' | sed 's/,$//g' | sed 's/,\t/\t/g' | sed 's/,/\t/g' | sed 's/score=//g' > $CORRECTED_MAP_BLOCKS
echo -e "\b\b\b50%\c"
CatMapBlock $CORRECTED_MAP_BLOCKS $ENST_CODING_PROCESSED > tmp_mappable_coding.blocks 2> $PROTEIN_CODING_MAP_BLOCKS_FILTERED
cat tmp_mappable_coding.blocks | awk 'BEGIN { RS = ""; FS = "\t"; } { for (i=1; i<=NF; i+=15) { if ($i == "NOVEL" || $i == "RETAIN") flagPrint = 1; } if (flagPrint == 1) printf("%s\n\n", $0); flagPrint = 0; }' > tmp_mappable_coding_refined.blocks
cat tmp_mappable_coding_refined.blocks | grep chr | awk '{ print $3 }' | sort -V -u > chr_catmap_list
echo -e "\b\b\b75%\c"
RecordDivide tmp_mappable_coding_refined.blocks 3 chr_catmap_list
cat _tmp_ALL_ | awk 'BEGIN { RS = ""; flag = 0; } { for (i=1; i<NF; i+=15) { if ($i == "RETAIN" || $i == "NOVEL") flag = 1; } if (flag == 1) printf("%s\n\n", $0); flag = 0; }' | awk 'BEGIN { RS = ""; FS = "\n"; } { printf("%d\n%s\n", NF, $0); }' > $PROTEIN_CODING_MAP_BLOCKS

if test -f $PROTEIN_CODING_MAP_BLOCKS; 
then 
	echo -e "\b\b\b100%\n"
	#echo -e "$PROTEIN_CODING_MAP_BLOCKS is done."
	#echo -e "$PROTEIN_CODING_MAP_BLOCKS_FILTERED is done.\n"
else 
	echo -e "\n** Error in producing $PROTEIN_CODING_MAP_BLOCKS. **\n"
	exit
fi


# -- peptide-sequence and stop-codon checking --

echo -e "## Starting stop-codon checking...\nProgress:  0%\c"
extractCandidateDNA $PROTEIN_CODING_MAP_BLOCKS $DIR_CHROMOSOMES > $PROTEIN_CODING_MAP_BLOCKS_AA_CHECKED 
if test ! -f $PROTEIN_CODING_MAP_BLOCKS_AA_CHECKED; 
then
	echo -e "\n** Error in producing $PROTEIN_CODING_MAP_BLOCKS_AA_CHECKED. **"
	exit
else
	echo -e "\b\b\b100%\n"
	#echo -e "$PROTEIN_CODING_MAP_BLOCKS_AA_CHECKED is done."
	cat $PROTEIN_CODING_MAP_BLOCKS_FILTERED | sed 's/# //g' | grep UTR | final_catlog_noncds.awk | final_layout.awk | UTR_overlap_check_1.awk | UTR_overlap_check_2.awk | sort -V -u | support_count.awk > $FINAL_CANDIDATES_NONCODING
	cat $PROTEIN_CODING_MAP_BLOCKS_AA_CHECKED | sed 's/## //g' | final_catlog_cds.awk | separateFlank.awk | final_layout.awk CDS | sort -V -u | sed 's/phase=//g' | sed 's/;CDSstart=/\t/g' | sed 's/,CDSend=/\t/g' | sed 's/pass/-/g' | support_count_coding.awk > $FINAL_CANDIDATES_CODING
	cat $FINAL_CANDIDATES_CODING $FINAL_CANDIDATES_NONCODING | sort -V -u > $FINAL_CANDIDATES_ALL
	cat $FINAL_CANDIDATES_ALL | sed 's/NOVEL/CASSETTE/g' | sed 's/AGGT/GT-AG/g' | sed 's/AGGC/GC-AG/g' | sed 's/ACAT/AT-AC/g' | sed 's/CODING-SUSTAINED/CDS/g' | \
	sed 's/CODING-STOP/CDS (STOP)/g' | ObtainIntronInRetain.awk | awk '
        BEGIN { 
                RS = "\n"; 
		FS = "\t"; 
                printf("chr\tstart\tend\tstrand\ttranscript ID\tnovel exonic length\tAS type\tsplicing sites motif\t");
                printf("genomic type\tflanking exons (+: upstream;downstream -: downstream;upstream)\t# supporting ESTs\tsupporting ESTs\n"); 
        } 
	{ 
		if (substr($9, 3, 3) == "UTR") { 
			for (i=1; i<=11; i++) printf("%s\t", $i); 
			printf("%s\n", $12); 
		} else { 
			for (i=1; i<=12; i++) { 
				if (i != 11) printf("%s\t", $i); 
			} 
			printf("%s\n", $13); 
		} 
	}' > $FINAL_CANDIDATES_ALL_TSV

cat $FINAL_CANDIDATES_ALL_TSV | grep -v 'UTR' > $FINAL_CANDIDATES_CODING_TSV
cat $FINAL_CANDIDATES_ALL_TSV | egrep 'UTR|genomic type' > $FINAL_CANDIDATES_NONCODING_TSV

	echo -e "$FINAL_CANDIDATES_CODING_TSV is done."
	echo -e "$FINAL_CANDIDATES_NONCODING_TSV is done.\n"
	rm -f _tmp_chr* tmp_mappable_coding.blocks tmp_mappable_coding_refined.blocks chr_catmap_list _tmp_ALL_
fi


