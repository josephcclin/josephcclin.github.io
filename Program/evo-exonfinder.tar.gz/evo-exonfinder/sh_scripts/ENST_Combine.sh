#!/bin/bash
# Add "Transcript biotype" to the two Ensembl gene annotation files. 
#
# Author: Dr. Joseph Chuang-Chieh Lin (josephcclin AT gmail dot com)
# Copyright (c) 2014 Trees-Juen Chuang's Lab

if [ "$#" -eq 2 ];
then
	GENES=$1
	TX_TYPE=$2
	GENES_JOINED="$GENES"".genes"
	test ! -f $GENES && echo -e "** The gene annotation file is missing. **\n" && exit 0
	test ! -f $TX_TYPE && echo -e "** The transcript biotype file is missing. **\n" && exit 0
elif [ "$#" -eq 3 ];
then
	GENES=$1
	GENES_CDS_PHASE=$2
	TX_TYPE=$3
	GENES_JOINED="$GENES"".genes"
	GENES_CDS_PHASE_JOINED="$GENES_CDS_PHASE"".CDS.tx"
	test ! -f $GENES && echo -e "** The first gene annotation file is missing. **\n" && exit 0
	test ! -f $GENES_CDS_PHASE && echo -e "** The second gene annotation file (with CDS information) is missing. **\n" && exit 0
	test ! -f $TX_TYPE && echo -e "** The transcript biotype file is missing. **\n" && exit 0
else
	echo -e "** Argument error. **"
	echo -e "Usage:\n\tENST_Combine.sh [FIRST_GENE_ANNOTATION_FILE] [SECOND_GENE_CDS_ANNOTATION_FILE] [TRANSCRIPT_BIOTYPE_FILE]\n" 
	exit 0
fi

#GENES=$1
#GENES_CDS_PHASE=$2
#TX_TYPE=$3
#GENES_JOINED="$GENES"".genes"
#GENES_CDS_PHASE_JOINED="$GENES_CDS_PHASE"".CDS.tx"

#test -z $GENES && echo -e "** Argument error. **\nUsage:\n\tENST_Combine.sh [FIRST_GENE_ANNOTATION_FILE] [SECOND_GENE_CDS_ANNOTATION_FILE] [TRANSCRIPT_BIOTYPE_FILE]\n" && exit 0
#test ! -f $GENES && echo -e "** The first gene annotation file is missing. **\n" && exit 0
#test -z $TX_TYPE && echo -e "** Argument error. **\nUsage:\n\tENST_Combine.sh [FIRST_GENE_ANNOTATION_FILE] [SECOND_GENE_CDS_ANNOTATION_FILE] [TRANSCRIPT_BIOTYPE_FILE]\n" && exit 0
#test ! -f $TX_TYPE && echo -e "** The transcript biotype file is missing. **\n" && exit 0
#test -z $GENES_CDS_PHASE && echo -e "Argument error. **\nUsage:\n\tENST_Combine.sh [FIRST_GENE_ANNOTATION_FILE] [SECOND_GENE_CDS_ANNOTATION_FILE] [TRANSCRIPT_BIOTYPE_FILE]\n" && exit 0
#test ! -f $GENES_CDS_PHASE && echo -e "** The second gene annotation file (with CDS information) is missing. **\n" && exit 0

if [ "$#" -eq 2 ]; 
then 
	echo "## Transformation..."
else
	echo "## Transformation (the first part)..."
fi

cat $TX_TYPE | sed 's/,/\t/g' | sed 's/ /_/g' | egrep -v '[Tt]ranscript.*.ID|[Bb]iotype' | awk ' 
BEGIN { FS = "\t"; RS = "\n"; } 
{ 
	printf("%s\t%s\t", $1, $2); 
	if ($3 == "") 
		printf("TBD\n"); 
	else 
		printf("%s\n", $3); 
}' > tx_types.tmp

cat $GENES | sed 's/,/\t/g' | egrep -v '[Tt]ranscript.*.ID|[Bb]iotype' | awk '
BEGIN { FS = "\t"; RS = "\n"; }
{
	for (i=1; i<=8; i++) printf("%s\t", $i); 
	for (i=9; i<=14; i++) { 
		if ($i == "") printf("-99\t");
		else printf("%d\t", $i);
	} 
	printf("%d\t%d\t%s\n", $15, $16, $17);
}' | annotation_join tx_types.tmp | sed 's/-99//g' > $GENES_JOINED

#annotation_join genes.tmp tx_types.tmp | sed 's/-99//g' > $GENES_JOINED

if [ "$#" -eq 3 ]; 
then
	echo -e "## Transformation (the second part)..."
	cat $GENES_CDS_PHASE  | sed 's/,/\t/g' | egrep -v '[Tt]ranscript.*.ID|[Rr]ank' | awk ' 
	BEGIN { FS = "\t"; RS = "\n"; } 
	{ 
		for (i=1; i<7; i++) 
			printf("%s\t", $i); 
		printf("%s", $7); 
		for (i=8; i<=10; i++) { 
			if ($i == "") 
				printf("\t-99"); 
			else 
				printf("\t%d", $i);
		} 
		printf("\n"); 
	}' | cds_annotation_join tx_types.tmp | sed 's/-99//g' > $GENES_CDS_PHASE_JOINED

	echo -e "$GENES_JOINED is done."
	echo -e "$GENES_CDS_PHASE_JOINED is done.\n"
else 
	echo -e "$GENES_JOINED is done."
fi

rm -f tx_types.tmp 
