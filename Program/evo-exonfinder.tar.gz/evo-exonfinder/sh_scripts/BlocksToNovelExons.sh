#!/bin/bash
# Extract novel internal (cassette-on), (5'- or 3'-)extended exons and novel retained-introns

test -z $1 && echo -e "Usage: \n\tBlocksToNovelExons.sh [BLAT_BLOCKS] [EXONS_PROCESSED] [TASK_NAME]\n" && exit 0
test -z $2 && echo -e "Usage: \n\tBlocksToNovelExons.sh [BLAT_BLOCKS] [EXONS_PROCESSED] [TASK_NAME]\n" && exit 0
test -z $3 && echo -e "Usage: \n\tBlocksToNovelExons.sh [BLAT_BLOCKS] [EXONS_PROCESSED] [TASK_NAME]\n" && exit 0
test ! -f $1 && echo -e "Usage: \n\tBlocksToNovelExons.sh [BLAT_BLOCKS] [EXONS_PROCESSED] [TASK_NAME]\n" && exit 0
test ! -f $2 && echo -e "Usage: \n\tBlocksToNovelExons.sh [BLAT_BLOCKS] [EXONS_PROCESSED] [TASK_NAME]\n" && exit 0
test -z $3 && echo -e "Usage: \n\tBlocksToNovelExons.sh [BLAT_BLOCKS] [EXONS_PROCESSED] [TASK_NAME]\n" && exit 0

BLAT_BLOCKS=$1
EXONS_PROCESSED=$2
TASK_NAME=$3
RAW_CANDIDATES="$TASK_NAME""_basic"
FIRST_FILTER_RESULT="$TASK_NAME""_result_after_filtering_internal_retained"
AS_REMOVED_CANDIDATES="$TASK_NAME""_AS-REMOVED"
RAW_MAPPABLE_BLOCKS="$TASK_NAME""_raw_mappable.blocks"
RAW_MAPPABLE_BLOCKS_SCORE="$TASK_NAME""_raw_mappable_score.blocks"

#Extract novel internal and retained-introns:
echo -e "## Extracting raw candidates of novel cassette exons and novel retained introns..."
echo -e "Progress:  0%\c"
cat $BLAT_BLOCKS | grep -v '#Chr' | sed 's/score=//g' | filter_internal_retained.awk > $FIRST_FILTER_RESULT
echo -e "\b\b\b25%\c"
cat $FIRST_FILTER_RESULT | egrep '## NOVEL|## RETAIN' | sed 's/## //g' | awk 'BEGIN { FS = "\t"; } { if ($1 == "RETAIN") { for (j=0; j<$11-1; j++) { printf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t2", $1, $2, $3, $4, $5, $6, $7, $8, $9, $10);  printf("\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", $(12+j*5), $(13+j*5), $(14+j*5), $(15+j*5), $(16+j*5), $(17+j*5), $(18+j*5), $(19+j*5), $(20+j*5), $(21+j*5) ); } } else printf("%s\n", $0); }' | sort -V | sed 's/score=//g' > $RAW_CANDIDATES 
cat $FIRST_FILTER_RESULT | grep -v '## ' | awk 'BEGIN { FS = "\n"; RS = ""; } { printf("%s\n\n", $0); }' | DividingBlocks.awk | RetainCut.awk | awk 'BEGIN { FS = "\n"; RS = ""; } { printf("%d\n%s\n", NF, $0); }' | sed 's/score=//g' > $RAW_MAPPABLE_BLOCKS
echo -e "\b\b\b50%\c"
AS_Exon_Removal $RAW_CANDIDATES $EXONS_PROCESSED $AS_REMOVED_CANDIDATES
echo -e "\b\b\b100%\n"
#echo -e "$AS_REMOVED_CANDIDATES is done.\n"

