#!/bin/bash
# This script combines BlatToAnnotatedBlocks.sh and BlocksToNovelExons.sh
#
# BlatToAnnotatedBlocks.sh: 
#	Transforming blat result to annotated exons
#
# BlocksToNovelExons.sh: 
#	Extract novel internal (cassette-on), (5'- or 3'-)extended exons and novel retained-introns from transformed blocks
#
# Input: 
#	[BLAT_OUTPUT], [INPUT_ENSTS], [TASK_NAME], [IS_INTER_SPECIES]
#

BLAT_OUTPUT=$1
BLAT_BLOCKS_TMP="$1"".tmpblocks"
BLAT_UNAMBIGUOUS_BLOCKS="$1"".unambiguous.tmpblocks"
BLAT_BLOCKS="$1"".blocks"
INPUT_ENSTS=$2
EXONS_PROCESSED="$2""_EXONS_PROCESSED"
ENST_PROCESSED="$2""_ENST_PROCESSED"
MAX_GAP_LEN=$3
TASK_NAME=$4
IS_INTER_SPECIES=$5
MIN_SCORE_DIFF=$6

if [ "$#" -ne 6 ];
then
	echo -e "** Number of parameters is not correct. **"
	echo -e "Usage: \n\tBasic_Analysis.sh [BLAT_OUTPUT] [INPUT_ENSTS] [MAX_GAP_LEN] [TASK_NAME] [IS_INTER_SPECIES] [MIN_SCORE_DIFF]\n"
	exit 0
fi

test ! -f $BLAT_OUTPUT && echo -e "** File ($BLAT_OUTPUT) does not exist. **\n\n" && exit 0
test ! -f $INPUT_ENSTS && echo -e "** File ($INPUT_ENSTS) does not exist. **\n" && exit 0
test ! -f $EXONS_PROCESSED && echo -e "** File ($EXONS_PROCESSED) does not exist. **\n" && exit 0
test ! -f $ENST_PROCESSED && echo -e "** File ($ENST_PROCESSED) does not exist. **\n" && exit 0

#echo -e "\n## Transforming $BLAT_OUTPUT to annotated blocks ##"
BlatToAnnotatedBlocks.sh $BLAT_OUTPUT $ENST_PROCESSED $MAX_GAP_LEN $MIN_SCORE_DIFF
#echo -e "\n## Transforming annotated blocks to preliminary candidates ##\n"
BlocksToNovelExons.sh $BLAT_BLOCKS $EXONS_PROCESSED $TASK_NAME

