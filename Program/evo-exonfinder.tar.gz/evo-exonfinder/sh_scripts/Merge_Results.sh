#!/bin/bash
# Merge candidates with cross-species support with those with the-same-species support

TASK_1=$1
TASK_2=$2
MERGED_TASK=$3

CANDIDATES_1="$TASK_1""_final_all"
CANDIDATES_2="$TASK_2""_final_all"
CANDIDATES_MERGED="$MERGED_TASK""_merged_final_all"
CANDIDATES_FILTERED="$MERGED_TASK""_filtered_final_all"
CANDIDATES_MERGED_CODING="$MERGED_TASK""_merged_final_coding"
CANDIDATES_FILTERED_CODING="$MERGED_TASK""_filtered_final_coding"
CANDIDATES_MERGED_NONCODING="$MERGED_TASK""_merged_final_noncoding"
CANDIDATES_FILTERED_NONCODING="$MERGED_TASK""_filtered_final_noncoding"
CANDIDATES_MERGED_TSV="$MERGED_TASK""_merged_identified_candidates.tsv"
CANDIDATES_FILTERED_TSV="$MERGED_TASK""_filtered_identified_candidates.tsv"
CANDIDATES_MERGED_CODING_TSV="$MERGED_TASK""_merged_identified_CDS_candidates.tsv"
CANDIDATES_MERGED_CODING_TSV="$MERGED_TASK""_merged_identified_CDS_candidates.tsv"
CANDIDATES_FILTERED_CODING_TSV="$MERGED_TASK""_filtered_identified_CDS_candidates.tsv"
CANDIDATES_MERGED_NONCODING_TSV="$MERGED_TASK""_merged_identified_UTR_candidates.tsv"
CANDIDATES_FILTERED_NONCODING_TSV="$MERGED_TASK""_filtered_identified_UTR_candidates.tsv"

test -z $TASK_1 && echo -e "Usage: \n\tMerge_Results.sh [CROSS_SPECIES_TASK_NAME] [THE_SAME_SPECIES_TASK_NAME] [MERGED_TASK_NAME]\n" && exit 0
test -z $TASK_2 && echo -e "Usage: \n\tMerge_Results.sh [CROSS_SPECIES_TASK_NAME] [THE_SAME_SPECIES_TASK_NAME] [MERGED_TASK_NAME]\n" && exit 0
test -z $MERGED_TASK && echo -e "Usage: \n\tMerge_Results.sh [CROSS_SPECIES_TASK_NAME] [THE_SAME_SPECIES_TASK_NAME] [MERGED_TASK_NAME]\n" && exit 0

if [ ! -f $CANDIDATES_1 ] || [ ! -f $CANDIDATES_2 ]; 
then
	exit 0;
fi

cat $CANDIDATES_1 $CANDIDATES_2 | grep -v 'UTR' | sort -V | merge_AllSpecies.awk > $CANDIDATES_MERGED_CODING
cat $CANDIDATES_1 $CANDIDATES_2 | grep 'UTR' | sort -V | merge_AllSpecies_UTR.awk > $CANDIDATES_MERGED_NONCODING
cat $CANDIDATES_MERGED_CODING $CANDIDATES_MERGED_NONCODING | sort -V > $CANDIDATES_MERGED

cat $CANDIDATES_2 | awk 'BEGIN { FS = "\t"; RS = "\n"; } 
{ 
	if (substr($9, 3, 3) == "UTR") { 
		for (i=1; i<12; i++) printf("%s\t", $i); 
		printf("%s#TARGET_SPECIES#\n", $12);
	} else { 
		for (i=1; i<13; i++) printf("%s\t", $i);
		printf("%s#TARGET_SPECIES#\t%s\t%s\t%s\t%s\t%s\t%s\n", $13, $14, $15, $16, $17, $18, $19); 
	}
}' > _tmp_candidates_ 

cat $CANDIDATES_1 _tmp_candidates_ | grep -v 'UTR' | sort -V | merge_AllSpecies.awk | grep -v '#TARGET_SPECIES#' > $CANDIDATES_FILTERED_CODING
cat $CANDIDATES_1 _tmp_candidates_ | grep 'UTR' | sort -V | merge_AllSpecies_UTR.awk | grep -v '#TARGET_SPECIES#' > $CANDIDATES_FILTERED_NONCODING 
cat $CANDIDATES_FILTERED_CODING $CANDIDATES_FILTERED_NONCODING | sort -V > $CANDIDATES_FILTERED 

cat $CANDIDATES_MERGED | sed 's/NOVEL/CASSETTE/g' | sed 's/AGGT/GT-AG/g' | sed 's/AGGC/GC-AG/g' | sed 's/ACAT/AT-AC/g' | sed 's/CODING-SUSTAINED/CDS/g' | \
sed 's/CODING-STOP/CDS (STOP)/g' | sed 's/#TARGET_SPECIES#//g' | ObtainIntronInRetain.awk | awk '
BEGIN { 
	FS = "\t";
	RS = "\n"; 
	printf("chr\tstart\tend\tstrand\ttranscript ID\tnovel exonic length\tAS type\tsplicing sites motif\t");
	printf("genomic type\tflanking exons (+: upstream;downstream -: downstream;upstream)\t# supporting ESTs\tsupporting ESTs\n"); 
} 
{ 
	if (substr($9, 3, 3) == "UTR") { 
	for (i=1; i<=11; i++) printf("%s\t", $i); 
		printf("%s\n", $12); 
	} else { 
		for (i=1; i<=12; i++) { 
			if (i != 11) printf("%s\t", $i); 
		} 
		printf("%s\n", $13); 
	} 
}' > $CANDIDATES_MERGED_TSV

cat $CANDIDATES_MERGED_TSV | grep -v 'UTR' > $CANDIDATES_MERGED_CODING_TSV
cat $CANDIDATES_MERGED_TSV | egrep 'UTR|genomic type' > $CANDIDATES_MERGED_NONCODING_TSV

echo -e "$CANDIDATES_MERGED_CODING_TSV is done."
echo -e "$CANDIDATES_MERGED_NONCODING_TSV is done.\n"


cat $CANDIDATES_FILTERED | sed 's/NOVEL/CASSETTE/g' | sed 's/AGGT/GT-AG/g' | sed 's/AGGC/GC-AG/g' | sed 's/ACAT/AT-AC/g' | sed 's/CODING-SUSTAINED/CDS/g' | \
sed 's/CODING-STOP/CDS (STOP)/g' | ObtainIntronInRetain.awk | awk '
BEGIN { 
	FS = "\t";
	RS = "\n"; 
	printf("chr\tstart\tend\tstrand\ttranscript ID\tnovel exonic length\tAS type\tsplicing sites motif\t");
	printf("genomic type\tflanking exons (+: upstream;downstream -: downstream;upstream)\t# supporting ESTs\tsupporting ESTs\n"); 
} 
{ 
	if (substr($9, 3, 3) == "UTR") { 
		for (i=1; i<=11; i++) printf("%s\t", $i); printf("%s\n", $12); 
	} else { 
		for (i=1; i<=12; i++) { 
			if (i != 11) printf("%s\t", $i); 
		} 
		printf("%s\n", $13); 
	} 

}' > $CANDIDATES_FILTERED_TSV


cat $CANDIDATES_FILTERED_TSV | grep -v 'UTR' > $CANDIDATES_FILTERED_CODING_TSV
cat $CANDIDATES_FILTERED_TSV | egrep 'UTR|genomic type' > $CANDIDATES_FILTERED_NONCODING_TSV

rm -f _tmp_candidates_ $CANDIDATES_MERGED_TSV

