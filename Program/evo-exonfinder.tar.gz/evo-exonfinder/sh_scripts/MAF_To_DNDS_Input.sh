#!/bin/bash
# Transforming CDS BLAT result of MAF format into pairs of sequences

INPUT_MAF=$1
OUTPUT="$1""Seq"

test -z $INPUT_MAF && echo -e "Usage: \n\tMAF_To_DNDS_Input.sh [INPUT_MAF]\n" && exit 0
test ! -f $INPUT_MAF && echo -e "** File ($INPUT_MAF) error **\n" && exit 0

cat $INPUT_MAF | grep -v '##maf' | awk 'BEGIN { RS = ""; FS = "\n"; } { printf("%s\n%s\n\n", $2, $3); }' | sed 's/s //g' | awk '
BEGIN { RS = ""; } 
{ 
	if ($4 == "+")  
		printf("chr%s\t%d\t%d\t%s\t%d\n%s\n", $1, $2+1, $2+$3, $4, length($6), $6); 
	else 
		printf("chr%s\t%d\t%d\t%s\t%d\n%s\n", $1, ($5-$2+1)-$3, $5-$2, $4, length($6), $6); 
	if ($10 == "+")
		printf("%s\t%d\t%d\t%s\t%d\n%s\n\n", $7, $8+1, $8+$9, $10, length($12), $12); 
	else 
		printf("%s\t%d\t%d\t%s\t%d\n%s\n\n", $7, ($11-$8+1)-$9, $11-$8, $10, length($12), $12); 
} END { printf("%d\n", NR) > "_NUM_MAF_BLOCKS_"; }' | sed 's/chrchr/chr/g' > $OUTPUT 
#echo -e "$OUTPUT is done."
