#!/bin/bash
# Transforming blat result to annotated exons

BLAT_OUTPUT=$1
BLAT_UNAMBIGUOUS_BLOCKS="$BLAT_OUTPUT"".unambiguous.tmpblocks"
ENST_PROCESSED=$2
BLAT_BLOCKS="$BLAT_OUTPUT"".blocks"
MAX_GAP_LEN=$3
MIN_SCORE_DIFF=$4

if [ "$#" -ne 4 ];
then
	echo -e "** Number of parameters is not correct. **"
	echo -e "Usage: \n\tBlatToAnnotatedBlocks.sh [BLAT_OUTPUT] [ENST_PROCESSED] [MAX_GAP_LEN] [MIN_SCORE_DIFF]\nOutput: \n\t[BLAT_BLOCKS]\n"
	exit 0
fi

test ! -f $BLAT_OUTPUT && echo -e "Usage: \n\tBlatToAnnotatedBlocks.sh [BLAT_OUTPUT] [ENST_PROCESSED] [MAX_GAP_LEN] [MIN_SCORE_DIFF]\nOutput: \n\t[BLAT_BLOCKS]\n" && exit 0
test ! -f $ENST_PROCESSED && echo -e "Usage: \n\tBlatToAnnotatedBlocks.sh [BLAT_OUTPUT] [ENST_PROCESSED] [MAX_GAP_LEN] [MIN_SCORE_DIFF]\nOutput: \n\t[BLAT_BLOCKS]\n" && exit 0



if test -f $BLAT_BLOCKS; 
then 
	read -p "## Re-transform the blat result? (y/n) " yn
	case $yn in
		[Yy]* ) decision=1;;
		[Nn]* ) decision=0;;
	esac
else 
	decision=1;
fi

if [ $decision -eq 1 ]; 
then
	echo -e "## Transforming the blat result ($BLAT_OUTPUT) into sets of blocks..."
	echo -e "Progress:  0%\c"

	cat $BLAT_OUTPUT | egrep -v 'psLayout|^$|match|---' | head -n 1 | awk 'BEGIN { FS = "\t"; } { if (length($9) == 2) system("echo 1 > _CROSS_"); }'

	if [ -s _CROSS_ ] || [ -f _CROSS_ ]; 
	then
		cat $BLAT_OUTPUT | egrep -v 'psLayout|^$|match|---' | awk '
		BEGIN { FS = "\t"; } { 
			printf("%d\t", $1-$2-$5-$7); 
			printf("%s\t%s\t%d\t%d\t%d\t%s\t%s\t%s\t%s\n", $10, $14, $18, $11, $15, $21, $19, $9, $20); 
		}' | psl_reduce.awk | awk 'BEGIN { FS = "\t"; } { printf("%s\t%s\n", $2, $0); }' | sort -V | awk '
		BEGIN { FS = "\t"; } { for (i=2; i<NF; i++) printf("%s\t", $i); printf("%s\n", $NF); }' | BlatInitTransform.awk | \
		GapFix.awk $MAX_GAP_LEN | rm_ambiguous_BLAT-blocks.awk $MIN_SCORE_DIFF | awk '
		BEGIN { FS = "[\t\n]"; RS = ""; } 
		{ 
			printf("%s\t%d\t%d\t%s\t%s\t%d\t%d\n", $2, $3, $(NF-4), $5, $6, $1, (NF-1)/7);
			for (i=0; i<(NF-1)/7; i++) { 
				printf("%d\t%d\t%d\t%d\n", $(3+i*7), $(4+i*7), $(7+i*7), $(8+i*7));  
			}

			if (NR == 5000) {
				printf("\b\b\b 1%") > "/dev/stderr"
			} else if (NR == 100000) {
			        printf("\b\b\b10%") > "/dev/stderr"
			} else if (NR == 2000000) {
			        printf("\b\b\b25%") > "/dev/stderr"
			} else if (NR == 4000000) {
			        printf("\b\b\b50%") > "/dev/stderr"
			} else if (NR == 6000000) {
			        printf("\b\b\b75%") > "/dev/stderr"
			}
		}' > $BLAT_UNAMBIGUOUS_BLOCKS
		echo -e "\b\b\b100%\n"
		echo -e "## Adding Ensembl annotations to the blocks..."
		ExonScan $BLAT_UNAMBIGUOUS_BLOCKS $ENST_PROCESSED $BLAT_BLOCKS
		rm -f $BLAT_UNAMBIGUOUS_BLOCKS 
		echo -e ""
		#echo -e "$BLAT_BLOCKS ([BLAT_BLOCKS]) is done.\n"
	else 
		cat $BLAT_OUTPUT | egrep -v 'psLayout|^$|match|---' | awk '
		BEGIN { FS = "\t"; } { 
			printf("%d\t", $1-$2-$5-$7); 
			printf("%s\t%s\t%d\t%d\t%d\t%s\t%s\t%s\t%s\n", $10, $14, $18, $11, $15, $21, $19, $9, $20); 
		}' | psl_reduce.awk | awk 'BEGIN { FS = "\t"; } { printf("%s\t%s\n", $2, $0); }' | \
		awk 'BEGIN { FS = "\t"; } { for (i=2; i<NF; i++) printf("%s\t", $i); printf("%s\n", $NF); }' | BlatInitTransform.awk | \
		GapFix.awk $MAX_GAP_LEN | rm_ambiguous_BLAT-blocks.awk $MIN_SCORE_DIFF | awk '
		BEGIN { FS = "[\t\n]"; RS = ""; } 
		{ 
			printf("%s\t%d\t%d\t%s\t%s\t%d\t%d\n", $2, $3, $(NF-4), $5, $6, $1, (NF-1)/7);
			for (i=0; i<(NF-1)/7; i++) { 
				printf("%d\t%d\t%d\t%d\n", $(3+i*7), $(4+i*7), $(7+i*7), $(8+i*7));  
			}

			if (NR == 50000) {
				printf("\b\b\b 1%") > "/dev/stderr"
			} else if (NR == 1000000) {
			        printf("\b\b\b10%") > "/dev/stderr"
			} else if (NR == 2000000) {
			        printf("\b\b\b25%") > "/dev/stderr"
			} else if (NR == 4000000) {
			        printf("\b\b\b50%") > "/dev/stderr"
			} else if (NR == 6000000) {
			        printf("\b\b\b75%") > "/dev/stderr"
			}
		}' > $BLAT_UNAMBIGUOUS_BLOCKS
		echo -e "\b\b\b100%\n"
		echo -e "## Adding Ensembl annotations to the blocks..."
		ExonScan $BLAT_UNAMBIGUOUS_BLOCKS $ENST_PROCESSED $BLAT_BLOCKS
		rm -f $BLAT_UNAMBIGUOUS_BLOCKS 
		echo -e ""
		#echo -e "$BLAT_BLOCKS ([BLAT_BLOCKS]) is done.\n"
	fi
	rm -f _CROSS_
fi

