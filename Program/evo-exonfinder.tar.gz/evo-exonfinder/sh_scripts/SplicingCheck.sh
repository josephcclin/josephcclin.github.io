#!/bin/bash
# Check splicing sites of the candidates (after executing cDNA_checking.sh) and then modify their boundaries. 
# Output candidates will be categorized into canonical ones and possibly editing mediated ones 

test -z $1 && echo -e "Usage: \n\tSplicingCheck.sh [TASK_NAME] [DIR_CHROMOSOMES] [IS_INTER_SPECIES]\n\t[IS_INTER_SPECIES]: 0 for intra-species, 1 for inter-sepcies\n" && exit 0
test -z $2 && echo -e "Usage: \n\tSplicingCheck.sh [TASK_NAME] [DIR_CHROMOSOMES] [IS_INTER_SPECIES]\n\t[IS_INTER_SPECIES]: 0 for intra-species, 1 for inter-sepcies\n" && exit 0
test -z $3 && echo -e "Usage: \n\tSplicingCheck.sh [TASK_NAME] [DIR_CHROMOSOMES] [IS_INTER_SPECIES]\n\t[IS_INTER_SPECIES]: 0 for intra-species, 1 for inter-sepcies\n" && exit 0

TASK_NAME=$1
DIR_CHR=$2
IS_INTER_SPECIES=$3

CDNA_CHECKED_CANDIDATES="$TASK_NAME""_cdnaChecked"
CDNA_FILTERED_CANDIDATES="$TASK_NAME""_cdnaFiltered"

test ! -f $CDNA_CHECKED_CANDIDATES && echo -e "$CDNA_CHECKED_CANDIDATES is missing.\n" && exit 0
test ! -f $CDNA_FILTERED_CANDIDATES && echo -e "$CDNA_FILTERED_CANDIDATES is missing.\n" && exit 0

CDNA_CHECKED_SIGNAL="$CDNA_CHECKED_CANDIDATES"".sites"
CDNA_FILTERED_SIGNAL="$CDNA_FILTERED_CANDIDATES"".sites"

SPLICING_CHECKED_CANDIDATES="$CDNA_CHECKED_CANDIDATES""_splicingChecked"
SPLICING_CHECKED_CANDIDATES_TMP="$SPLICING_CHECKED_CANDIDATES"".bak"
SPLICING_CHECKED_CDNA_FILTERED="$CDNA_FILTERED_CANDIDATES""_splicingChecked"
SPLICING_CHECKED_CDNA_FILTERED_TMP="$SPLICING_CHECKED_CDNA_FILTERED"".bak"

if test -f $CDNA_CHECKED_SIGNAL;
then
	read -p "Re-extract splicing sites of the candidates? (y/n) " yn
	case $yn in
		[Yy]* ) decision=1;;
		[Nn]* ) decision=0;;
	esac
else
	decision=1;
fi

if [ $decision -eq 1 ];
then
	echo -e "## Examining possible splicing sites of the candidates...\nProgress:  0%\c"
	extractSpliceSites $CDNA_CHECKED_CANDIDATES $DIR_CHR $IS_INTER_SPECIES > $CDNA_CHECKED_SIGNAL 2> progress.log
	echo -e "\b\b\b25%\c"
	extractSpliceSites $CDNA_FILTERED_CANDIDATES $DIR_CHR $IS_INTER_SPECIES > $CDNA_FILTERED_SIGNAL 2>> progress.log
	echo -e "\b\b\b50%\c"
else
	echo -e "Progress:  0%\c"
fi

cat $CDNA_CHECKED_CANDIDATES | grep 'RETAIN' | awk 'BEGIN { FS = "\t"; RS = "\n"; } { printf("%s\tpass\t", $1); for (i=2; i<=7; i++) printf("%s\t", $i); printf("%d\t%d\t", $3, $4); for (i=8; i<=NF-1; i++) printf("%s\t", $i); printf("%s\n", $NF); }' > tmp_retained_cdnaChecked
#cat $CDNA_CHECKED_CANDIDATES | grep 'RETAIN' | awk 'BEGIN { FS = "\t"; RS = "\n"; } { printf("%s\tpass\t", $1); for (i=2; i<=NF-1; i++) printf("%s\t", $i); printf("%s\n", $NF); }' > tmp_retained_cdnaChecked
cat $CDNA_FILTERED_CANDIDATES | grep 'RETAIN' | awk 'BEGIN { FS = "\t"; RS = "\n"; } { printf("%s\tpass\t", $1); for (i=2; i<=7; i++) printf("%s\t", $i); printf("%d\t%d\t", $3, $4); for (i=8; i<=NF-1; i++) printf("%s\t", $i); printf("%s\n", $NF); }' > tmp_retained_cdnaFiltered
#cat $CDNA_FILTERED_CANDIDATES | grep 'RETAIN' | awk 'BEGIN { FS = "\t"; RS = "\n"; } { printf("%s\tpass\t", $1); for (i=2; i<=NF-1; i++) printf("%s\t", $i); printf("%s\n", $NF); }' > tmp_retained_cdnaFiltered
echo -e "\b\b\b50%\c"

# -- Categorize the splicing signals -- 

splicing_checking_canonical_AGGT_3n.awk $CDNA_CHECKED_SIGNAL $IS_INTER_SPECIES > _tmp_AGGT_3n_ 2> AGGT_3n_removed.sites 
splicing_checking_canonical_AGGC_3n.awk AGGT_3n_removed.sites $IS_INTER_SPECIES > _tmp_AGGC_3n_ 2> AGGT_AGGC_3n_removed.sites
splicing_checking_canonical_AGGT.awk AGGT_AGGC_3n_removed.sites $IS_INTER_SPECIES > _tmp_AGGT_ 2> AGGT_removed.sites 
splicing_checking_canonical_AGGC.awk AGGT_removed.sites $IS_INTER_SPECIES > _tmp_AGGC_ 2> AGGT_AGGC_removed.sites
splicing_checking_canonical_ACAT.awk AGGT_AGGC_removed.sites $IS_INTER_SPECIES > _tmp_ACAT_ 2> canonical_removed.sites
cat _tmp_AGGT_3n_ _tmp_AGGC_3n_ _tmp_AGGT_ _tmp_AGGC_ _tmp_ACAT_ | grep chr > $SPLICING_CHECKED_CANDIDATES_TMP
cat $SPLICING_CHECKED_CANDIDATES_TMP tmp_retained_cdnaChecked | awk 'BEGIN { FS = "\t"; RS = "\n"; } { printf("%s\t%s\t%d\t%d\t%s\n", $1, $3, $4, $5, $0); }' | sort -V | awk 'BEGIN { FS = "\t"; RS = "\n"; } { for (i=5; i<=NF-1; i++) printf("%s\t", $i); printf("%s\n", $NF); }' | rm_duplicate.awk > $SPLICING_CHECKED_CANDIDATES
rm -f _tmp_AGGT_ _tmp_AGGC_ _tmp_ACAT_ _tmp_aggt_ _tmp_aggc_ AGGT_removed.sites AGGT_AGGC_removed.sites canonical_removed.sites canonical_and_aggt_removed.sites canonical_and_edited_removed.sites

if test -f $SPLICING_CHECKED_CANDIDATES; then
	echo -e "\b\b\b90%\c"
	rm -f $SPLICING_CHECKED_CANDIDATES_TMP tmp_retained_cdnaChecked
else 
	echo -e "** File ($SPLICING_CHECKED_CANDIDATES) error **\n"
	exit
fi

splicing_checking_canonical_AGGT_3n.awk $CDNA_FILTERED_SIGNAL $IS_INTER_SPECIES > _filtered_tmp_AGGT_3n_ 2> cdnaF_AGGT_3n_removed.sites
splicing_checking_canonical_AGGC_3n.awk cdnaF_AGGT_3n_removed.sites $IS_INTER_SPECIES > _filtered_tmp_AGGC_3n_ 2> cdnaF_AGGT_AGGC_3n_removed.sites
splicing_checking_canonical_AGGT.awk cdnaF_AGGT_AGGC_3n_removed.sites $IS_INTER_SPECIES > _filtered_tmp_AGGT_ 2> cdnaF_AGGT_removed.sites
splicing_checking_canonical_AGGC.awk cdnaF_AGGT_removed.sites $IS_INTER_SPECIES > _filtered_tmp_AGGC_ 2> cdnaF_AGGT_AGGC_removed.sites
splicing_checking_canonical_ACAT.awk cdnaF_AGGT_AGGC_removed.sites $IS_INTER_SPECIES > _filtered_tmp_ACAT_ 2> cdnaF_canonical_removed.sites
cat _filtered_tmp_AGGT_3n_ _filtered_tmp_AGGC_3n_ _filtered_tmp_AGGT_ _filtered_tmp_AGGC_ _filtered_tmp_ACAT_ | grep chr > $SPLICING_CHECKED_CDNA_FILTERED_TMP
cat $SPLICING_CHECKED_CDNA_FILTERED_TMP tmp_retained_cdnaFiltered | awk 'BEGIN { FS = "\t"; RS = "\n"; } { printf("%s\t%s\t%d\t%d\t%s\n", $1, $3, $4, $5, $0); }' | sort -V | awk 'BEGIN { FS = "\t"; RS = "\n"; } { for (i=5; i<=NF-1; i++) printf("%s\t", $i); printf("%s\n", $NF); }' | rm_duplicate.awk > $SPLICING_CHECKED_CDNA_FILTERED
rm -f _tmp_AGGT_3n_ _tmp_AGGC_3n_ _filtered_tmp_AGGT_3n_ _filtered_tmp_AGGC_3n_ 
rm -f _filtered_tmp_AGGT_ _filtered_tmp_AGGC_ _filtered_tmp_ACAT_ _filtered_tmp_aggt_ _filtered_tmp_aggc_ 
rm -f cdnaF_AGGT_removed.sites cdnaF_AGGT_AGGC_removed.sites cdnaF_canonical_removed.sites cdnaF_canonical_and_aggt_removed.sites cdnaF_canonical_and_edited_removed.sites

if test -f $SPLICING_CHECKED_CDNA_FILTERED; then
	echo -e "\b\b\b100%\n"
	#echo -e "$SPLICING_CHECKED_CANDIDATES is done.\n"
	#echo -e "$SPLICING_CHECKED_CDNA_FILTERED is done.\n"
	rm -f $SPLICING_CHECKED_CDNA_FILTERED_TMP tmp_retained_cdnaFiltered *removed.sites
else 
	#echo -e "** File ($SPLICING_CHECKED_CDNA_FILTERED) error **\n"
	exit
fi

