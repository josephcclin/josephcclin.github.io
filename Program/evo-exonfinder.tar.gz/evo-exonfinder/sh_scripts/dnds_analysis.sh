#!/bin/bash
# The pipeline of evolutionary analysis for possibly coding candidates

FINAL_CANDIDATES=$1
FINAL_CANDIDATES_DNDS="$1""_final_coding"
FINAL_CANDIDATES_CODING="$FINAL_CANDIDATES""_identified_CDS_candidates.tsv"
FINAL_CANDIDATES_NONCODING="$FINAL_CANDIDATES""_identified_UTR_candidates.tsv"
FINAL_CANDIDATES_CODING_DNDS="$FINAL_CANDIDATES""_identified_CDS_candidates_dnds.tsv"
TARGET_GENOME=$2
SeqReads=$3
SeqReadsToDo="$SeqReads""_ToDo.fa"
BLAT_PARA="-t=dnax -q=dnax -out=maf"

PPAML="$HOME/EVO_EXON_FINDER/PAML/PPAML"
YN00="$HOME/EVO_EXON_FINDER/PAML/yn00"
YN00_CTL="$HOME/EVO_EXON_FINDER/PAML/yn00.ctl"

BLAT="blat" # default
THREADS="" # default

test -z $FINAL_CANDIDATES && echo -e "Please give [FINAL_CANDIDATES]\n\nUsage: \n\tdnds_analysis.sh [FINAL_CANDIDATES] [TARGET_GENOME] [SEQUENCED_READS]\n" && exit 0
test -z $TARGET_GENOME && echo -e "Please give [TARGET_GENOME]\n\nUsage: \n\tdnds_analysis.sh [FINAL_CANDIDATES] [TARGET_GENOME] [SEQUENCED_READS]\n" && exit 0
test -z $SeqReads && echo -e "Please give [SEQUENCED_READS]\n\nUsage: \n\tdnds_analysis.sh [FINAL_CANDIDATES] [TARGET_GENOME] [SEQUENCED_READS]\n" && exit 0

test ! -f $TARGET_GENOME && echo -e "** File ($TARGET_GENOME) error **\n" && exit 0
test ! -f $SeqReadsToDo && echo -e "** File ($SeqReadsToDo) error **\n" && exit 0
test ! -f $RAW_MAPPABLE_BLOCKS && echo -e "** File ($RAW_MAPPABLE_BLOCKS) error **\n" && exit 0
test ! -f $FINAL_CANDIDATES_DNDS && echo -e "File ($FINAL_CANDIDATES_DNDS) error **\n" && exit 0
test ! -f $FINAL_CANDIDATES_NONCODING && echo -e "File ($FINAL_CANDIDATES_NONCODING) error **\n" && exit 0

if test ! -f PPAML;
then
        cp $PPAML ./
fi

if test ! -d bin;
then 
	mkdir bin
fi

if test ! -f bin/yn00;
then 
	cp $YN00 bin/
fi

if test ! -f yn00.ctl;
then 
	cp $YN00_CTL ./
fi

#if [ ! -f _THREADS_ ] || [ ! -s _THREADS_ ];
#then
#        BLAT="blat"
#        THREADS=""
#else 
#	BLAT=`cat _THREADS_ | grep blat`
#	if [ $BLAT = "blat" ];
#	then
#		THREADS=""
#	else
#		THREADS="-threads=""`cat _THREADS_ | grep -v blat`"
#        fi
#fi

START=$(date +"%s")

echo -e "## Starting the evolutionary-rate analysis for CDS candidates...\n"
echo -e "## Extracting required fastas from $SeqReads..."

cat $FINAL_CANDIDATES_DNDS | awk 'BEGIN { FS = "\t"; RS = "\n"; } { printf("%s\t%s\t%s\t%s\t", $1, $2, $3, $4); for (i=1; i<=length($5); i++) { if (substr($5, i, 1) != ",") printf("%s", substr($5, i, 1)); else printf("_and_"); } printf("\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", $7, $10, $11, $14, $15, $16, $17, $18, $19); }' | awk 'BEGIN { FS = "\t"; RS = "\n"; } { count = 1; for (i=1; i<=length($2); i++) { if (substr($2, i, 1) == ";") count++; } printf("%d\t%s\n", count, $0); }' | sed -r 's/phase=|CDSstart=|CDSend=//g' | sed 's/,;/\t/g' | sed -r 's/,|;/\t/g' | sed 's/_and_/,/g' | candidates_split.awk > tmp_CDS_candidates_dnds.input
cat tmp_CDS_candidates_dnds.input | ExtractTagsForDN-DS_Analysis.awk | sort -V -u > preprocessing_DN_DS_Tags
ExtractSeqDNA $SeqReadsToDo preprocessing_DN_DS_Tags > preprocessing_DN_DS.fasta

if [[ ! -s preprocessing_DN_DS.fasta ]];
then
	echo -e "\n"
fi
echo -e "## Generating required alignments (maf) using blat...\n"

$BLAT $TARGET_GENOME preprocessing_DN_DS.fasta $BLAT_PARA $THREADS tmp_CDS_candidates.maf
MAF_To_DNDS_Input.sh tmp_CDS_candidates.maf 
DN_DS_Novel_Cut tmp_CDS_candidates_dnds.input tmp_CDS_candidates.mafSeq > tmp_CDS_candidates_dnds_novel_paml.input 2> _paml_log_
DN_DS_Flank_Cut tmp_CDS_candidates_dnds.input tmp_CDS_candidates.mafSeq > tmp_CDS_candidates_dnds_flank_paml.input 2>> _paml_log_

if [[ -s _paml_log_ ]]; 
then 
	echo -e "** Error either in blatx or DN_DS_Novel/Flank_Cut **\n"
	exit 0
fi

echo -e "\n## Running PAML yn00 method (novel exonic regions)..."
if [[ -s tmp_CDS_candidates_dnds_novel_paml.input ]]; 
then
	./PPAML yn00 -i tmp_CDS_candidates_dnds_novel_paml.input tmp_CDS_candidates_dnds_novel_paml.out
else 
	echo -e "" > tmp_CDS_candidates_dnds_novel_paml.out
fi
echo -e ""
echo -e "## Running PAML yn00 method (flanking exonic regions)..."
if [[ -s tmp_CDS_candidates_dnds_flank_paml.input ]]; 
then 
	./PPAML yn00 -i tmp_CDS_candidates_dnds_flank_paml.input tmp_CDS_candidates_dnds_flank_paml.out
else 
	echo -e "" > tmp_CDS_candidates_dnds_flank_paml.out
fi
echo -e ""

cat $FINAL_CANDIDATES_CODING | grep -v 'genomic' | sed 's/CDS (STOP)/CDS_STOP/g' | awk 'BEGIN { FS = "\t"; } { printf("%d\t%s\n", NR, $0); }' > tmp_cds
cat tmp_CDS_candidates_dnds_novel_paml.out | grep -v 'kappa' | awk 'BEGIN { FS = "\t"; } { printf("%d\t%s\n", NR, $0); }' > tmp_dnds_novel
cat tmp_CDS_candidates_dnds_flank_paml.out | grep -v 'kappa' | awk 'BEGIN { FS = "\t"; } { printf("%d\t%s\n", NR, $0); }' > tmp_dnds_flank
join -1 1 tmp_cds -2 1 tmp_dnds_novel > tmp_cds_dnds_novel
join -1 1 tmp_cds_dnds_novel -2 1 tmp_dnds_flank | sed 's/ /\t/g' | sed 's/CDS_STOP/CDS (STOP)/g' | sed 's/_identity=/\t/g' | sed 's/_length=/\t/g' | sed 's/_+/\t+/g' | sed 's/_-/\t-/g' | awk 'BEGIN { FS = "\t"; RS = "\n"; } 
{ 
	for (i=2; i<=13; i++) printf("%s\t", $i); 
	printf("%s\t%s\t%s\t", $16, $17, $18); 
	for (i=20; i<=30; i++) 
		printf("%s\t", $i); printf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", $33, $34, $37, $38, $39, $40, $41, $42, $43, $44, $45, $46, $47); 
}' | sed 's/CDS_STOP/CDS (STOP)/g' > tmp_cds_dnds_novel_flank

dn_ds_fisherTest.sh tmp_cds_dnds_novel_flank > $FINAL_CANDIDATES_CODING_DNDS

echo -e "$FINAL_CANDIDATES_CODING_DNDS is done."
echo -e "$FINAL_CANDIDATES_NONCODING is done.\n"

rm -f tmp_cds tmp_dnds_novel tmp_dnds_flank tmp_cds_dnds_novel tmp_cds_dnds_novel_flank
rm -f preprocessing_*.fasta preprocessing_DN_DS_Tags tmp_CDS_*.input tmp_CDS_candidates.maf*
rm -f preprocessing_*.psl TargetESTtags

test ! -f tmp_CDS_candidates_dnds_novel_paml.out && echo -e "** Error in extracting alignments (novel exonic regions) for PAML **\n" && exit 0
test ! -f tmp_CDS_candidates_dnds_flank_paml.out && echo -e "** Error in extracting alignments (flanking exonic regions) for PAML **\n" && exit 0

rm -f _NUM_MAF_BLOCKS_ _paml_log_ *paml.out tmp_S.r tmp_N.r tmp_ds.pVal tmp_dn.pVal tmp_dnds.pVal tmp_candidates_dnds 
rm -f *final_coding *final_noncoding *final_all *identified_candidates.tsv
rm -f *_basic *_result_after_filtering_internal_retained *.sites *_raw_mappable.blocks *_mappable.blocks *cdna_exclusion.tsv

END=$(date +"%s")
DIFF=$(($END - $START))
echo -e "## $(($DIFF / 60)) minutes and $(($DIFF % 60)) seconds elapsed.\n"

