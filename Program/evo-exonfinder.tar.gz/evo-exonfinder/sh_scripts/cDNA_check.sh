#!/bin/bash
# Exclude suspicious candidates which might be located in known cDNAs

test -z $1 && echo -e "Usage: \n\tcDNA_check.sh [TASK_NAME] [SEQUENCED_READS] [CDNA_LIBRARY]\n" && exit 0
test -z $2 && echo -e "Usage: \n\tcDNA_check.sh [TASK_NAME] [SEQUENCED_READS] [CDNA_LIBRARY]\n" && exit 0
test -z $3 && echo -e "Usage: \n\tcDNA_check.sh [TASK_NAME] [SEQUENCED_READS] [CDNA_LIBRARY]\n" && exit 0
test ! -f $2 && echo -e "** [SEQUENCED_READS] is NOT found **" && exit 0
test ! -f $3 && echo -e "** [CDNA_LIBRARY] is NOT found **" && exit 0

TASK_NAME=$1
SeqReads=$2
cdnaLibrary=$3
SeqReadsToDo="$2""_ToDo.fa"
CDNA_EXCLUSION="$TASK_NAME""_cdna_exclusion.tsv"

AS_REMOVED_CANDIDATES="$TASK_NAME""_AS-REMOVED"
CDNA_CHECKED_CANDIDATES="$TASK_NAME""_cdnaChecked"
CDNA_FILTERED_CANDIDATES="$TASK_NAME""_cdnaFiltered"

BLAT="blat" # default 
THREADS="" # default

if [ ! -f _THREADS_ ] || [ ! -s _THREADS_ ]; 
then 
	BLAT="blat" 
	THREADS=""
else 
	BLAT=`cat _THREADS_ | grep blat`
	if [ $BLAT = "blat" ]; 
	then
		THREADS=""
	else	
		THREADS="-threads=""`cat _THREADS_ | grep -v blat`"
	fi
fi

# Transform [SEQUENCED_READS] into "Tag length DNA" format:

if test ! -f "$SeqReadsToDo";
then 
	echo -e "## Transforming $SeqReads into $SeqReadsToDo..."
	echo -e "Progress:  0%\c"
	cat $SeqReads | sed 's/>/\n/g' | awk '
	BEGIN { RS = ""; FS = "\n"; } 
	{ 
		printf("%s\t%d\t", $1, length($2) * (NF-2) + length($NF)); 
		for (i=2; i<=NF; i++) printf("%s", $i); 
		printf("\n"); 
	}' | awk '
	BEGIN { RS = "\n"; } 
	{ 
		if (NF > 3) printf("%s\t%d\t%s\n", $1, $(NF-1), $NF); 
		else printf("%s\t%d\t%s\n", $1, $2, $3); 
		if (NR == 50000) printf("\b\b\b20%") > "/dev/stderr"
		else if (NR == 200000) printf("\b\b\b50%") > "/dev/stderr"
		else if (NR == 500000) printf("\b\b\b75%") > "/dev/stderr"
		else if (NR == 1000000) printf("\b\b\b90%") > "/dev/stderr"
		else if (NR == 10000000) printf("\b\b\b95%") > "/dev/stderr"
	}' > $SeqReadsToDo
	echo -e "\b\b\b100%\n"
fi

echo -e "## Extracting required fastas from $SeqReads and blat them against the cDNA-library..."

# Get the required fasta sequences to blat the cDNA-library:

cat $AS_REMOVED_CANDIDATES | awk '{ printf("%s\n", $7); }' | sort -V -u > TargetESTtags
ExtractSeqDNA $SeqReadsToDo TargetESTtags > preprocessing_cdna_checking.fasta
$BLAT $cdnaLibrary preprocessing_cdna_checking.fasta $THREADS preprocessing_cdna_checking.psl 
echo -e "Blat mapping completed.\n"
echo -e "## Start removing candidates identified in cDNA..."

# Obtain the suspicious regions

cat preprocessing_cdna_checking.psl | egrep -v 'psLayout|^$|match|---' | awk 'BEGIN { FS = "\t"; } { printf("%d\t", $1-$2-$5-$7); printf("%s\t%s\t%d\t%d\t%d\t%s\t%s\t%s\t%s\n", $10, $14, $18, $11, $15, $21, $19, $9, $20); }' | BlatInitTransform.awk | awk 'BEGIN { RS = ""; } { if (NF > 1) printf("%s\n\n", $0); }' | rm_ambiguous_BLAT-blocks.awk cdna | awk 'BEGIN { FS = "\t"; RS = "\n"; } { if ($0 == "") printf(""); else if (NF > 1) printf("%s\t%d\t%d\t%s\t%d\t%d\n", $4, $6, $7, $1, $2, $3); }' | sed 's/chr//g' > $CDNA_EXCLUSION

echo -e "Progress: 50%\c"

if test ! -f $CDNA_EXCLUSION;
then 
	echo -e "** Fail to generate the excluding set of candidates ($CDNA_EXCLUSION). **"
	exit
fi

# Obtain the candidates with suspicious ones removed

cdnaCheck $AS_REMOVED_CANDIDATES $CDNA_EXCLUSION > $CDNA_CHECKED_CANDIDATES 2> $CDNA_FILTERED_CANDIDATES

#if test -f $CDNA_CHECKED_CANDIDATES; 
#then 
#	#echo -e "$CDNA_CHECKED_CANDIDATES is done.\n"
#fi

#if test -f $CDNA_FILTERED_CANDIDATES; 
#then
#	echo -e "$CDNA_FILTERED_CANDIDATES is done.\n"
#fi

#rm -f TargetESTtags preprocessing_cdna_checking.fasta preprocessing_cdna_checking.psl 
echo -e "\b\b\b100%\n"

