#!/bin/bash
# This pipeline performs Fisher exact test for dn and ds values between novel exonic regions and flanking exons

INPUT=$1

if [ ! -f $INPUT ] || [ -z $INPUT ]; 
then 
	echo -e "** dn_ds_fisherTest.sh: Input candidate file error **\n" 
	exit 0
fi

cat $INPUT | grep -v 'splicing sites motif' | awk 'BEGIN { FS = "\t"; RS = "\n"; } { printf("%d\t%s\n", NR, $0); }' > tmp_candidates_dnds

cat $INPUT | egrep -v 'splicing sites motif' | awk 'BEGIN { FS = "\t"; }      
function round(x, ival, aval, fraction)
{
        ival = int(x)    # integer part, int() truncates
     
        if (ival == x)   # no fraction
           return ival   # ensure no decimals
     
        if (x < 0) {
           aval = -x     # absolute value
           ival = int(aval)
           fraction = aval - ival
           if (fraction >= .5)
              return int(x) - 1   # -2.5 --> -3
           else
              return int(x)       # -2.3 --> -2
        } else {
           fraction = x - ival
           if (fraction >= .5)
              return ival + 1
           else
              return ival
        }
}
     
{ 
	Novel_N = $17; Novel_DN = $21; Flank_N = $30; Flank_DN = $34; 
	if (Novel_DN > 1) Novel_DN = 1;
	if (Flank_DN > 1) Flank_DN = 1;
	if (Novel_N == "nan" || Novel_N == "-nan" || Flank_N == "nan" || Flank_N == "-nan" ||  
	Novel_DN == "nan" || Flank_DN == "nan" || Novel_DN == "-nan" || Flank_DN == "-nan") { 
		printf("Candidate_%d <- c(0, 0, 0, 0)\ndim(Candidate_%d) <- c(2,2)\nfisher.test(Candidate_%s)\n\n", NR, NR, NR); 
	} else { 
		if (Novel_N * Novel_DN >=0 && Novel_N * (1 - Novel_DN) >= 0 && Flank_N * Flank_DN >= 0 && Flank_N * (1 - Flank_DN) >= 0)  
		printf("Candidate_%d <- c(%d, %d, %d, %d)\n", NR, round(Novel_N * Novel_DN), 
                round(Novel_N * (1 - Novel_DN)), round(Flank_N * Flank_DN), round(Flank_N * (1 - Flank_DN)));
		printf("dim(Candidate_%d) <- c(2, 2)\nfisher.test(Candidate_%s)\n\n", NR, NR); 
	}
}' > tmp_N.r 

cat $INPUT | egrep -v 'splicing sites motif' | awk 'BEGIN { FS = "\t"; } 
     
function round(x, ival, aval, fraction)
{
        ival = int(x)    # integer part, int() truncates
     
        if (ival == x)   # no fraction
           return ival   # ensure no decimals
     
        if (x < 0) {
           aval = -x     # absolute value
           ival = int(aval)
           fraction = aval - ival
           if (fraction >= .5)
              return int(x) - 1   # -2.5 --> -3
           else
              return int(x)       # -2.3 --> -2
        } else {
           fraction = x - ival
           if (fraction >= .5)
              return ival + 1
           else
              return ival
        }
}
     
{ 
	Novel_S = $16; Novel_DS = $24; Flank_S = $29; Flank_DS = $37;
	if (Novel_DS > 1) Novel_DS = 1;
	if (Flank_DS > 1) Flank_DS = 1;
	if (Novel_S == "nan" || Novel_S == "-nan" || Flank_S == "nan" || Flank_S == "-nan" || 
	Novel_DS == "nan" || Flank_DS == "nan" || Novel_DS == "-nan" || Flank_DS == "-nan") { 
		printf("Candidate_%d <- c(0, 0, 0, 0)\ndim(Candidate_%d) <- c(2,2)\nfisher.test(Candidate_%s)\n\n", NR, NR, NR); 
	} else { 
		if (Novel_S * Novel_DS >=0 && Novel_S * (1 - Novel_DS) >= 0 && Flank_S * Flank_DS >= 0 && Flank_S * (1 - Flank_DS) >= 0) { 
			printf("Candidate_%d <- c(%d, %d, %d, %d)\n", NR, round(Novel_S * Novel_DS), round(Novel_S * (1 - Novel_DS)), 
			round(Flank_S * Flank_DS), round(Flank_S * (1 - Flank_DS)));
			printf("dim(Candidate_%d) <- c(2, 2)\nfisher.test(Candidate_%s)\n\n", NR, NR); 
		}
	}
}' > tmp_S.r

Rscript tmp_N.r | grep p-value | sed -e 's/p-value [=<] //g' | awk 'BEGIN { RS = "\n"; } { printf("%d\t%s\n", NR, $0); }' > tmp_dn.pVal
Rscript tmp_S.r | grep p-value | sed -e 's/p-value [=<] //g' | awk 'BEGIN { RS = "\n"; } { printf("%d\t%s\n", NR, $0); }' > tmp_ds.pVal 

join tmp_dn.pVal tmp_ds.pVal | sed 's/ /\t/g' > tmp_dnds.pVal
join tmp_candidates_dnds tmp_dnds.pVal | sed 's/CDS (STOP)/CDS_STOP/g' | sed 's/ /\t/g' | awk '
BEGIN { 
	FS = "\t"; 
	printf("chr\tstart\tend\tstrand\ttranscript ID\tnovel exonic length\tAS type\tsplicing sites motif\tgenomic type\t");
        printf("flanking exons (+: upstream;downstream -: downstream;upstream)\t# supporting ESTs\tsupporting ESTs\t"); 
        printf("novel sequence identity (dnds)\tnovel sequence length (dnds)\tEST (max score)\t");
        printf("S (novel)\tN (novel) \tt (novel)\tkappa (novel)\tomega (novel)\tdN (novel)\t+- (novel)\tSE (novel)\tdS (novel)\t+- (novel)\tSE (novel)\t");
        printf("flanking sequence identity (dnds)\t flanking sequence length (dnds)\t"); 
        printf("S (flanking)\tN (flanking) \tt (flanking)\tkappa (flanking)\tomega (flanking)\tdN (flanking)\t+- (flanking)\tSE (flanking)\tdS (flanking)\t+- (flanking)\tSE (flanking)\t");
	printf("dn_P: novel vs flanking\tds_P: novel vs flanking\n"); 
 } { for (i=2; i<NF; i++) printf("%s\t", $i); printf("%s\n", $NF); }' | sed 's/CDS_STOP/CDS (STOP)/g' 

