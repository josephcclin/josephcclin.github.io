#!/bin/bash
# Advance analysis follows the basic analysis by Run.sh. It includes the following pipelines: 
#
#	0. Transforming the reference genome fasta file (preprocessing by running Init_Genome.sh)
#	1. Filtering candidates by mapping reads to a cDNA library (cDNA_checking.sh)
#	2. Checking splicing sites of the candidates (SplicingChecking.sh)
#	3. Checking the reading frame for the protein-coding blocks where candidates is located (CodingCheck.sh)
#	4. Combining the evolutionary-rate analysis for the possibly coding candidates (in CodingCheck.sh)
#	

TASK_NAME=$1
TARGET_GENOME=$2
SEQUENCED_READS=$3
CDNA_LIBRARY=$4
INPUT_ENSTS_CDS_PHASE=$5
IS_INTER_SPECIES=$6
#FIRST_FILTERING="$1""_result_after_filtering_internal_retained"
AS_REMOVED_CANDIDATES="$TASK_NAME""_AS-REMOVED"
CDNA_CHECKED_CANDIDATES="$TASK_NAME""_cdnaChecked"
CDNA_FILTERED_CANDIDATES="$TASK_NAME""_cdnaFiltered"

ENST_CODING_PROCESSED="$INPUT_ENSTS_CDS_PHASE""_PROTEIN_CODING_PROCESSED"
DIR_CHROMOSOMES="DIR_CHRS"

test -z $TASK_NAME && echo -e "Usage: \n\tAdvanced_analysis.sh [TASK_NAME] [TARGET_GENOME] [SEQUENCED_READS] [CDNA_LIBRARY] [INPUT_ENSTS_CDS_PHASE] [IS_INTER_SPECIES]\n" && exit 0
test -z $TARGET_GENOME && echo -e "Usage: \n\tAdvanced_analysis.sh [TASK_NAME] [TARGET_GENOME] [SEQUENCED_READS] [CDNA_LIBRARY] [INPUT_ENSTS_CDS_PHASE] [IS_INTER_SPECIES]\n" && exit 0
test ! -d $DIR_CHROMOSOMES && echo -e "** Directory [$DIR_CHROMOSOMES] does not exist.\nPlease run Init_Genome.sh first. **\n" && exit 0
test -z $SEQUENCED_READS && echo -e "Usage: \n\tAdvanced_analysis.sh [TASK_NAME] [TARGET_GENOME] [SEQUENCED_READS] [CDNA_LIBRARY] [INPUT_ENSTS_CDS_PHASE] [IS_INTER_SPECIES]\n" && exit 0
test ! -f $SEQUENCED_READS && echo -e "** File [SEQUENCED_READS] does not exist. **\n" && exit 0
test -z $CDNA_LIBRARY && echo -e "Usage: \n\tAdvanced_analysis.sh [TASK_NAME] [TARGET_GENOME] [SEQUENCED_READS] [CDNA_LIBRARY] [INPUT_ENSTS_CDS_PHASE] [IS_INTER_SPECIES]\n" && exit 0
test ! -f $CDNA_LIBRARY && echo -e "** File [CDNA_LIBRARY] does not exist. **\n" && exit 0
test -z $INPUT_ENSTS_CDS_PHASE && echo -e "Usage: \n\tAdvanced_analysis.sh [TASK_NAME] [TARGET_GENOME] [SEQUENCED_READS] [CDNA_LIBRARY] [INPUT_ENSTS_CDS_PHASE] [IS_INTER_SPECIES]\n" && exit 0
test -z $IS_INTER_SPECIES && echo -e "Usage: \n\tAdvanced_analysis.sh [TASK_NAME] [TARGET_GENOME] [SEQUENCED_READS] [CDNA_LIBRARY] [INPUT_ENSTS_CDS_PHASE] [IS_INTER_SPECIES]\n" && exit 0
test ! -f $ENST_CODING_PROCESSED && echo -e "** File ($ENST_CODING_PROCESSED) does not exist.\nPlease run Init_ENSTs.sh first. **\n" && exit 0
#test ! -f $FIRST_FILTERING && echo -e "** File ($FIRST_FILTERING) does not exist. **\n" && exit 0
test ! -f $AS_REMOVED_CANDIDATES && echo -e "** File $AS_REMOVED_CANDIDATES does not exist. **\n" && exit 0

#echo -e "\n## Filtering candidates by mapping reads to the cDNA library ##\n"
if [ $CDNA_LIBRARY = "_EMPTY_CDNA_" ] || [ ! -f $CDNA_LIBRARY ] || [ ! -s $CDNA_LIBRARY ];
then
	cp $AS_REMOVED_CANDIDATES $CDNA_CHECKED_CANDIDATES
	echo "" > $CDNA_FILTERED_CANDIDATES
	echo -e "## cDNA filtering step is skipped.\n"
else 
	cDNA_check.sh $TASK_NAME $SEQUENCED_READS $CDNA_LIBRARY
fi
#echo -e "\n## Filtering candidates by checking their splicing sites ##\n"
SplicingCheck.sh $TASK_NAME $DIR_CHROMOSOMES $IS_INTER_SPECIES
#echo -e "\n## Reading frame examination and stop codon checking ##\n"
CodingCheck.sh $TASK_NAME $ENST_CODING_PROCESSED $IS_INTER_SPECIES
#echo -e "## Advanced analysis completed. \n"
rm -f progress.log
