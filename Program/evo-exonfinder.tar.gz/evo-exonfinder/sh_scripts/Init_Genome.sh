#!/bin/bash
# Transform a genome into separate fastas (CHROMOSOME_NAME, SIZE, DNA) w.r.t. chromosomes

GENOME=$1
DIR_CHROMOSOMES="DIR_CHRS"

test -z $GENOME && echo -e "Usage:\n\tInit_Genome.sh [GENOME]\n" && exit 0

if test -d $DIR_CHROMOSOMES;
then 
	read -p "## Re-Initialize the genome data? " yn
	case $yn in 
		[Yy]* ) decision=1;;
		[Nn]* ) decision=0;;
	esac
else
	decision=1;
fi

if [ $decision -eq 1 ];
then
	cat $GENOME | sed 's/>/\n/g' | awk '
	BEGIN { 
		RS = ""; 
		FS = "\n"; 
	} 
	{ 
		if (NF > 2) { 
			if (substr($1, 1, 3) != "chr") $1 = "chr" $1
			printf("%s\t%d\t", $1, length($2) * (NF-2) + length($NF)); 
		} else { 
			if (substr($1, 1, 3) != "chr") $1 = "chr" $1
			printf("%s\t%d\t", $1, length($2)); 
		}
		
		for (i=2; i<=NF; i++) printf("%s", $i); printf("\n"); 
	}' | awk '
	BEGIN { RS = "\n"; } 
	{ 
		if (NF > 3) printf("%s\t%d\t%s\n", $1, $(NF-1), $NF); 
		else printf("%s\t%d\t%s\n", $1, $2, $3); 
	}' | GenomeTransform $DIR_CHROMOSOMES 
fi
