#!/bin/bash
# This scripts integrates Basic_analysis.sh and Advanced_analysis.sh. 
#
# Author: Joseph Chuang-Chieh Lin
# Date: 31 May 2014

BLAT_OUTPUT=$1
INPUT_ENSTS=$2
INPUT_ENSTS_CDS_PHASE=$3
TARGET_GENOME=$4
EXPRESSED_SEQUENCES=$5
CDNA_LIBRARY=$6
MAX_GAP_LEN=$7
TASK_NAME=$8
IS_INTER_SPECIES=$9
MIN_SCORE_DIFF=$10

DIR_CHROMOSOMES="DIR_CHRS"

if [ "$#" -ne 10 ];
then 
	echo -e "** Number of parameters is not correct. **"
	echo -e "Usage: \n\tNE-Extractor.sh [BLAT_OUTPUT] [INPUT_ENSTS] [INPUT_ENSTS_CDS_PHASE] [TARGET_GENOME] [EXPRESSED_SEQUENCES] [CDNA_LIBRARY] [MAX_GAP_LEN] [TASK_NAME] [IS_INTER_SPECIES] [MIN_SCORE_DIFF]\n"
	exit 0
fi

test ! -f $BLAT_OUTPUT && echo -e "** File ($BLAT_OUTPUT) does not exist. **\n\n" && exit 0
test ! -f $INPUT_ENSTS && echo -e "** File ($INPUT_ENSTS) does not exist. **\n\n[INPUT_ENSTS] includes:\n\tEnsembl Gene ID, Ensembl Transcript ID, Chromosome Name, Gene Start (bp), Gene End (bp), Strand, \n\tTranscript Start (bp), Transcript End (bp), 5' UTR Start, 5' UTR End, 3' UTR Start, 3' UTR End, \n\tCDS Start, CDS End, Exon Chr Start (bp), Exon Chr End (bp), Gene Biotype,\n\tTranscript Biotype, Status (transcript).\n\n" && exit 0
test ! -f $INPUT_ENSTS_CDS_PHASE && echo -e "** File ($INPUT_ENSTS_CDS_PHASE) does not exist. **\n\n[INPUT_ENSTS_CDS_PHASE] includes:\n\tEnsembl Gene ID, Ensembl Transcript ID, Chromosome Name, Strand, \n\tExon Chr Start (bp), Exon Chr End (bp), Exon Rank in Transcript, phase,\n\tCDS Start, CDS End, Transcript Biotype\n" && exit 0
test ! -f $TARGET_GENOME && echo -e "** [TARGET_GENOME] does not exist. **\n" && exit 0
test ! -f $EXPRESSED_SEQUENCES && echo -e "** File [EXPRESSED_SEQUENCES] does not exist. **\n" && exit 0
test ! -f $CDNA_LIBRARY && echo -e "** File [CDNA_LIBRARY] does not exist. **\n" && exit 0
test ! -f $BLAT_OUTPUT && echo -e "** File ($BLAT_OUTPUT) does not exist. **\n\n" && exit 0
test ! -f $INPUT_ENSTS && echo -e "** File ($INPUT_ENSTS) does not exist. **\n" && exit 0

rm -f _CHECK_*BLAT_ _WHERE_IS_*BLAT_

test ! -d $DIR_CHROMOSOMES && Init_Genome.sh $TARGET_GENOME 
Init_ENSTs.sh $INPUT_ENSTS $INPUT_ENSTS_CDS_PHASE

START=$(date +"%s")
Basic_analysis.sh $BLAT_OUTPUT $INPUT_ENSTS $MAX_GAP_LEN $TASK_NAME $IS_INTER_SPECIES $MIN_SCORE_DIFF
Advanced_analysis.sh $TASK_NAME $TARGET_GENOME $EXPRESSED_SEQUENCES $CDNA_LIBRARY $INPUT_ENSTS_CDS_PHASE $IS_INTER_SPECIES
END=$(date +"%s")
DIFF=$(($END - $START))
echo -e "## $(($DIFF / 60)) minutes and $(($DIFF % 60)) seconds elapsed.\n"
