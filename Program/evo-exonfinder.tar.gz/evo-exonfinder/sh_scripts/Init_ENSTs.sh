#!/bin/bash
# Initialize the required Ensembl annotations of exons.
#
# INPUT_ENSTS includes:
#       Ensembl Gene ID, Ensembl Transcript ID, Chromosome Name, Gene Start (bp), Gene End (bp), Strand, Transcript Start (bp), Transcript End (bp), 
#       5' UTR Start, 5' UTR End, 3' UTR Start, 3' UTR End, CDS Start, CDS End, Exon Chr Start (bp), Exon Chr End (bp), Gene Biotype, 
#       Transcript Biotype, Status (transcript).
# INPUT_ENSTS_CDS_PHASE includes: 
#       Ensembl Gene ID, Ensembl Transcript ID, Chromosome Name, Strand, Exon Chr Start (bp), Exon Chr End (bp), Exon Rank in Transcript, phase, 
#       CDS Start, CDS End, Transcript Biotype

INPUT_ENSTS=$1
ENST_PROCESSED="$1""_ENST_PROCESSED"
EXONS_PROCESSED="$1""_EXONS_PROCESSED"
INPUT_ENSTS_CDS_PHASE=$2
ENST_CODING_PROCESSED="$INPUT_ENSTS_CDS_PHASE""_PROTEIN_CODING_PROCESSED"

test -z $INPUT_ENSTS && echo -e "Usage: \n\tInit_ENSTs.sh [INPUT_ENSTS] [INPUT_ENSTS_CDS_PHASE]\n" && exit 0
test ! -f $INPUT_ENSTS && echo -e "** File ($INPUT_ENSTS) error **\n" && exit 0
test -z $INPUT_ENSTS_CDS_PHASE && echo -e "Usage: \n\tInit_ENSTs.sh [INPUT_ENSTS] [INPUT_ENSTS_CDS_PHASE]\n" && exit 0
test ! -f $INPUT_ENSTS_CDS_PHASE && echo -e "** File ($INPUT_ENSTS_CDS_PHASE) error **\n" && exit 0

decision=0

if [ ! -f $ENST_PROCESSED ] || [ ! -f $EXONS_PROCESSED ] || [ ! -f $ENST_CODING_PROCESSED ] || [ ! -f ENST_LEN ] || [ ! -f ENST_EXON_LEN ];
then 
	decision=1
fi

#test ! -f $ENST_PROCESSED && decision=1
#test ! -f $EXONS_PROCESSED && decision=1
#test ! -f $ENST_CODING_PROCESSED && decision=1
#test ! -f ENST_LEN && decision=1
#test ! -f ENST_EXON_LEN && decision=1

if [ $decision -eq 1 ];
then
	echo -e "## Starting to initialize the annotation files..."
	cat $INPUT_ENSTS | sed 's/,/\t/g' | egrep -v 'Ensembl|((G|g)ene|(T|t)ranscript)[[:space:]]*[[:alpha:]]*[[:space:]]*ID' | awk 'BEGIN { FS = "\t"; } { printf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", $1, $2, $3, $6, $7, $8, $15, $16, $18); }' | sort -V | Init_ENST.awk | awk 'BEGIN { FS = "\t"; RS = ""; } { for (i=1; i<=5; i++) printf("%s\t", $i); printf("%s\n", $6); for (i=7; i<=NF-1; i+=2) { if (i == 7 || i > 7 && $i > $(i-1)) printf("%d\t%d\n", $i, $(i+1)); } printf("\n"); }' | awk 'BEGIN { RS = ""; FS = "\n"; } { printf("%s\t%d\t", $1, NF-1); for (i=2; i<=NF-1; i++) printf("%s\t", $i); printf("%s\n", $NF); }' | sort -V | awk 'BEGIN { FS = "\t"; RS = "\n"; } { for (i=1; i<=6; i++) printf("%s\t", $i); printf("%s\n", $7); for (i=8; i<=NF-1; i+=2) { printf("%d\t%d\n", $i, $(i+1)); } }' > $ENST_PROCESSED
	cat $ENST_PROCESSED | grep chr | GetENSTMaxLen.awk > ENST_LEN
	#echo -e "ENST_LEN is done."
	#echo -e "$ENST_PROCESSED ([ENST_PROCESSED]) is done."
	echo -e "Progress:  25%\c"
fi

if [ $decision -eq 1 ];
then 
	cat $INPUT_ENSTS | sed 's/,/\t/g' | egrep -v 'Ensembl|((G|g)ene|(T|t)ranscript)[[:space:]]*[[:alpha:]]*[[:space:]]*ID' | awk '
	BEGIN { FS = "\t"; } 
	{ 
		if ($6 == 1) $6 = "+"; 
		else $6 = "-"; 
		printf("chr%s\t%d\t%d\t%s\t%s\t%s\n", $3, $15, $16, $6, $2, $18); 
	} ' | sort -V -u > $EXONS_PROCESSED
	cat $ENST_PROCESSED | sed 's/chr/\nchr/g' | awk '
	BEGIN { RS = ""; } 
	{ 
		CHR = $1; 
		STRAND = $4; 
		ENST = $5; 
		BIOTYPE = $6; 
		numExons = $7; 
		for (i=7; i<NF; i+=2) printf("%s\t%d\t%d\t%s\t%s\t%s\n", CHR, $(i+1), $(i+2), STRAND, ENST, BIOTYPE ); 
	}' | GetENSTMaxLen.awk > ENST_EXON_LEN
	#echo -e "$EXONS_PROCESSED ([EXONS_PROCESSED]) is done."
	echo -e "\b\b\b50%\c"
fi

if [ $decision -eq 1 ];
then
	cat $INPUT_ENSTS_CDS_PHASE | sed 's/,/\t/g' | egrep -v 'Ensembl|((G|g)ene|(T|t)ranscript)[[:space:]]*[[:alpha:]]*[[:space:]]*ID' | grep protein_coding | awk '
	BEGIN { 
		FS = "\t"; 
		id = "tmp"; 
	} 
	{ 
		if ($2!=id) { 
			printf("\n%s\n", $0); 
			id = $2; 
		} else { 
			printf("%s\n", $0); 
		} 
	}' | awk '
	BEGIN { 
		RS = ""; 
		FS = "[\t\n]"; 
	} 
	{ 
		printf("%s\n\n", $0); 
	}' | awk '
	BEGIN { 
		RS = ""; 
		FS = "[\t\n]"; 
	} 
	{ 
		for (i=1; i<=NF/11; i++) { 
			for (j=1; j<=NF; j+=11) { 
				if ($(j+6) == i) { 
					printf("%s\t%s\tchr%s\t", $j, $(j+1), $(j+2)); 
					if ($(j+3) == 1) { 
						printf("+\t"); 
					} else { 
						printf("-\t"); 
					} 
					printf("%d\t%d\t%d\t%d\t%d\t%d\t%s\n", $(j+4), $(j+5), $(j+6), $(j+7), $(j+8), $(j+9), $(j+10)); 
				} 
			} 
		} 
		printf("\n"); 
	}' | awk '
	BEGIN { RS = ""; } 
	{ 
		if ($0 != "") { 
			for (i=0; i<NF/11; i++) { 
				printf("%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\n", $(i*11+2), $(i*11+3), $(i*11+4), $(i*11+5), $(i*11+6), 
				$(i*11+7), $(i*11+8), $(i*11+9), $(i*11+10)); 
			} 
			printf("\n"); 
		} 
	}' | awk '
	BEGIN { FS = "\t"; } 
	{ 
		if ($0 == "") printf("\n"); 
		else { 
			if (!($7 == -1 && $8 == 0 && $9 == 0)) printf("%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\n", $1, $2, $3, $4, $5, $6, $7, $8, $9); 
		} 
	}' | CDS_transform.awk | CDS_transform_refined_1.awk | awk 'BEGIN { RS = ""; FS = "\n"; } { for (i=1; i<=NF; i++) { if (i==1 || i>1 && $i!=$(i-1)) printf("%s\n", $i); } printf("\n"); }' | CDS_transform_refined_2.awk > $ENST_CODING_PROCESSED
	#echo -e "$ENST_CODING_PROCESSED ([ENST_CODING_PROCESSED]) is done.\n"
	echo -e "\b\b\b\b100%\n"
fi


