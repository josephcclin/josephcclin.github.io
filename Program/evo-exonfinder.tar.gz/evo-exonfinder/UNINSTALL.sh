#!/bin/bash

INSTALL_FOLDER="$HOME/EVO_EXON_FINDER"
INSTALL_FOLDER_SCRIPT="$HOME/EVO_EXON_FINDER/SCRIPT"
INSTALL_FOLDER_C="$HOME/EVO_EXON_FINDER/C"
INSTALL_FOLDER_AWK="$HOME/EVO_EXON_FINDER/AWK"

INSTALL_FOLDER_COMMAND=$(echo $INSTALL_FOLDER | sed -e "s|\/|\\\/|g")
INSTALL_FOLDER_COMMAND_SCRIPT=$(echo $INSTALL_FOLDER_SCRIPT | sed -e "s|\/|\\\/|g")
INSTALL_FOLDER_COMMAND_C=$(echo $INSTALL_FOLDER_C | sed -e "s|\/|\\\/|g")
INSTALL_FOLDER_COMMAND_AWK=$(echo $INSTALL_FOLDER_AWK | sed -e "s|\/|\\\/|g")

rm -r -f $INSTALL_FOLDER

cat $HOME/.profile | sed -e "s|\/:$INSTALL_FOLDER_COMMAND_SCRIPT||g" | sed -e "s|:$INSTALL_FOLDER_COMMAND_SCRIPT||g" | \
sed -e "s|\/:$INSTALL_FOLDER_COMMAND_C||g" | sed -e "s|:$INSTALL_FOLDER_COMMAND_C||g" | sed -e "s|\/:$INSTALL_FOLDER_COMMAND_AWK||g" | \
sed -e "s|:$INSTALL_FOLDER_COMMAND_AWK||g" | sed -e "s|\/:$INSTALL_FOLDER_COMMAND||g" | sed -e "s|:$INSTALL_FOLDER_COMMAND||g" | awk '
BEGIN { flag = 0; } 
{ 
	if ($0 == "# appended by EvoExonFinder") 
		flag = 1; 
	else { 
		if (flag == 0) 
			printf("%s\n", $0); 
		else if (substr($0, 1, 6) == "export") 
			flag = 0; 
	} 
}' > profile.tmp
mv profile.tmp $HOME/.profile

echo -e "\nUn-installation completed.\n"
