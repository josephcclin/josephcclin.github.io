#!/bin/bash

INSTALL_FOLDER="$HOME/EVO_EXON_FINDER"
INSTALL_FOLDER_SHELL="$HOME/EVO_EXON_FINDER/SCRIPT"
INSTALL_FOLDER_C="$HOME/EVO_EXON_FINDER/C"
INSTALL_FOLDER_AWK="$HOME/EVO_EXON_FINDER/AWK"
INSTALL_FOLDER_PAML="$HOME/EVO_EXON_FINDER/PAML"

chmod 755 ./sh_scripts/*.sh 
chmod 755 ./C_PROGRAMS/BINARY/*
chmod 755 ./AWKs/*.awk
chmod 755 ./PAML/PPAML
chmod 755 ./PAML/yn00

decision=1

if test -d $INSTALL_FOLDER;
then
        read -p "## Re-Install EvoExonFinder? (y/n) " yn
        case $yn in
                [Yy]* ) decision=1;;
                [Nn]* ) decision=0;;
        esac
else
        decision=1;
fi

if [ $decision -eq 1 ];
then
	if test ! -d $INSTALL_FOLDER;
	then 
		mkdir $INSTALL_FOLDER
	fi
	if test ! -d $INSTALL_FOLDER_SHELL; 
	then 
		mkdir $INSTALL_FOLDER_SHELL
	fi
	if test ! -d $INSTALL_FOLDER_C;
	then
		mkdir $INSTALL_FOLDER_C
	fi
	if test ! -d $INSTALL_FOLDER_AWK;
	then
		mkdir $INSTALL_FOLDER_AWK
	fi
	if test ! -d $INSTALL_FOLDER_PAML;
	then
		mkdir $INSTALL_FOLDER_PAML
	fi
	cp ./sh_scripts/*.sh $INSTALL_FOLDER_SHELL
	cp ./C_PROGRAMS/BINARY/* $INSTALL_FOLDER_C
	cp ./AWKs/*.awk $INSTALL_FOLDER_AWK
	cp ./PAML/* $INSTALL_FOLDER_PAML

	#cat $HOME/.profile | grep -v 'PATH=' > profile_tmp
	#echo -e "export PATH=$PATH:$INSTALL_FOLDER:$INSTALL_FOLDER_SHELL:$INSTALL_FOLDER_C:$INSTALL_FOLDER_AWK" >> profile_tmp
	#cp $HOME/.profile $HOME/.profile.bak
	#mv profile_tmp $HOME/.profile
	echo -e "\n# appended by EvoExonFinder\n\nexport PATH=$PATH:$INSTALL_FOLDER:$INSTALL_FOLDER_SHELL:$INSTALL_FOLDER_C:$INSTALL_FOLDER_AWK" >> $HOME/.profile
	echo -e "\nInstallation completed."
	echo -e "\nPlease type \"source ~/.profile\" to make EvoExonFinder executable anywhere."
	echo -e "\nType \"EvoExonFinder\" or \"EvoExonFinder --help\" for help.\nEnjoy it."
fi

echo -e "\nEvoExonFinder Copyright (c) 2014 Dr. Trees-Juen Chuang's Lab"
echo -e "Author: Dr. Joseph Chuang-Chieh Lin (email: josephcclin@gmail.com)"
echo -e "This program comes with ABSOLUTELY NO WARRANTY.\n"

