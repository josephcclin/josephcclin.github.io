EvoExonFinder: 

	A pipeline which identifies novel cassette exons and novel retained introns from cross/target species EST BLAT mapping and provides 
	evolutionary rate analysis.

	EvoExonFinder Copyright (c) 2014 Dr. Trees-Juen Chuang's Lab
	Author: Dr. Joseph Chuang-Chieh Lin (email: josephcclin@gmail.com)
	This program comes with ABSOLUTELY NO WARRANTY.

Programming languages: 

	C/Bash shell script/AWK

	Tested Compiler versions:
		gcc version 4.4.3 (Ubuntu 4.4.3-4ubuntu5) 
		gcc version 4.6.3 20120306 (Red Hat 4.6.3-2)

	Tested Bash shell versions: 
		GNU bash, version 4.1.5(1)-release (x86_64-pc-linux-gnu)	
		GNU bash, version 4.2.10(1)-release (x86_64-redhat-linux-gnu)
	
	Tested AWK versions: 
		GNU Awk 3.1.6
		GNU Awk 3.1.8

Execution environment (recommended): 

	Platform: Linux x86-64 (kernel 2.6.32 or later; recommended distribution: Bio-Linux 6 or later versions) 
	Memoery: Depending on BLAT and the target genome size.
	BLAT/PBLAT and R/Rscript must be executable anywhere.
	*PBLAT: blat with multi-threads support (http://code.google.com/p/pblat/). (Optional). 

Installation/Uninstallation: 

	tar -xzvf evo-exonfinder.tar.gz 
	cd evo-exonfinder/

	Type "make install" and then "source ~/.profile" to complete the installation. 
	Type "make uninstall" to uninstall this tool. 
		
	*If there is any problem with the C executable files, try "make all" to rebuild them  and then "make install" 
	again.  

*****************************************************************************************************************************************************

Usage: 

	EvoExonFinder --config [CONFIG_FILE] -x [CROSS-SPECIES_MAPPING_PSL] -o [TASK_NAME]
	EvoExonFinder --config [CONFIG_FILE] -t [TARGET-SPECIES_MAPPING_PSL] -o [TASK_NAME]
	EvoExonFinder --config [CONFIG_FILE] -b -1 [CROSS-SPECIES_MAPPING_PSL] -2 [TARGET-SPECIES_MAPPING_PSL] -o [TASK_NAME]

	-x: identify novel exons through cross-species EST mapping
	-t: identify novel exons through target-species EST mapping
	-b: identify novel exons through both target and cross species EST mapping

	[TASK_NAME]: 
		A label for the current task. No space is allowed. 

	[CROSS-SPECIES_MAPPING_PSL]: 
		The output of mapping cross-species ESTs against the target genome in the psl format. 
	
	[TARGET-SPECIES_MAPPING_PSL]: 
		The output of mapping target-species ESTs against the target genome in the psl format. 

	[CONFIG_FILE] should contain the following fields (please do NOT change them), each of which is followed by either a file name (as well as 
	its location) or a value as the corresponding parameter (see sample.config):
		 
		INPUT_ENSTS	
		INPUT_ENSTS_CDS_PHASE	
		CDNA_LIBRARY	
		TARGET_GENOME	
		MAX_GAP_LEN	
		CROSS_SPECIES_EST	
		TARGET_SPECIES_EST
		MIN_SCORE_DIFF
		THREADS	

		[INPUT_ENSTS]: 
			Gene annotation (csv/tsv) of the target species downloaded from Ensembl BioMart. 
			Required 19 attributes (must follow the order below): 
				Ensembl Gene ID, 
				Ensembl Transcript ID, 
				Chromosome Name, 
				Gene Start (bp), 
				Gene End (bp), 
				Strand, 
				Transcript Start (bp), 
				Transcript End (bp), 
				5' UTR Start, 
				5' UTR End, 
				3' UTR Start, 
				3' UTR End, 
				CDS Start, 
				CDS End, 
				Exon Chr Start (bp), 
				Exon Chr End (bp), 
				Gene Biotype, 
				Transcript Biotype, 
				Status (transcript). 
			If "Status (transcript)" is not available, choose "Gene name" or "Protein ID" instead.

		[INPUT_ENSTS_CDS_PHASE]: 
			Another gene annotation (csv/tsv) of the target species downloaded from Ensembl BioMart. 
			Required 11 attributes (must follow the order below): 
				Ensembl Gene ID, 
				Ensembl Transcript ID, 
				Chromosome Name, 
				Strand, 
				Exon Chr Start (bp), 
				Exon Chr End (bp), 
				Exon Rank in Transcript, 
				phase, 
				CDS Start, 
				CDS End, 
				Transcript Biotype.

		[CDNA_LIBRARY]: 
			The whole annotated transcript sequences (fasta) which can be download at Ensembl website. 
			(Downloads -> Download "databases" -> cDNA)
			This field in [CONFIG_FILE] can be left as empty, and the cDNA filtering step will be skipped.
		
		[TARGET_GENOME]: 
			The whole genome (fasta) of the target species downloaded from UCSC/Ensembl database. 
	
		[MAX_GAP_LEN]: Recommended (default) value: 10
			Maximum gap length between contiguous segments aligned by BLAT. Two contiguous segments, between which there are no more than 
			[MAX_GAP_LEN] gaps, will be regarded as one segment. 
			
		[CROSS_SPECIES_EST]: 
			The cross species EST file which were used to obtain [CROSS-SPECIES MAPPING PSL].

		[TARGET_SPECIES_EST]: 
			The EST file from the target species which were used to obtain [TARGET-SPECIES MAPPING PSL].

		[MIN_SCORE_DIFF]: Recommended (default) value: 20
			A value set for filtering ambiguous BLAT mapping results. The mapping results of an EST will 
			be discarded if the best and the second best scores differ in at most this value. 

		[THREADS]: default 1
			Set this value to run blat in multi-threads by pblat. Since there are some issues of pblat, we suggest to set `1' here. 

Output files: 

	For option '-x': 
		[TASK_NAME]_cross_identified_CDS_candidates_dnds.tsv
		[TASK_NAME]_cross_identified_UTR_candidates.tsv

	For option '-t': 
		[TASK_NAME]_same_identified_CDS_candidates.tsv
		[TASK_NAME]_same_identified_UTR_candidates.tsv

	For option '-b': 		
		[TASK_NAME]_cross_identified_CDS_candidates_dnds.tsv
		[TASK_NAME]_cross_identified_UTR_candidates.tsv
		[TASK_NAME]_same_identified_CDS_candidates.tsv
		[TASK_NAME]_same_identified_UTR_candidates.tsv

		as well as:

		merged candidates from both cross and target species mapping
			[TASK_NAME]_cross_same_merged_identified_CDS_candidates.tsv 
			[TASK_NAME]_cross_same_merged_identified_UTR_candidates.tsv 
		and 

		merged candidates without target species EST support
			[TASK_NAME]_cross_same_filtered_identified_CDS_candidates_dnds.tsv
			[TASK_NAME]_cross_same_filtered_identified_UTR_candidates.tsv 

	Columns in order (41 attributes for *identified_CDS_candidates_dnds.tsv):
		chr, 
		start (1-base), 
		end (1-base), 
		strand, 
		transcript ID, 
		novel exonic length, 
		AS type, 
		splicing sites motif, 
		genomic type, 
		coordinates of flanking exons, 
		#supporting reads, 
		supporting reads, 
		novel sequence identity (dnds), 
		novel sequence length (dnds), 
		EST (max score), 
		S (novel), 
		N (novel), 
		t (novel), 
		kappa (novel), 
		omega (novel), 
		dN (novel), 
		+- (novel), 
		SE (novel), 
		dS (novel), 
		+- (novel), 
		SE (novel), 
		flanking sequence identity (dnds), 
		flanking sequence length (dnds), 
		S (flanking), 
		N (flanking), 
		t (flanking), 
		kappa (flanking), 
		omega (flanking), 
		dN (flanking), 
		+- (flanking), 
		SE (flanking), 
		dS (flanking), 
		+- (flanking), 
		SE (flanking), 
		dn_P: novel vs flanking, 
		ds_P: novel vs flanking.
.
	For "start", "end", and "splicing sites motifs": 
		Two or more numbers/motifs separated by semicolons stand for events of multiple cassette  exons. 

	For "coordinates of flanking exons" (1-base): 
		strand "+": 
			upstream flanking exon 5'end, 
			upstream flanking exon 3'end; 
			downstream flanking exon 5'end, 
			downstream flanking exon 3'end
		strand "-": 
			downstream flanking exon 3'end, 
			downstream flanking exon 5'end; 
			upstream flanking exon 3'end, 
			upstream flanking exon 5'end

*Note: 
	[INPUT_ENSTS] and [INPUT_ENSTS_CDS_PHASE] can be generated by "Thanda" (by Yen-Zho Chen). Though, it can only be executed in Windows OS. 
	Users can also download threes files, say annotation_1.tsv, annotation_2.tsv, transcript_biotypes.tsv, from Ensembl Biomart, and then run 
	"ENST_Combine.sh annotation_1.tsv annotation_2.tsv transcript_biotypes.tsv" to generate [INPUT_ENSTS] and [INPUT_ENSTS_CDS_PHASE], that 
	will be, for example, "annotation_1.tsv.genes" and "annotation_2.tsv.CDS.tx" respectively.

	"annotation_1.tsv" should contain the following 17 attributes in order: 
		Ensembl Gene ID, 
		Ensembl Transcript ID, 
		Chromosome Name, 
		Gene Start (bp), 
		Gene End (bp), 
		Strand, 
		Transcript Start (bp), 
		Transcript End (bp), 
		5' UTR Start, 
		5' UTR End, 
		3' UTR Start, 
		3' UTR End, 
		CDS Start, 
		CDS End, 
		Exon Chr Start (bp), 
		Exon Chr End (bp), 
		Gene Biotype.
	
	"annotation_2.tsv" should contain the following 10 attributes in order: 
		Ensembl Gene ID, 
		Ensembl Transcript ID, 
		Chromosome Name, 
		Strand, 
		Exon Chr Start (bp), 
		Exon Chr End (bp), 
		Exon Rank in Transcript, 
		phase, 
		CDS Start, 
		CDS End. 

	"transcript_biotypes.tsv" should contain the following 3 attributes in order: 
		Ensembl Transcript ID, 	
		Transcript Biotype, 
		Status (transcript). 
	If "Status (transcript)" is not available, choose "Gene name" or "Protein ID" instead.	
	

